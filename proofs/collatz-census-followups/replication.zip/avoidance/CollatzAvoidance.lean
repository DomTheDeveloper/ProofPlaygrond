import Lean

/- Ordinary Collatz, with forward (positive-time or time-zero) visits.
   Checked with Lean 4.14.0 and its standard library. -/
namespace Census

def C (n : Nat) : Nat := if n % 2 = 0 then n / 2 else 3*n+1

inductive Hits (P : Nat → Prop) : Nat → Prop
  | here {n} : P n → Hits P n
  | prev {n} : Hits P (C n) → Hits P n

def FirstTarget (n : Nat) : Prop :=
  n ≤ 1 ∨ n % 8 = 7 ∨ n % 2916 = 2909

private abbrev Row (d r a b : Nat) : Prop :=
  ∀ t : Nat, 1 < d*t+r →
    (∀ y, y < d*t+r → Hits FirstTarget y) → Hits FirstTarget (a*t+b)

private theorem splitRow {d r a b : Nat}
    (left : Row (2*d) r (2*a) b)
    (right : Row (2*d) (r+d) (2*a) (b+a)) : Row d r a b := by
  intro t ht ih
  obtain ⟨u, h⟩ : ∃ u, t = 2*u ∨ t = 2*u+1 := ⟨t/2, by omega⟩
  rcases h with h | h
  · subst t
    simpa only [Nat.mul_add, Nat.mul_one, Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc,
      Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using
      left u (by simpa [Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc] using ht)
        (by simpa [Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc] using ih)
  · subst t
    simpa only [Nat.mul_add, Nat.mul_one, Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc,
      Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using
      right u (by simpa [Nat.mul_add, Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc,
                         Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using ht)
        (by simpa [Nat.mul_add, Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc,
                   Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using ih)

private theorem stepRow {d r a b e f : Nat}
    (heq : ∀ t, C (a*t+b)=e*t+f) (next : Row d r e f) : Row d r a b := by
  intro t ht ih
  apply Hits.prev
  rw [heq]
  exact next t ht ih

/- The generated tree below repeatedly bisects a single binary input
   progression, takes an actual C step, or proves a visit or a descent.
   Each branch identity is discharged by kernel-checked arithmetic. -/
/- BEGIN CERTIFICATE -/
private theorem r0 : Row 2 0 1 0 := by
  intro t h ih; exact ih _ (by omega)

private theorem r1 : Row 2 0 2 0 := stepRow (e := 1) (f := 0) (by intro t; unfold C; split <;> omega) r0

private theorem r2 : Row 4 1 3 1 := by
  intro t h ih; exact ih _ (by omega)

private theorem r3 : Row 4 1 6 2 := stepRow (e := 3) (f := 1) (by intro t; unfold C; split <;> omega) r2

private theorem r4 : Row 4 1 12 4 := stepRow (e := 6) (f := 2) (by intro t; unfold C; split <;> omega) r3

private theorem r5 : Row 4 1 4 1 := stepRow (e := 12) (f := 4) (by intro t; unfold C; split <;> omega) r4

private theorem r6 : Row 16 3 9 2 := by
  intro t h ih; exact ih _ (by omega)

private theorem r7 : Row 16 3 18 4 := stepRow (e := 9) (f := 2) (by intro t; unfold C; split <;> omega) r6

private theorem r8 : Row 32 11 27 10 := by
  intro t h ih; exact ih _ (by omega)

private theorem r9 : Row 32 11 54 20 := stepRow (e := 27) (f := 10) (by intro t; unfold C; split <;> omega) r8

private theorem r10 : Row 32 11 108 40 := stepRow (e := 54) (f := 20) (by intro t; unfold C; split <;> omega) r9

private theorem r11 : Row 32 11 36 13 := stepRow (e := 108) (f := 40) (by intro t; unfold C; split <;> omega) r10

private theorem r12 : Row 64 27 72 31 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r13 : Row 128 59 81 38 := by
  intro t h ih; exact ih _ (by omega)

private theorem r14 : Row 128 59 162 76 := stepRow (e := 81) (f := 38) (by intro t; unfold C; split <;> omega) r13

private theorem r15 : Row 256 123 243 118 := by
  intro t h ih; exact ih _ (by omega)

private theorem r16 : Row 256 123 486 236 := stepRow (e := 243) (f := 118) (by intro t; unfold C; split <;> omega) r15

private theorem r17 : Row 256 123 972 472 := stepRow (e := 486) (f := 236) (by intro t; unfold C; split <;> omega) r16

private theorem r18 : Row 256 123 324 157 := stepRow (e := 972) (f := 472) (by intro t; unfold C; split <;> omega) r17

private theorem r19 : Row 512 251 648 319 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r20 : Row 1024 507 729 362 := by
  intro t h ih; exact ih _ (by omega)

private theorem r21 : Row 1024 507 1458 724 := stepRow (e := 729) (f := 362) (by intro t; unfold C; split <;> omega) r20

private theorem r22 : Row 4096 1019 2187 545 := by
  intro t h ih; exact ih _ (by omega)

private theorem r23 : Row 4096 1019 4374 1090 := stepRow (e := 2187) (f := 545) (by intro t; unfold C; split <;> omega) r22

private theorem r24 : Row 8192 3067 6561 2458 := by
  intro t h ih; exact ih _ (by omega)

private theorem r25 : Row 8192 3067 13122 4916 := stepRow (e := 6561) (f := 2458) (by intro t; unfold C; split <;> omega) r24

private theorem r26 : Row 8192 3067 26244 9832 := stepRow (e := 13122) (f := 4916) (by intro t; unfold C; split <;> omega) r25

private theorem r27 : Row 8192 3067 8748 3277 := stepRow (e := 26244) (f := 9832) (by intro t; unfold C; split <;> omega) r26

private theorem r28 : Row 32768 7163 19683 4304 := by
  intro t h ih; exact ih _ (by omega)

private theorem r29 : Row 32768 7163 39366 8608 := stepRow (e := 19683) (f := 4304) (by intro t; unfold C; split <;> omega) r28

private theorem r30 : Row 262144 23547 177147 15914 := by
  intro t h ih; exact ih _ (by omega)

private theorem r31 : Row 262144 23547 354294 31828 := stepRow (e := 177147) (f := 15914) (by intro t; unfold C; split <;> omega) r30

private theorem r32 : Row 1048576 154619 1417176 208975 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r33 : Row 1048576 678907 2125764 1376345 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inr (by omega)))

private theorem r34 : Row 1048576 678907 4251528 2752690 := stepRow (e := 2125764) (f := 1376345) (by intro t; unfold C; split <;> omega) r33

private theorem r35 : Row 1048576 678907 1417176 917563 := stepRow (e := 4251528) (f := 2752690) (by intro t; unfold C; split <;> omega) r34

private theorem r36 : Row 524288 154619 708588 208975 := splitRow r32 r35

private theorem r37 : Row 1048576 416763 531441 211226 := by
  intro t h ih; exact ih _ (by omega)

private theorem r38 : Row 1048576 416763 1062882 422452 := stepRow (e := 531441) (f := 211226) (by intro t; unfold C; split <;> omega) r37

private theorem r39 : Row 2097152 941051 1594323 715420 := by
  intro t h ih; exact ih _ (by omega)

private theorem r40 : Row 2097152 941051 3188646 1430840 := stepRow (e := 1594323) (f := 715420) (by intro t; unfold C; split <;> omega) r39

private theorem r41 : Row 2097152 941051 6377292 2861680 := stepRow (e := 3188646) (f := 1430840) (by intro t; unfold C; split <;> omega) r40

private theorem r42 : Row 2097152 941051 2125764 953893 := stepRow (e := 6377292) (f := 2861680) (by intro t; unfold C; split <;> omega) r41

private theorem r43 : Row 4194304 1989627 4251528 2016775 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r44 : Row 16777216 4086779 14348907 3495268 := by
  intro t h ih; exact ih _ (by omega)

private theorem r45 : Row 16777216 4086779 28697814 6990536 := stepRow (e := 14348907) (f := 3495268) (by intro t; unfold C; split <;> omega) r44

private theorem r46 : Row 16777216 4086779 57395628 13981072 := stepRow (e := 28697814) (f := 6990536) (by intro t; unfold C; split <;> omega) r45

private theorem r47 : Row 16777216 4086779 19131876 4660357 := stepRow (e := 57395628) (f := 13981072) (by intro t; unfold C; split <;> omega) r46

private theorem r48 : Row 33554432 12475387 38263752 14226295 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r49 : Row 268435456 29252603 344373768 37527943 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r50 : Row 268435456 163470331 516560652 314572241 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inr (by omega)))

private theorem r51 : Row 268435456 163470331 1033121304 629144482 := stepRow (e := 516560652) (f := 314572241) (by intro t; unfold C; split <;> omega) r50

private theorem r52 : Row 268435456 163470331 344373768 209714827 := stepRow (e := 1033121304) (f := 629144482) (by intro t; unfold C; split <;> omega) r51

private theorem r53 : Row 134217728 29252603 172186884 37527943 := splitRow r49 r52

private theorem r54 : Row 134217728 96361467 129140163 92716039 := by
  intro t h ih; exact ih _ (by omega)

private theorem r55 : Row 134217728 96361467 258280326 185432078 := stepRow (e := 129140163) (f := 92716039) (by intro t; unfold C; split <;> omega) r54

private theorem r56 : Row 134217728 96361467 516560652 370864156 := stepRow (e := 258280326) (f := 185432078) (by intro t; unfold C; split <;> omega) r55

private theorem r57 : Row 134217728 96361467 172186884 123621385 := stepRow (e := 516560652) (f := 370864156) (by intro t; unfold C; split <;> omega) r56

private theorem r58 : Row 67108864 29252603 86093442 37527943 := splitRow r53 r57

private theorem r59 : Row 67108864 62807035 43046721 40287332 := by
  intro t h ih; exact ih _ (by omega)

private theorem r60 : Row 67108864 62807035 86093442 80574664 := stepRow (e := 43046721) (f := 40287332) (by intro t; unfold C; split <;> omega) r59

private theorem r61 : Row 33554432 29252603 43046721 37527943 := splitRow r58 r60

private theorem r62 : Row 33554432 29252603 86093442 75055886 := stepRow (e := 43046721) (f := 37527943) (by intro t; unfold C; split <;> omega) r61

private theorem r63 : Row 33554432 29252603 172186884 150111772 := stepRow (e := 86093442) (f := 75055886) (by intro t; unfold C; split <;> omega) r62

private theorem r64 : Row 33554432 29252603 57395628 50037257 := stepRow (e := 172186884) (f := 150111772) (by intro t; unfold C; split <;> omega) r63

private theorem r65 : Row 33554432 29252603 114791256 100074514 := stepRow (e := 57395628) (f := 50037257) (by intro t; unfold C; split <;> omega) r64

private theorem r66 : Row 33554432 29252603 38263752 33358171 := stepRow (e := 114791256) (f := 100074514) (by intro t; unfold C; split <;> omega) r65

private theorem r67 : Row 16777216 12475387 19131876 14226295 := splitRow r48 r66

private theorem r68 : Row 8388608 4086779 9565938 4660357 := splitRow r47 r67

private theorem r69 : Row 8388608 8281083 4782969 4721663 := by
  intro t h ih; exact ih _ (by omega)

private theorem r70 : Row 8388608 8281083 9565938 9443326 := stepRow (e := 4782969) (f := 4721663) (by intro t; unfold C; split <;> omega) r69

private theorem r71 : Row 4194304 4086779 4782969 4660357 := splitRow r68 r70

private theorem r72 : Row 4194304 4086779 9565938 9320714 := stepRow (e := 4782969) (f := 4660357) (by intro t; unfold C; split <;> omega) r71

private theorem r73 : Row 4194304 4086779 19131876 18641428 := stepRow (e := 9565938) (f := 9320714) (by intro t; unfold C; split <;> omega) r72

private theorem r74 : Row 4194304 4086779 6377292 6213809 := stepRow (e := 19131876) (f := 18641428) (by intro t; unfold C; split <;> omega) r73

private theorem r75 : Row 4194304 4086779 12754584 12427618 := stepRow (e := 6377292) (f := 6213809) (by intro t; unfold C; split <;> omega) r74

private theorem r76 : Row 4194304 4086779 4251528 4142539 := stepRow (e := 12754584) (f := 12427618) (by intro t; unfold C; split <;> omega) r75

private theorem r77 : Row 2097152 1989627 2125764 2016775 := splitRow r43 r76

private theorem r78 : Row 1048576 941051 1062882 953893 := splitRow r42 r77

private theorem r79 : Row 524288 416763 531441 422452 := splitRow r38 r78

private theorem r80 : Row 524288 416763 1062882 844904 := stepRow (e := 531441) (f := 422452) (by intro t; unfold C; split <;> omega) r79

private theorem r81 : Row 524288 416763 2125764 1689808 := stepRow (e := 1062882) (f := 844904) (by intro t; unfold C; split <;> omega) r80

private theorem r82 : Row 524288 416763 708588 563269 := stepRow (e := 2125764) (f := 1689808) (by intro t; unfold C; split <;> omega) r81

private theorem r83 : Row 262144 154619 354294 208975 := splitRow r36 r82

private theorem r84 : Row 131072 23547 177147 31828 := splitRow r31 r83

private theorem r85 : Row 131072 23547 354294 63656 := stepRow (e := 177147) (f := 31828) (by intro t; unfold C; split <;> omega) r84

private theorem r86 : Row 131072 23547 708588 127312 := stepRow (e := 354294) (f := 63656) (by intro t; unfold C; split <;> omega) r85

private theorem r87 : Row 131072 23547 236196 42437 := stepRow (e := 708588) (f := 127312) (by intro t; unfold C; split <;> omega) r86

private theorem r88 : Row 131072 23547 472392 84874 := stepRow (e := 236196) (f := 42437) (by intro t; unfold C; split <;> omega) r87

private theorem r89 : Row 131072 23547 157464 28291 := stepRow (e := 472392) (f := 84874) (by intro t; unfold C; split <;> omega) r88

private theorem r90 : Row 131072 89083 157464 107023 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r91 : Row 65536 23547 78732 28291 := splitRow r89 r90

private theorem r92 : Row 65536 56315 59049 50743 := by
  intro t h ih; exact ih _ (by omega)

private theorem r93 : Row 65536 56315 118098 101486 := stepRow (e := 59049) (f := 50743) (by intro t; unfold C; split <;> omega) r92

private theorem r94 : Row 65536 56315 236196 202972 := stepRow (e := 118098) (f := 101486) (by intro t; unfold C; split <;> omega) r93

private theorem r95 : Row 65536 56315 78732 67657 := stepRow (e := 236196) (f := 202972) (by intro t; unfold C; split <;> omega) r94

private theorem r96 : Row 32768 23547 39366 28291 := splitRow r91 r95

private theorem r97 : Row 16384 7163 19683 8608 := splitRow r29 r96

private theorem r98 : Row 16384 7163 39366 17216 := stepRow (e := 19683) (f := 8608) (by intro t; unfold C; split <;> omega) r97

private theorem r99 : Row 16384 7163 78732 34432 := stepRow (e := 39366) (f := 17216) (by intro t; unfold C; split <;> omega) r98

private theorem r100 : Row 16384 7163 26244 11477 := stepRow (e := 78732) (f := 34432) (by intro t; unfold C; split <;> omega) r99

private theorem r101 : Row 16384 7163 52488 22954 := stepRow (e := 26244) (f := 11477) (by intro t; unfold C; split <;> omega) r100

private theorem r102 : Row 16384 7163 17496 7651 := stepRow (e := 52488) (f := 22954) (by intro t; unfold C; split <;> omega) r101

private theorem r103 : Row 16384 15355 17496 16399 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r104 : Row 8192 7163 8748 7651 := splitRow r102 r103

private theorem r105 : Row 4096 3067 4374 3277 := splitRow r27 r104

private theorem r106 : Row 2048 1019 2187 1090 := splitRow r23 r105

private theorem r107 : Row 2048 1019 4374 2180 := stepRow (e := 2187) (f := 1090) (by intro t; unfold C; split <;> omega) r106

private theorem r108 : Row 2048 1019 8748 4360 := stepRow (e := 4374) (f := 2180) (by intro t; unfold C; split <;> omega) r107

private theorem r109 : Row 2048 1019 2916 1453 := stepRow (e := 8748) (f := 4360) (by intro t; unfold C; split <;> omega) r108

private theorem r110 : Row 4096 2043 5832 2911 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r111 : Row 4096 4091 8748 8741 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inr (by omega)))

private theorem r112 : Row 4096 4091 17496 17482 := stepRow (e := 8748) (f := 8741) (by intro t; unfold C; split <;> omega) r111

private theorem r113 : Row 4096 4091 5832 5827 := stepRow (e := 17496) (f := 17482) (by intro t; unfold C; split <;> omega) r112

private theorem r114 : Row 2048 2043 2916 2911 := splitRow r110 r113

private theorem r115 : Row 1024 1019 1458 1453 := splitRow r109 r114

private theorem r116 : Row 512 507 729 724 := splitRow r21 r115

private theorem r117 : Row 512 507 1458 1448 := stepRow (e := 729) (f := 724) (by intro t; unfold C; split <;> omega) r116

private theorem r118 : Row 512 507 2916 2896 := stepRow (e := 1458) (f := 1448) (by intro t; unfold C; split <;> omega) r117

private theorem r119 : Row 512 507 972 965 := stepRow (e := 2916) (f := 2896) (by intro t; unfold C; split <;> omega) r118

private theorem r120 : Row 512 507 1944 1930 := stepRow (e := 972) (f := 965) (by intro t; unfold C; split <;> omega) r119

private theorem r121 : Row 512 507 648 643 := stepRow (e := 1944) (f := 1930) (by intro t; unfold C; split <;> omega) r120

private theorem r122 : Row 256 251 324 319 := splitRow r19 r121

private theorem r123 : Row 128 123 162 157 := splitRow r18 r122

private theorem r124 : Row 64 59 81 76 := splitRow r14 r123

private theorem r125 : Row 64 59 162 152 := stepRow (e := 81) (f := 76) (by intro t; unfold C; split <;> omega) r124

private theorem r126 : Row 64 59 324 304 := stepRow (e := 162) (f := 152) (by intro t; unfold C; split <;> omega) r125

private theorem r127 : Row 64 59 108 101 := stepRow (e := 324) (f := 304) (by intro t; unfold C; split <;> omega) r126

private theorem r128 : Row 64 59 216 202 := stepRow (e := 108) (f := 101) (by intro t; unfold C; split <;> omega) r127

private theorem r129 : Row 64 59 72 67 := stepRow (e := 216) (f := 202) (by intro t; unfold C; split <;> omega) r128

private theorem r130 : Row 32 27 36 31 := splitRow r12 r129

private theorem r131 : Row 16 11 18 13 := splitRow r11 r130

private theorem r132 : Row 8 3 9 4 := splitRow r7 r131

private theorem r133 : Row 8 3 18 8 := stepRow (e := 9) (f := 4) (by intro t; unfold C; split <;> omega) r132

private theorem r134 : Row 8 3 36 16 := stepRow (e := 18) (f := 8) (by intro t; unfold C; split <;> omega) r133

private theorem r135 : Row 8 3 12 5 := stepRow (e := 36) (f := 16) (by intro t; unfold C; split <;> omega) r134

private theorem r136 : Row 8 3 24 10 := stepRow (e := 12) (f := 5) (by intro t; unfold C; split <;> omega) r135

private theorem r137 : Row 8 3 8 3 := stepRow (e := 24) (f := 10) (by intro t; unfold C; split <;> omega) r136

private theorem r138 : Row 8 7 8 7 := by
  intro t _ _; exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem r139 : Row 4 3 4 3 := splitRow r137 r138

private theorem r140 : Row 2 1 2 1 := splitRow r5 r139

private theorem r141 : Row 1 0 1 0 := splitRow r1 r140

theorem hits_first_target (n : Nat) : Hits FirstTarget n := by
  induction n using Nat.strongRecOn with
  | ind n ih =>
    by_cases h : n ≤ 1
    · exact Hits.here (Or.inl h)
    · have aux := r141 n (by simp; omega) (by simpa using ih)
      simpa using aux

def Bad (n : Nat) : Prop := n % 8 = 5 ∨ n % 8 = 7 ∨ n % 23328 = 5825
def SecondTarget (n : Nat) : Prop := n ≤ 1 ∨ Bad n

private theorem follow {P : Nat → Prop} {n m : Nat} (h : C n=m)
    (hm : Hits P m) : Hits P n := Hits.prev (h.symm ▸ hm)

private theorem baseCells {n u : Nat} (hu : u%8 ≠ 0)
    (hn : n+7=729*(8*u)) : Hits SecondTarget n := by
  let t := u/8
  have decomp : u = 8*t + u%8 := by dsimp [t]; omega
  have hr : u%8=1 ∨ u%8=2 ∨ u%8=3 ∨ u%8=4 ∨ u%8=5 ∨ u%8=6 ∨ u%8=7 := by omega
  rcases hr with h|h|h|h|h|h|h
  · have edge : n=46656*t+5825 := by omega
    rw [edge]
    exact Hits.here (Or.inr (Or.inr (Or.inr (by omega))))
  · have edge : n=46656*t+11657 := by omega
    rw [edge]
    apply follow (m := 139968*t+34972) (by unfold C; split <;> omega)
    apply follow (m := 69984*t+17486) (by unfold C; split <;> omega)
    apply follow (m := 34992*t+8743) (by unfold C; split <;> omega)
    exact Hits.here (Or.inr (Or.inr (Or.inl (by omega))))
  · have edge : n=46656*t+17489 := by omega
    rw [edge]
    apply follow (m := 139968*t+52468) (by unfold C; split <;> omega)
    apply follow (m := 69984*t+26234) (by unfold C; split <;> omega)
    apply follow (m := 34992*t+13117) (by unfold C; split <;> omega)
    exact Hits.here (Or.inr (Or.inl (by omega)))
  · have edge : n=46656*t+23321 := by omega
    rw [edge]
    apply follow (m := 139968*t+69964) (by unfold C; split <;> omega)
    apply follow (m := 69984*t+34982) (by unfold C; split <;> omega)
    apply follow (m := 34992*t+17491) (by unfold C; split <;> omega)
    apply follow (m := 104976*t+52474) (by unfold C; split <;> omega)
    apply follow (m := 52488*t+26237) (by unfold C; split <;> omega)
    exact Hits.here (Or.inr (Or.inl (by omega)))
  · have edge : n=46656*t+29153 := by omega
    rw [edge]
    exact Hits.here (Or.inr (Or.inr (Or.inr (by omega))))
  · have edge : n=46656*t+34985 := by omega
    rw [edge]
    apply follow (m := 139968*t+104956) (by unfold C; split <;> omega)
    apply follow (m := 69984*t+52478) (by unfold C; split <;> omega)
    apply follow (m := 34992*t+26239) (by unfold C; split <;> omega)
    exact Hits.here (Or.inr (Or.inr (Or.inl (by omega))))
  · have edge : n=46656*t+40817 := by omega
    rw [edge]
    apply follow (m := 139968*t+122452) (by unfold C; split <;> omega)
    apply follow (m := 69984*t+61226) (by unfold C; split <;> omega)
    apply follow (m := 34992*t+30613) (by unfold C; split <;> omega)
    exact Hits.here (Or.inr (Or.inl (by omega)))

private theorem Bpath {P : Nat → Prop} (t : Nat) (h : Hits P (72*t+65)) : Hits P (64*t+57) := by
  apply follow (m := 192*t+172) (by unfold C; split <;> omega)
  apply follow (m := 96*t+86) (by unfold C; split <;> omega)
  apply follow (m := 48*t+43) (by unfold C; split <;> omega)
  apply follow (m := 144*t+130) (by unfold C; split <;> omega)
  apply follow (m := 72*t+65) (by unfold C; split <;> omega)
  exact h

private theorem decompose (w : Nat) (hw : 0<w) :
    ∃ k v : Nat, v%8 ≠ 0 ∧ w=8^k*v := by
  induction w using Nat.strongRecOn with
  | ind w ih =>
    by_cases hd : w%8=0
    · obtain ⟨k,v,hv,eq⟩ := ih (w/8) (by omega) (by omega)
      refine ⟨k+1,v,hv,?_⟩
      calc w = 8*(w/8) := by omega
           _ = 8*(8^k*v) := by rw [eq]
           _ = 8^(k+1)*v := by rw [Nat.pow_succ]; ac_rfl
    · exact ⟨0,w,hd,by simp⟩

private theorem scale_factors (i j a b c : Nat) :
    a*((b*i*j)*c)=(i*j)*(a*(b*c)) := by ac_rfl

private theorem shift_factors (i j a b c : Nat) :
    a*((b*i)*(j*c))=(i*j)*(a*(b*c)) := by ac_rfl

private theorem zone (k : Nat) : ∀ n v : Nat, v%8 ≠ 0 →
    n+7=729*(8^k*v) → (n+7)%4=0 → Hits SecondTarget n := by
  induction k using Nat.strongRecOn with
  | ind k ih =>
    intro n v hv hn h4
    cases k with
    | zero =>
      simp at hn
      have hv4 : v%4=0 := by rw [hn] at h4; simpa [Nat.mul_mod] using h4
      have hv8 : v%8=4 := by omega
      have h8 : (n+7)%8=4 := by rw [hn]; simp [Nat.mul_mod,hv8]
      exact Hits.here (Or.inr (Or.inl (by omega)))
    | succ j =>
      cases j with
      | zero => apply baseCells hv; simpa using hn
      | succ j =>
        let t := 8^j*v
        have hform : n+7=64*(729*t) := by
          rw [hn]; simp only [Nat.pow_succ]
          exact scale_factors 8 8 729 (8^j) v
        let a := 729*t-1
        have hstart : n=64*a+57 := by dsimp [a]; omega
        have hend : 72*a+65+7=729*(8^(j+1)*(9*v)) := by
          have id : 729*(8^(j+1)*(9*v))=72*(729*t) := by
            rw [Nat.pow_succ]; exact shift_factors 8 9 729 (8^j) v
          rw [id]; dsimp [a]; omega
        have hv' : (9*v)%8 ≠ 0 := by simpa [Nat.mul_mod] using hv
        have hr := ih (j+1) (by omega) (72*a+65) (9*v) hv' hend (by omega)
        rw [hstart]; exact Bpath a hr

private theorem refine_target {n : Nat} (h : FirstTarget n) : Hits SecondTarget n := by
  rcases h with h|h|h
  · exact Hits.here (Or.inl h)
  · exact Hits.here (Or.inr (Or.inr (Or.inl h)))
  · let w := 4*(n/2916+1)
    have heq : n+7=729*w := by dsimp [w]; omega
    obtain ⟨k,v,hv,hw⟩ := decompose w (by dsimp [w]; omega)
    exact zone k n v hv (by rw [←hw]; exact heq) (by omega)

theorem hits_second_target (n : Nat) : Hits SecondTarget n := by
  have h := hits_first_target n
  induction h with
  | here h => exact refine_target h
  | prev _ ih => exact Hits.prev ih

def IsPower (n : Nat) : Prop := ∃ k : Nat, n=2^k

private theorem positive_C {n : Nat} (h : n>0) : C n>0 := by
  unfold C; split <;> omega

private theorem power_closed {n : Nat} (h : IsPower n) : IsPower (C n) := by
  obtain ⟨k,rfl⟩ := h
  cases k with
  | zero => exact ⟨2,by decide⟩
  | succ k =>
    refine ⟨k,?_⟩
    rw [Nat.pow_succ]; unfold C; split <;> omega

private theorem power_safe {n : Nat} (h : IsPower n) : ¬Bad n := by
  obtain ⟨k,rfl⟩ := h
  cases k with
  | zero => unfold Bad; decide
  | succ k => rw [Nat.pow_succ]; unfold Bad; omega

private theorem power_preimage {n : Nat} (safe : ¬Bad n) (power : IsPower (C n)) : IsPower n := by
  obtain ⟨k,h⟩ := power
  unfold C at h
  split at h
  · refine ⟨k+1,?_⟩; rw [Nat.pow_succ]; omega
  · cases k with
    | zero => omega
    | succ k =>
      cases k with
      | zero => omega
      | succ k =>
        cases k with
        | zero => exact ⟨0,by omega⟩
        | succ k =>
          have he : 3*n+1=8*(2^k) := by
            have eq : 2^(k+3)=8*2^k := by
              rw [Nat.pow_add]
              exact Nat.mul_comm _ _
            exact h.trans eq
          unfold Bad at safe; omega

private theorem power_of_safe {n : Nat} (h : Hits SecondTarget n) (hn : n>0)
    (avoid : ¬Hits Bad n) : IsPower n := by
  induction h with
  | @here n h =>
    rcases h with h|h
    · exact ⟨0,by omega⟩
    · exact False.elim (avoid (Hits.here h))
  | @prev n _ ih =>
    apply power_preimage (fun b => avoid (Hits.here b))
    exact ih (positive_C hn) (fun later => avoid (Hits.prev later))

private theorem guards_exclude_powers {n : Nat} (h : Hits Bad n) : ¬IsPower n := by
  induction h with
  | here h => exact fun p => power_safe p h
  | prev _ ih => exact fun p => ih (power_closed p)

theorem avoids_three_classes_iff_power (n : Nat) (positive : n>0) :
    (¬Hits Bad n) ↔ IsPower n := by
  constructor
  · exact power_of_safe (hits_second_target n) positive
  · exact fun p hits => guards_exclude_powers hits p

def orbit (n : Nat) : Nat → Nat
  | 0 => n
  | k+1 => orbit (C n) k

theorem hits_iff {P : Nat → Prop} {n : Nat} : Hits P n ↔ ∃ k, P (orbit n k) := by
  constructor
  · intro h
    induction h with
    | here hp => exact ⟨0,hp⟩
    | prev _ ih => obtain ⟨k,hk⟩ := ih; exact ⟨k+1,hk⟩
  · rintro ⟨k,hk⟩
    induction k generalizing n with
    | zero => exact Hits.here hk
    | succ k ih => exact Hits.prev (ih hk)

private theorem orbit_pos {n : Nat} (hn : n>0) (k : Nat) : orbit n k>0 := by
  induction k generalizing n with
  | zero => exact hn
  | succ k ih => exact ih (positive_C hn)

theorem reaches_one_or_one_of_two_classes (n : Nat) (positive : n>0) :
    ∃ k, orbit n k=1 ∨ orbit n k%8=7 ∨ orbit n k%2916=2909 := by
  obtain ⟨k,hk⟩ := hits_iff.mp (hits_first_target n)
  refine ⟨k,?_⟩
  rcases hk with h|h
  · have hpos := orbit_pos positive k; exact Or.inl (by omega)
  · exact Or.inr h

theorem exact_positive_avoidance (n : Nat) (positive : n>0) :
    (∀ k, orbit n k%8≠5 ∧ orbit n k%8≠7 ∧ orbit n k%23328≠5825) ↔
      ∃ j : Nat, n=2^j := by
  change (∀ k, orbit n k%8≠5 ∧ orbit n k%8≠7 ∧ orbit n k%23328≠5825) ↔ IsPower n
  rw [←avoids_three_classes_iff_power n positive, hits_iff]
  constructor
  · intro condition ⟨k,hk⟩
    obtain ⟨h5,h7,h5825⟩ := condition k
    rcases hk with eq|eq|eq <;> contradiction
  · intro h k
    exact ⟨fun eq => h ⟨k,Or.inl eq⟩, fun eq => h ⟨k,Or.inr (Or.inl eq)⟩,
      fun eq => h ⟨k,Or.inr (Or.inr eq)⟩⟩

#print axioms reaches_one_or_one_of_two_classes
#print axioms exact_positive_avoidance
end Census
