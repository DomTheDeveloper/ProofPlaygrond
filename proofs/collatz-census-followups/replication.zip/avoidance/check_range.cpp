// g++ -O3 -std=c++17 check_range.cpp -o check_range
// ./check_range 48 32 20    (map ID, log2 range, base-digit sieve depth)
// Cover every start 1..2^log2_range inclusive, capped at UINT64_MAX for 64 bits.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using wide = unsigned __int128;

template<int id> constexpr unsigned base() { return id == 51 ? 3 : 2; }
template<int id> constexpr unsigned guard() {
    return id == 52 ? 32 : id == 51 ? 3 : 4;
}
template<int id> unsigned numerator(unsigned residue) {
    if (residue % base<id>() == 0) return 1;
    if constexpr (id == 51) return residue % 3 == 1 ? 4 : 2;
    if constexpr (id == 52) return residue == 19 || residue == 27 || residue == 31 ? 1 : 3;
    return residue % 4 == 1 ? (id == 48 ? 5 : 7) : 1;
}
template<int id> unsigned addition(unsigned residue) {
    if (residue % base<id>() == 0) return 0;
    if constexpr (id == 51) return residue % 3 == 1 ? 5 : 2;
    return 1;
}
template<int id, typename T> T single_step(T n) {
    unsigned residue = n % guard<id>();
    unsigned a = numerator<id>(residue), b = addition<id>(residue);
    if (n > (std::numeric_limits<T>::max() - b) / a)
        throw std::overflow_error("unchecked numerator");
    return (a*n + b) / base<id>();
}
template<int id, typename T> bool known(T n) {
    if constexpr (id == 48) return n == 1 || n == 13;
    if constexpr (id == 51) return n == 1 || n == 2 || n == 16;
    return n == 1;
}
template<int id> void check_cycles() {
    for (u64 m : {1, 2, 13, 16}) {
        if (!known<id>(m)) continue;
        std::set<u64> values;
        u64 x = m;
        do {
            if (!values.insert(x).second || values.size() > 500)
                throw std::logic_error("cycle representative does not return");
            x = single_step<id>(x);
        } while (x != m);
        if (*values.begin() != m) throw std::logic_error("incorrect minimum");
    }
}
template<int id> unsigned finish(u64 seed, wide x) {
    unsigned steps = 0;
    constexpr u64 fast_limit = std::numeric_limits<u64>::max() / 8;
    while (x >= seed && !known<id>(x)) {
        if (x < fast_limit) {
            u64 small = static_cast<u64>(x);
            do {
                small = single_step<id>(small);
                if (++steps > 20000) throw std::runtime_error("unresolved seed " + std::to_string(seed));
            } while (small >= seed && small < fast_limit && !known<id>(small));
            x = small;
        } else {
            x = single_step<id>(x);
            if (++steps > 20000) throw std::runtime_error("unresolved seed " + std::to_string(seed));
        }
    }
    return steps;
}
template<int id> void verify(unsigned bits, unsigned depth) {
    check_cycles<id>();
    if (bits > 55 || depth > 25 || !depth) throw std::invalid_argument("parameter out of range");
    u64 limit = u64(1) << bits, modulus = 1;
    for (unsigned j = 0; j < depth; ++j) modulus *= base<id>();
    u64 total = 0, individual = 0, unresolved_classes = 0;
    unsigned longest = 0;
    // A class is n=modulus*t+r. Current iterate is a*t+b, with t>=0.
    for (u64 r=0; r<modulus && r<=limit; ++r) {
        u64 low = r==0 ? 1 : 0, high = (limit-r)/modulus;
        if (high < low) continue;
        total += high-low+1;
        u64 a=modulus, b=r;
        for (;;) {
            if (a<modulus || (a==modulus && b<r)) {
                if (b<r) { low=1;high=0; }
                else high=std::min(high,(b-r)/(modulus-a));
                break;
            }
            if (a % base<id>() != 0) { ++unresolved_classes; break; }
            unsigned residue=b%guard<id>();
            if (residue%base<id>() && a%guard<id>()) { ++unresolved_classes; break; }
            unsigned p=numerator<id>(residue), c=addition<id>(residue);
            wide aa=wide(a)*p, bb=wide(b)*p+c;
            if (aa%base<id>() || bb%base<id>()) throw std::logic_error("illegal class branch");
            aa/=base<id>();bb/=base<id>();
            if (aa>std::numeric_limits<u64>::max() || bb>std::numeric_limits<u64>::max())
                throw std::overflow_error("class coefficients too large");
            a=u64(aa);b=u64(bb);
        }
        for (u64 t=low; t<=high; ++t) {
            u64 seed=modulus*t+r;
            longest=std::max(longest,finish<id>(seed,wide(a)*t+b));
            ++individual;
        }
    }
    if (total!=limit) throw std::logic_error("incomplete coverage");
    std::cout << "CLS-" << id << " range=" << total << " modulus=" << modulus
              << " undecided_classes=" << unresolved_classes << " individual=" << individual
              << " max_extra_steps=" << longest << std::endl;
}
// Adaptive version. Split a residue class only when another input digit is
// needed. The pair (a,b) always describes the current iterate of D*t+r.
template<int id> struct Adaptive {
    u64 limit, total=0, individual=0, nodes=0;
    unsigned longest=0;
    void visit(u64 D,u64 r,wide a,wide b) {
        if (r>limit) return;
        u64 low=r==0 ? 1 : 0, high=(limit-r)/D;
        if (high<low) return;
        ++nodes;
        for (;;) {
            if (a<D || (a==D && b<r)) {
                total+=high-low+1;
                if (b<r) return;
                wide threshold=(b-r)/(D-a);
                if (threshold<high) high=u64(threshold);
                break;
            }
            unsigned residue=b%guard<id>();
            if (a%base<id>() || (residue%base<id>() && a%guard<id>())) {
                if (high-low<63) { total+=high-low+1; break; }
                constexpr unsigned g=base<id>();
                if (a>(std::numeric_limits<wide>::max()-b)/g)
                    throw std::overflow_error("adaptive split coefficients");
                for (unsigned d=0;d<g;++d)
                    visit(g*D,r+d*D,g*a,b+d*a);
                return;
            }
            unsigned p=numerator<id>(residue), c=addition<id>(residue);
            if (std::max(a,b)>(std::numeric_limits<wide>::max()-c)/p)
                throw std::overflow_error("adaptive affine image");
            a=a*p/base<id>(); b=(b*p+c)/base<id>();
        }
        for (u64 t=low;t<=high;++t) {
            if (t && a>(std::numeric_limits<wide>::max()-b)/t)
                throw std::overflow_error("adaptive endpoint");
            longest=std::max(longest,finish<id>(D*t+r,a*t+b));
            ++individual;
        }
    }
    explicit Adaptive(unsigned bits) {
        if (!bits || bits>64) throw std::invalid_argument("range bits must be 1..64");
        check_cycles<id>();
        limit = bits == 64 ? std::numeric_limits<u64>::max() : u64(1)<<bits;
        visit(1,0,1,0);
        if(total!=limit)throw std::logic_error("incomplete adaptive coverage");
        std::cout<<"CLS-"<<id<<" range="<<total<<" adaptive_nodes="<<nodes
                 <<" individual="<<individual<<" max_extra_steps="<<longest<<std::endl;
    }
};
template<int id> void run(unsigned bits,unsigned depth) {
    if(depth) verify<id>(bits,depth); else { Adaptive<id> check{bits}; }
}
int main(int argc,char** argv) {
    if (argc!=4) throw std::invalid_argument("arguments: map_id range_bits sieve_digits");
    unsigned bits=std::stoul(argv[2]), depth=std::stoul(argv[3]);
    switch (std::stoi(argv[1])) {
        case 48: run<48>(bits,depth); break;
        case 51: run<51>(bits,depth); break;
        case 52: run<52>(bits,depth); break;
        case 53: run<53>(bits,depth); break;
        default: throw std::invalid_argument("unknown map");
    }
}
