"""Independent raw-rule and avoidance checks. Python 3, standard library only."""
from fractions import Fraction
from itertools import product


def raw(n, which):
    if which == 51:
        r = n % 3
        if r == 0:
            return n // 3
        return 4*n + 5 if r == 1 else 2*n + 2
    if n % 2 == 0:
        return n // 2
    if which == 52:
        return n+1 if n % 32 in (19,27,31) else 3*n+1
    if which in (48,53):
        return ((5 if which == 48 else 7)*n + 1) if n % 4 == 1 else n+1
    return 3*n+1


def direct_range(which, bound):
    solved, cycles = {}, {}
    for start in range(1, bound+1):
        if start in solved:
            continue
        local, order = {}, []
        x = start
        while x not in solved and x not in local:
            local[x] = len(order)
            order.append(x)
            assert len(order) < 20000
            x = raw(x, which)
        if x in solved:
            minimum = solved[x]
        else:
            loop = order[local[x]:]
            minimum = min(loop)
            prime = 3 if which == 51 else 2
            accelerated = [n for n in loop if n % prime]
            rises = [accelerated[(j+1)%len(accelerated)] > n
                     for j,n in enumerate(accelerated)]
            runs = sum(flag and not rises[j-1] for j,flag in enumerate(rises))
            cycles[minimum] = (len(loop),runs)
        for x in order:
            solved[x] = minimum
    return dict(sorted(cycles.items()))


def down_return(n, forbid5=False):
    """Use the original 3n+1 iterations, stopping on first forbidden input."""
    assert n % 4 == 1
    x = n
    for j in range(100):
        if x % 8 == 7 or (forbid5 and x % 8 == 5):
            return None
        if j and x % 4 == 1:
            return x
        x = raw(x, 0)
    raise AssertionError("failed to return to a down state")


def avoidance():
    for n in range(1, 2**17, 4):
        y = down_return(n)
        if y is not None:
            if n % 32 == 25:
                assert 8*y == 9*n+7
            else:
                assert 4*y <= 3*n+1
        z = down_return(n, True)
        if n % 32 == 1:
            assert z is not None and 4*z == 3*n+1
        elif n % 64 == 57:
            assert z is not None and 8*z == 9*n+7
        else:
            assert z is None
    for t in range(400):
        x = 2041+2048*t
        for _ in range(3):
            assert x % 32 == 25
            x = down_return(x)
        assert x == 2909+2916*t
        x = 4089+16384*t
        for _ in range(3):
            assert x % 64 == 57
            x = down_return(x, True)
        assert x == 5825+23328*t and x % 32 == 1
        assert raw(x,0) == 17476+69984*t


def classify_words():
    aa,bb=Fraction(3,4),Fraction(9,8)
    good={"A","B","BB","BBB","AB","ABB","ABBB","BA","BBA","BBBA"}
    for length in range(1,12):
        for chars in product("AB",repeat=length):
            w="".join(chars)
            if w in good:
                continue
            if w.count("A") >= 2:
                period="A"+"B"*max(3,length+1)
            elif w.count("A")==1 and w[0]=="B" and w[-1]=="B":
                period="AA"+"B"*5
            else:
                period="A"+"B"*3
            assert aa**period.count("A")*bb**period.count("B") > 1
            assert w not in period*(2+length)


if __name__=="__main__":
    expected={48:{1:(5,1),13:(35,4)},51:{1:(3,0),2:(2,0),16:(4,1)},
              52:{1:(3,0)},53:{1:(4,0)}}
    for index, ans in expected.items():
        found=direct_range(index,200000)
        assert found==ans,(index,found,ans)
        print(index,found)
    avoidance()
    classify_words()
    print("Raw maps, return branches, congruence witnesses and pattern checks passed.")
