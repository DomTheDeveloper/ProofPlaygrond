"""Exact rational proof of bounds on the number of increasing runs.

The range hypotheses are supplied by check_range.cpp and, for map 56,
by Barina's published ordinary-Collatz verification through 2^71.
Run with Python 3. Use --ranges followed by five bit counts to test alternative ranges.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import cache
from math import ceil, floor
import argparse


@cache
def unit_log(x):
    assert 1 <= x <= 2
    z = (x-1)/(x+1)
    term, total = z, F(0)
    for j in range(190):
        total += 2*term/(2*j+1)
        term *= z*z
    return total, total + 2*term/(381*(1-z*z))


@cache
def log_interval(value):
    x = F(value)
    assert x >= 1
    exponent = x.numerator.bit_length() - x.denominator.bit_length()
    if F(2)**exponent > x:
        exponent -= 1
    a, b = unit_log(x/F(2)**exponent)
    lo2, hi2 = unit_log(F(2))
    scale = 10**145
    return (F(floor((a+exponent*lo2)*scale),scale),
            F(ceil((b+exponent*hi2)*scale),scale))


def coarse_log_upper(x):
    # An error below ln 2 suffices here, including for very large x.
    x = F(x)
    assert x >= 1
    e = x.numerator.bit_length() - x.denominator.bit_length()
    if F(2)**e < x:
        e += 1
    return e*log_interval(2)[1]


@dataclass(frozen=True)
class System:
    p: int
    q: int
    rise: F
    divisor: int
    gamma_upper: F
    count_factor: int
    gap_factor: int
    bits: int


SYSTEMS = {
    48: System(2, 5, F(5,2), 2, F(2322,1000), 1, 1, 37),
    51: System(3, 2, F(4,3), 3, F(1262,1000), 4, 7, 46),
    52: System(2, 3, F(3,2), 2, F(1585,1000), 3, 2, 64),
    53: System(2, 7, F(7,4), 4, F(1404,1000), 6, 2, 49),
    56: System(2, 3, F(9,8), 8, F(1057,1000), 3, 8, 71),
}


def farey_bracket(x, cap):
    # Neighboring fractions in the sequence of order cap, using Euclid.
    n, d = x.numerator, x.denominator
    a, b, c, e = 0, 1, 1, 0
    while d:
        k, rem = divmod(n, d)
        if b+k*e > cap:
            break
        a, b, c, e = c, e, a+k*c, b+k*e
        n, d = d, rem
    if not d:
        raise ArithmeticError("increase logarithm precision")
    k = (cap-b)//e
    left, right = sorted((F(a+k*c,b+k*e),F(c,e)))
    assert left.denominator <= cap and right.denominator <= cap
    assert left.denominator+right.denominator > cap
    assert right.numerator*left.denominator-left.numerator*right.denominator == 1
    return left, right


def certify(index, runs, bits=None):
    s=SYSTEMS[index]
    lo_p, hi_p=log_interval(s.p)
    lo_q, hi_q=log_interval(s.q)
    alpha_lo, alpha_hi=lo_q/hi_p, hi_q/lo_p
    # For the published limit the minimum is at least 2^71. The weaker
    # m >= 2^bits is used uniformly, including for the four inclusive checks.
    min_value = 2**(bits or s.bits)
    assert min_value>=100
    delta_top=F(s.gap_factor*runs, min_value-2)
    assert (hi_q+F(s.gap_factor,98))/lo_p<4
    assert F(7,5)*30**5*23*hi_p*hi_q<2*10**9
    lo_rise,hi_rise=log_interval(s.rise)
    assert 1+hi_rise/log_interval(s.divisor)[0]<s.gamma_upper
    coefficient=ceil(s.count_factor*(s.gamma_upper**runs-1)/lo_rise) if index!=52 else None
    if index==52:
        # Each of the K rising triple steps contributes one halving.
        # Every other triple step contributes at least two. Also K <= 3*r.
        cap=floor((3*runs+delta_top/lo_p)/(2-alpha_hi))
    else:
        cap=10**48
        growth=coarse_log_upper(3*(9+s.gap_factor*runs))
        assert coefficient*(growth+2*10**9*(1+coarse_log_upper(4*cap)))<cap
    history=[]
    for _ in range(24):
        lower,upper=farey_bracket((alpha_lo+alpha_hi)/2,cap)
        assert lower<alpha_lo<alpha_hi<upper
        gap=lo_p*(upper.numerator-upper.denominator*alpha_hi)
        assert gap>0
        history.append((cap,lower,upper,gap))
        if gap>delta_top:
            return True,history
        if index==52:
            break
        new_cap=ceil(coefficient*coarse_log_upper(3*(9+s.gap_factor*runs/gap)))
        if new_cap>=cap:
            break
        cap=new_cap
    return False,history


def feasible_range(index, bits):
    low,high=0,2
    while certify(index,high,bits)[0]:
        low,high=high,high*2
    while high-low>1:
        mid=(high+low)//2
        if certify(index,mid,bits)[0]:
            low=mid
        else:
            high=mid
    return low


def check_elementary_constants():
    # Uniform rise and fall bounds at n>=100 for the four nontrivial cases.
    configs=[
        (F(4,3)+F(5,300),max(F(4,9)+F(5,900),F(2,3)+F(2,300)),1),
        (F(3,2)+F(1,200),max(F(3,4)+F(1,400),F(1,4)+F(1,400)),2),
        (F(7,4)+F(1,400),max(F(7,8)+F(1,800),F(1,4)+F(1,400)),5),
        (F(9,8)+F(7,800),F(3,4)+F(1,400),1),
    ]
    for rise,fall,power in configs:
        assert rise*fall**power<1


if __name__=="__main__":
    args=argparse.ArgumentParser()
    args.add_argument("--ranges",nargs=5,type=int)
    args=args.parse_args()
    expected = {48:24, 51:82, 52:911258916, 53:67, 56:581}
    check_elementary_constants()
    for i,(index,s) in enumerate(SYSTEMS.items()):
        bits=args.ranges[i] if args.ranges else s.bits
        runs=feasible_range(index,bits)
        success,hist=certify(index,runs,bits)
        assert success
        if args.ranges is None:
            assert runs == expected[index]
        cap,lower,upper,gap=hist[-1]
        print(f"CLS-{index:03d}   m >= 2^{bits}   at most {runs:,} runs ruled out")
        print("    J caps", [x[0] for x in hist])
        print("    Farey bounds", lower, upper)
