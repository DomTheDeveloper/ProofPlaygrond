#include <array>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include <utility>
using U=uint64_t;
U swap9(U n){return n%18==9 ? n+1 : n%18==10 ? n-1 : n;}
U R(U n){n=swap9(n);U q=n/3;return n%3==0?2*q:n%3==1?4*q+1:4*q+3;}
U I(U n){U x=n%2==0?3*(n/2):n%4==1?3*(n/4)+1:3*(n/4)+2;return swap9(x);}
struct Trie {int child[2]={-1,-1},label=0;};
std::vector<Trie> trie(1);
void add(U n,int label){
 int digits[64],len=0;
 while(n>1){digits[len++]=n%2;n/=2;}
 int idx=0;
 while(len){int c=digits[--len];int next=trie[idx].child[c];
 if(next<0){next=trie.size();trie[idx].child[c]=next;trie.emplace_back();}
 idx=next;}
 trie[idx].label|=label;
}
int k,d[20][2],allowed[20],trie_states[10000];
U count_all=0, count_consistent=0,count_small=0;
int label(U n){int v=0;for(int j=62-__builtin_clzll(n);j>=0;--j)v=d[v][(n>>j)&1];return v;}
void test(){
 ++count_all;
 int yes=0,no=0;
 trie_states[0]=0;
 for(int i=0;i<(int)trie.size();++i){
 int q=trie_states[i];auto &t=trie[i];
 if(t.label&1)yes|=1<<q;
 if(t.label&2)no|=1<<q;
 if(yes&no)return;
 for(int c=0;c<2;++c)if(t.child[c]>=0)trie_states[t.child[c]]=d[q][c];
 }
 ++count_consistent;
 for(int s=0;s<k;s++)allowed[s]=1<<s;
 for(U n=1;n<=2400;n++){allowed[label(n)]|=1<<label(R(n));}
 for(int t=0;t<k;t++)for(int s=0;s<k;s++)if(allowed[s]&(1<<t))allowed[s]|=allowed[t];
 int sup=yes;for(int s=0;s<k;s++)if(yes&(1<<s))sup|=allowed[s];
 if(sup&no)return;
 ++count_small;
 for(int m=0;m<1<<k;m++){
 if((m&sup)!=sup || (m&no))continue;
 int cl=m;for(int s=0;s<k;s++)if(m&(1<<s))cl|=allowed[s];
 if(cl==m){std::printf("candidate %d",m);for(int s=0;s<k;s++)std::printf(" %d %d",d[s][0],d[s][1]);std::puts("");}
 }
}
void enumerate(int idx,int states){
 if(idx==2*k){if(states==k)test();return;}
 if(idx>=2*states || k-states>2*k-idx)return;
 for(int s=0;s<states+(states<k);s++){
 d[idx/2][idx%2]=s;enumerate(idx+1,states+(s==states));
 }
}
int main(int argc,char**argv){
 if(argc!=2)return 1;k=atoi(argv[1]);if(k<1||k>8)return 1;
 U f=8,b=8;add(8,2);
 for(int j=0;j<96;++j){f=R(f);b=I(b);add(f,1);add(b,2);if(f>(1ULL<<58)||b>(1ULL<<58))break;}
 std::fprintf(stderr,"trie %zu\n",trie.size());enumerate(0,1);
 std::printf("k=%d graphs=%llu orbit-consistent=%llu finite-closure-consistent=%llu\n",k,(unsigned long long)count_all,(unsigned long long)count_consistent,(unsigned long long)count_small);
}
