#include <gmpxx.h>
#include <cstdio>
int main(){
 constexpr int k=25; unsigned long M=6;
 for(int i=0;i<k;i++)M*=3;
 mpz_class n=8,q;
 for(long j=0;j<10000000;j+=k){
  auto r=mpz_fdiv_q_ui(q.get_mpz_t(),n.get_mpz_t(),M);
  int e=0;
  for(int i=1;i<=k;i++){
   if(r%18==9)++r;else if(r%18==10)--r;
   unsigned long t=r/3;
   switch(r%3){case 0:r=2*t;e+=1;break;case 1:r=4*t+1;e+=2;break;default:r=4*t+3;e+=2;}
   if(q==0 && r==8){printf("RETURN %ld\n",j+i);return 0;}
  }
  n=((q*6)<<e)+r;
  if((j+k)%1000000==0){printf("%ld bits=%zu mod1000000007=%lu\n",j+k,mpz_sizeinbase(n.get_mpz_t(),2),mpz_fdiv_ui(n.get_mpz_t(),1000000007));fflush(stdout);}
 }
}
