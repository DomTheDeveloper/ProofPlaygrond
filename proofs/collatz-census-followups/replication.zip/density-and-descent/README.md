# Verification for the CLS-057 basin densities and CLS-056 descent bounds

The two manuscripts are included as editable Typst sources under `proofs/`. The companion PDFs are CLS057-Basin-Densities.pdf and CLS056-and-Uniform-Descent.pdf. The census snapshot is commit `7d749f4ac5a021a6079efa76f6337bdc22811751` from November 25, 2026.

## CLS-057

The basin-density manuscript proves existence of the three natural densities, computes rigorous enclosing intervals, and proves the residue-class extension. It also proves positive basin density for each cycle in the full family of maps specified in the paper. The convergence arguments are mathematical proofs on pages 2–6. Lean checks the three integer counting statements used to obtain the scalar recurrence and its error bound. The original finite-state classification question was resolved earlier by the census.

The programs use Python's standard library, a C++17 compiler supporting the native 128-bit integer type, and Lean 4.14.0 for the formal checks. Run from the root of the archive.

```sh
g++ -O3 -std=c++17 basin_sums.cpp -o basin_sums
python3 basin_intervals.py q17_1500m.txt
python3 crosscheck.py ./basin_sums
python3 check_words.py
python3 check_residues.py
lean BasinCounts.lean
```

To regenerate the larger integer sum, allow about 1.5 GB for its one-byte-per-input table.

```sh
./basin_sums 1500000000 > new-basin-output.txt
cmp q17_1500m.txt new-basin-output.txt
python3 basin_intervals.py new-basin-output.txt
```

The intervals certified for the cycles of 1 and 5 are [0.628576297, 0.628576317] and [0.312600154, 0.312600174]. The cycle of 17 attracts exactly the positive multiples of 17 and has density 1/17. Output from the smaller 250,000,000 cutoff is included for comparison. The integer sums are deterministic. An independent direct orbit classifier checks the per-input formulas through 48,000.

The file `word-witnesses.txt` gives a positive starting integer for each of the 28,672 possible words of length 12. A, B and X respectively mean the cycles of 1, 5 and 17. The checker evaluates every witness using the original map. Since X occurs exactly once in every 17 positions, the census formula for the number of words is now exact for every length from 1 through 12.

The residue checker groups the infinite branch weights using exact fractions and the eventual periodicity of powers of two modulo the chosen modulus. It checks the uniform stationary measure and all predicted communicating classes in 634 finite matrices covering seven family members. The manuscript proves the result for arbitrary admissible parameters and moduli.

## CLS-056 and almost-everywhere descent

The supplemental manuscript proves convergence through the entire unsigned 128-bit range and a lower bound on the length of a further cycle. It also gives a uniform power-saving descent theorem for eleven census maps. The claim about all positive starts in CLS-056 remains open.

The range verifier uses GNU MP for continuations exceeding native 128-bit arithmetic. On Debian or Ubuntu its development package is `libgmp-dev`. The three integer arguments give the reduced input exponent, prefix precision and suffix precision.

```sh
g++ -O3 -std=c++17 verify_056.cpp -lgmpxx -lgmp -o verify_056
./verify_056 32 20 12
./verify_056 126 99 42
./verify_056 126 97 43
python3 cycle_gap.py
python3 mixed_drift.py
```

Both full runs exhausted every reduced input from 1 through 2^126. The two range files report node counts, direct continuations and arbitrary-precision continuations. The final verifier compares the forward and inverse suffix lists. `cycle_gap.py` bounds the logarithms by rational numbers and checks the Farey neighbors. `mixed_drift.py` builds rational transition matrices and checks the strict exponent inequalities. `verification.txt` records the shorter checks, the Lean axioms and numeric outputs.

## References

- [CLS-057 family sweep and explicitly open follow-up](https://github.com/rain-1/collatz-like-systems/blob/7d749f4ac5a021a6079efa76f6337bdc22811751/census/lhf/q17-family/CLS-057.md#L99-L105)
- [Original census list and numbered questions](https://github.com/rain-1/collatz-like-systems/blob/7d749f4ac5a021a6079efa76f6337bdc22811751/census/open_collatz_systems.txt)
- [Yolcu, Aaronson and Heule, An Automated Approach to the Collatz Conjecture](https://doi.org/10.1007/s10817-022-09658-8)
- [Serfozo, Basics of Applied Stochastic Processes, Chapter 2, Theorem 35](https://www.stat.yale.edu/~jtc5/251/readings/Basics%20of%20Applied%20Stochastic%20Processes_Serfozo.pdf)
