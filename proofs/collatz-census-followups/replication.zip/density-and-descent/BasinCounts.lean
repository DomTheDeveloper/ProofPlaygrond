import Lean

/- The integer identities used in the natural-density proof for CLS-057.
   The hypotheses hold for each of the three 0/1 basin indicators.
   The analytic limit is proved in the accompanying paper. -/
namespace BasinCounts

def T (n : Nat) : Nat :=
  if n % 2 = 0 then n/2 else (n+17*(n%3))/3

def sumFirst (g : Nat → Nat) : Nat → Nat
  | 0 => 0
  | k+1 => sumFirst g k + g k

abbrev allCount (f : Nat → Nat) := sumFirst (fun k => f (k+1))
abbrev oddCount (f : Nat → Nat) := sumFirst (fun k => f (2*k+1))
abbrev Invariant (f : Nat → Nat) := ∀ n, 0<n → f n=f (T n)

private theorem even_step (k : Nat) : T (2*k)=k := by
  unfold T; split <;> omega

private theorem odd1 (k : Nat) : T (6*k+1)=2*(k+3) := by
  unfold T; split <;> omega

private theorem odd3 (k : Nat) : T (6*k+3)=2*k+1 := by
  unfold T; split <;> omega

private theorem odd5 (k : Nat) : T (6*k+5)=2*k+13 := by
  unfold T; split <;> omega

private theorem values (f : Nat → Nat) (hf : Invariant f) (k : Nat) :
    f (6*k+1)=f (k+3) ∧ f (6*k+3)=f (2*k+1) ∧ f (6*k+5)=f (2*k+13) := by
  have h1 := hf (6*k+1) (by omega)
  have h2 := hf (2*(k+3)) (by omega)
  have h3 := hf (6*k+3) (by omega)
  have h5 := hf (6*k+5) (by omega)
  rw [odd1] at h1
  rw [even_step] at h2
  rw [odd3] at h3
  rw [odd5] at h5
  exact ⟨h1.trans h2,h3,h5⟩

theorem even_odd_partition (f : Nat → Nat) (hf : Invariant f) (n : Nat) :
    allCount f n = allCount f (n/2) + oddCount f ((n+1)/2) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    by_cases he : n%2=0
    · have a : (n+1)/2=n/2 := by omega
      have b : (n+1+1)/2=(n+1)/2+1 := by omega
      have c : 2*((n+1)/2)+1=n+1 := by omega
      change allCount f n + f (n+1) = allCount f ((n+1)/2) + oddCount f ((n+1+1)/2)
      rw [b,show oddCount f ((n+1)/2+1)=oddCount f ((n+1)/2)+f (2*((n+1)/2)+1) from rfl,c]
      simp only [a] at ih ⊢
      omega
    · have a : (n+1)/2=n/2+1 := by omega
      have b : (n+1+1)/2=(n+1)/2 := by omega
      have e := hf (n+1) (by omega)
      have t : T (n+1)=n/2+1 := by unfold T; split <;> omega
      rw [t] at e
      change allCount f n + f (n+1) = allCount f ((n+1)/2) + oddCount f ((n+1+1)/2)
      rw [b,a,show allCount f (n/2+1)=allCount f (n/2)+f (n/2+1) from rfl]
      rw [a] at ih
      omega

theorem exact_three_residues (f : Nat → Nat) (hf : Invariant f) (k : Nat) :
    oddCount f (3*k) + allCount f 2 + oddCount f 6 =
      allCount f (k+2) + oddCount f k + oddCount f (k+6) := by
  induction k with
  | zero => simp [sumFirst]
  | succ k ih =>
    obtain ⟨a,b,c⟩ := values f hf k
    have v1 : 2*(3*k)+1=6*k+1 := by omega
    have v2 : 2*(3*k+1)+1=6*k+3 := by omega
    have v3 : 2*(3*k+2)+1=6*k+5 := by omega
    have v4 : 2*(k+6)+1=2*k+13 := by omega
    change oddCount f (3*(k+1)) + allCount f 2 + oddCount f 6 = _
    rw [show 3*(k+1)=3*k+3 by omega]
    change oddCount f (3*k)+f (2*(3*k)+1)+f (2*(3*k+1)+1)+f (2*(3*k+2)+1)+
      allCount f 2+oddCount f 6 =
      allCount f (k+2)+f (k+3)+(oddCount f k+f (2*k+1))+
      (oddCount f (k+6)+f (2*(k+6)+1))
    rw [v1,v2,v3,v4,a,b,c]
    omega

private theorem window (g : Nat → Nat) (bounded : ∀ i, g i ≤ 1) (k d : Nat) :
    sumFirst g k ≤ sumFirst g (k+d) ∧ sumFirst g (k+d) ≤ sumFirst g k+d := by
  induction d with
  | zero => exact ⟨by simp,by simp⟩
  | succ d ih =>
    rw [Nat.add_succ,sumFirst]
    have h := bounded (k+d)
    omega

private theorem odd_window (f : Nat → Nat) (h : ∀ i, f i ≤ 1) {k n : Nat} (le : k≤n) :
    oddCount f k ≤ oddCount f n ∧ oddCount f n ≤ oddCount f k+(n-k) := by
  have a := window (fun i => f (2*i+1)) (fun i => h _) k (n-k)
  rw [show k+(n-k)=n by omega] at a
  exact a

theorem bounded_renewal_error (f : Nat → Nat) (hf : Invariant f)
    (bounded : ∀ n, f n≤1) (n : Nat) :
    let o := oddCount f ((n+1)/2)
    let base := 2*oddCount f ((n/3+1)/2)+allCount f (n/6)
    o ≤ base+11 ∧ base ≤ o+11 := by
  dsimp only
  let k := n/6
  have orig := exact_three_residues f hf k
  have a : allCount f k ≤ allCount f (k+2) ∧ allCount f (k+2) ≤ allCount f k+2 :=
    window (fun i => f (i+1)) (fun i => bounded _) k 2
  have b := @odd_window f bounded k (k+6) (by omega)
  have e1 : allCount f 2 ≤ 2 := (window (fun i => f (i+1)) (fun i => bounded _) 0 2).2
  have e2 : oddCount f 6 ≤ 6 := (window (fun i => f (2*i+1)) (fun i => bounded _) 0 6).2
  have near1 : 3*k ≤ (n+1)/2 ∧ (n+1)/2 ≤ 3*k+3 := by dsimp [k]; omega
  have near2 : k ≤ (n/3+1)/2 ∧ (n/3+1)/2 ≤ k+1 := by dsimp [k]; omega
  have w1 := @odd_window f bounded (3*k) ((n+1)/2) near1.1
  have w2 := @odd_window f bounded k ((n/3+1)/2) near2.1
  change oddCount f ((n+1)/2) ≤ 2*oddCount f ((n/3+1)/2) + allCount f k + 11 ∧
     2*oddCount f ((n/3+1)/2) + allCount f k ≤ oddCount f ((n+1)/2) + 11
  omega

#print axioms even_odd_partition
#print axioms exact_three_residues
#print axioms bounded_renewal_error
end BasinCounts
