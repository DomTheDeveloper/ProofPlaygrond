// Exact stopping check for H(u)=3u/4 at u=0 mod 4 and (9u+1)/8 at u=7 mod 8.
// Build: g++ -O3 -std=c++17 verify_056.cpp -lgmpxx -lgmp -o verify_056
// Run:   ./verify_056 input_bits prefix_bits suffix_bits
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <gmpxx.h>
#include <iostream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using u128 = unsigned __int128;
constexpr u128 MAX128 = ~u128(0);
std::string decimal(u128 n) {
    std::string s;
    do {s.push_back(char('0'+n%10)); n/=10;} while(n);
    std::reverse(s.begin(),s.end());
    return s;
}
mpz_class big(u128 n) {
    mpz_class x;
    mpz_import(x.get_mpz_t(),1,1,sizeof(n),0,0,&n);
    return x;
}
u64 inverse_odd(u64 n) {
    u64 x=1;
    for(unsigned i=0;i<6;++i) x*=2-n*x;
    if(n*x!=1) throw std::logic_error("wrong inverse");
    return x;
}
struct State {
    unsigned bits, threes;
    u128 r,a,b;  // input 2^bits * t + r, current value a*t+b; a=3^threes
    State child(bool use_b) const {
        unsigned cost=use_b?3:2, numerator=use_b?9:3, add=use_b?1:0;
        unsigned divisor=1u<<cost, target=use_b?7:0;
        unsigned digit=((target-unsigned(b))*unsigned(a))&(divisor-1);
        if(bits+cost>=128 || a>(MAX128-b)/divisor || a>MAX128/numerator)
            throw std::overflow_error("symbolic class");
        u128 old_at_digit=a*digit+b;
        if(old_at_digit>(MAX128-add)/numerator)throw std::overflow_error("symbolic offset");
        u128 image=numerator*old_at_digit+add;
        if(image%divisor!=0 || (old_at_digit%divisor)!=target)
            throw std::logic_error("bad symbolic branch");
        return {bits+cost,threes+(use_b?2u:1u),r+(u128(digit)<<bits),a*numerator,image/divisor};
    }
};

struct Suffix {
    unsigned bits;
    u64 mod;
    std::vector<u64> residues;
    std::map<unsigned,std::vector<u64>> translated;
    explicit Suffix(unsigned k):bits(k), mod(u64(1)<<k) {
        generate({0,0,0,1,0});
        // Rebuild the same words in reverse order, using independent inverse formulas.
        std::vector<std::vector<u64>> prev(k+1);
        for(unsigned width=0; width<=k; ++width) {
            auto& out=prev[width];
            if(width<3) {
                for(u64 t=0;t<(u64(1)<<width);++t)out.push_back(t);
                continue;
            }
            u64 mask_a=(u64(1)<<(width-2))-1, mask_b=(u64(1)<<(width-3))-1;
            u64 inv3=inverse_odd(3), inv9=inverse_odd(9);
            for(u64 y:prev[width-2]) out.push_back(4*((y*inv3)&mask_a));
            for(u64 y:prev[width-3]) out.push_back(8*(((y-8)*inv9)&mask_b)+7);
        }
        std::sort(residues.begin(),residues.end());
        std::sort(prev[k].begin(),prev[k].end());
        if(prev[k]!=residues)throw std::logic_error("forward and inverse suffix lists disagree");
    }
    void generate(State s) {
        if(s.bits+2>=bits) {
            for(u64 v=u64(s.r);v<mod;v+=u64(1)<<s.bits) residues.push_back(v);
            return;
        }
        generate(s.child(false));
        generate(s.child(true));
    }
    const std::vector<u64>& for_exponent(const State& s) {
        auto [it,inserted]=translated.try_emplace(s.threes);
        if(inserted) {
            auto& v=it->second;
            v.reserve(residues.size());
            u64 inverse=inverse_odd(u64(s.a));
            for(u64 r:residues) v.push_back((inverse*r)&(mod-1));
            std::sort(v.begin(),v.end());
            if(std::adjacent_find(v.begin(),v.end())!=v.end())
                throw std::logic_error("suffix classes overlap");
        }
        return it->second;
    }
};

struct Proof {
    u128 limit;
    unsigned prefix;
    Suffix suffix;
    u64 nodes=0,tables=0,direct=0,gmp_cases=0;
    unsigned longest=0;
    Proof(unsigned bits,unsigned prefix_bits,unsigned suffix_bits):
        limit(u128(1)<<bits),prefix(prefix_bits),suffix(suffix_bits) {}
    void big_finish(const mpz_class& seed,mpz_class x,unsigned steps) {
        ++gmp_cases;
        while(x>=seed) {
            if(++steps>10000)throw std::runtime_error("unresolved integer "+seed.get_str());
            unsigned d=mpz_fdiv_ui(x.get_mpz_t(),8);
            if(d%4==0) { x/=4; x*=3; }
            else if(d==7) { x+=1; x/=8; x*=9; x-=1; }
            else break;
        }
        longest=std::max(longest,steps);
    }
    void finish(const State& s,u128 t) {
        ++direct;
        u128 seed=(t<<s.bits)+s.r;
        if(!seed || seed>limit)throw std::logic_error("invalid seed");
        if(t && s.a>(MAX128-s.b)/t) { big_finish(big(seed),big(s.a)*big(t)+big(s.b),0);return; }
        u128 x=s.a*t+s.b;
        unsigned steps=0;
        while(x>=seed) {
            if(++steps>10000)throw std::runtime_error("unresolved integer "+decimal(seed));
            unsigned d=unsigned(x)&7;
            if(d%4==0) x-=x/4;
            else if(d==7) {
                u128 increment=x/8+1;
                if(x>MAX128-increment) {big_finish(big(seed),big(x)+big(increment),steps);return;}
                x+=increment;
            } else break;
        }
        longest=std::max(longest,steps);
    }
    void candidates(const State& s,u128 low,u128 high) {
        ++tables;
        const auto& list=suffix.for_exponent(s);
        const u64 mask=suffix.mod-1;
        const u64 shift=(inverse_odd(u64(s.a))*u64(s.b))&mask;
        // List entries equal t+shift modulo 2^suffix.bits.
        u128 pos=low;
        while(pos<=high) {
            u64 left=(u64(pos)+shift)&mask;
            u64 span=u64(std::min(u128(mask-left),high-pos));
            u64 right=left+span;
            auto first=std::lower_bound(list.begin(),list.end(),left);
            auto last=std::upper_bound(first,list.end(),right);
            for(auto it=first;it!=last;++it) finish(s,pos+(*it-left));
            pos+=u128(span)+1;
        }
    }
    void visit(const State& s) {
        if(s.r>limit) return;
        u128 lo=s.r==0?1:0, hi=(limit-s.r)>>s.bits;
        if(hi<lo)return;
        ++nodes;
        u128 d=u128(1)<<s.bits;
        if(s.a<d) {
            if(s.b<s.r)return;
            hi=std::min(hi,(s.b-s.r)/(d-s.a));
            if(hi<lo)return;
            if(hi-lo<32) {
                for(u128 t=lo;t<=hi;++t)finish(s,t);
            } else candidates(s,lo,hi);
            return;
        }
        if(s.bits>=prefix) { candidates(s,lo,hi);return; }
        visit(s.child(false));
        visit(s.child(true));
    }
};

int main(int argc,char** argv) {
    if(argc!=4)throw std::invalid_argument("arguments: bits prefix_bits suffix_bits");
    unsigned n=std::stoul(argv[1]),p=std::stoul(argv[2]),f=std::stoul(argv[3]);
    if(n>=128 || n<1 || p>110 || p<1 || f<3 || f>55)
        throw std::invalid_argument("allowed n=1..127, p=1..110, f=3..55");
    Proof proof(n,p,f);
    proof.visit({0,0,0,1,0});
    std::cout<<"PASS all 1 <= u <= "<<decimal(proof.limit)<<" (2^"<<n<<")"
             <<" prefix="<<p<<" suffix="<<f<<" suffix_residues="<<proof.suffix.residues.size()
             <<" nodes="<<proof.nodes<<" queries="<<proof.tables<<" continuations="<<proof.direct
             <<" gmp="<<proof.gmp_cases<<" max_continuation="<<proof.longest<<'\n';
}
