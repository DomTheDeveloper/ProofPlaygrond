"""Exact residue chains and a certified comparison for mixed-prime census maps."""
from fractions import Fraction as F
from itertools import product
from math import lcm, log


def order(a, prime):
    n = 1
    while pow(a, n, prime) != 1:
        n += 1
    return n


def configurations(primes, multiplier):
    states = list(product(*(range(1, p) for p in primes)))
    matrix = []
    for state in states:
        active = [(multiplier * r + 1) % p == 0 for p, r in zip(primes, state)]
        laws = []
        for p, hit in zip(primes, active):
            if not hit:
                laws.append([(0,F(1))])
                continue
            period = lcm(*(order(p, q) for q in primes if q != p))
            laws.append([(j, F((p-1)*p**(period-j), p**period-1))
                         for j in range(1, period+1)])
        row = [F(0)]*len(states)
        for exps in product(*laws):
            weight = F(1)
            for _,probability in exps:
                weight *= probability
            outputs = []
            for i,(q,hit) in enumerate(zip(primes,active)):
                if hit:
                    outputs.append(list(range(1,q)))
                    weight /= q-1
                else:
                    residue = multiplier*state[i]+1
                    for j,(p, (e,_)) in enumerate(zip(primes,exps)):
                        if i!=j:
                            residue *= pow(p, -e, q)
                    outputs.append([residue % q])
            for target in product(*outputs):
                row[states.index(target)] += weight
        assert sum(row)==1
        matrix.append(row)
    return states,matrix


def stationary(matrix):
    n=len(matrix)
    a = [[matrix[j][i]-int(j==i) for j in range(n)]+[F(0)] for i in range(n-1)]
    a.append([F(1)]*(n+1))
    for j in range(n):
        i=next(i for i in range(j,n) if a[i][j])
        a[j],a[i]=a[i],a[j]
        p=a[j][j]
        a[j]=[x/p for x in a[j]]
        for i in range(n):
            if i!=j:
                c=a[i][j]
                a[i]=[x-c*y for x,y in zip(a[i],a[j])]
    v=[a[i][-1] for i in range(n)]
    assert sum(v)==1 and min(v)>0
    assert all(sum(v[i]*matrix[i][j] for i in range(n))==v[j] for j in range(n))
    # Two-way reachability from state zero.
    for table in (matrix, list(zip(*matrix))):
        reached={0}
        for _ in range(n):
            reached |= {j for i in reached for j,val in enumerate(table[i]) if val}
        assert len(reached)==n
    return v


def interval_log(n):
    # Arguments 2, 3, 4, 5 and 7 only. The remainder bound is rational.
    z=F(n-1,n+1)
    terms=175
    lo=2*sum((z**(2*j+1)/(2*j+1) for j in range(terms)),F())
    hi=lo+2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    return lo,hi


def analyze(multiplier, primes, target):
    states,matrix=configurations(primes,multiplier)
    pi=stationary(matrix)
    means=[F(p,p-1)*sum(w for w,s in zip(pi,states) if (multiplier*s[i]+1)%p==0)
           for i,p in enumerate(primes)]
    denom=sum(float(x)*log(p) for p,x in zip(primes,means))
    assert interval_log(multiplier)[1] < target*sum(x*interval_log(p)[0] for p,x in zip(primes,means))
    print('multiplier',multiplier,'primes',primes,'states',states)
    print('P',*[','.join(map(str,row)) for row in matrix],sep='\n')
    print('stationary',*pi,'mean valuations',*means)
    print('mean log multiplier',f'{log(multiplier)-denom:.12f}', 'threshold',f'{log(multiplier)/denom:.12f}','verified example',target)
    return means


if __name__=='__main__':
    analyze(7,(2,3,5),F(18,25))
    analyze(5,(2,3),F(7,10))
    analyze(7,(2,3),F(24,25))

def fixed_divisor(label, p, h, multiplier, addition):
    mod=p**h
    matrix=[]
    for r in range(mod):
        a,b=multiplier(r),addition(r)
        assert a%p and (a*r+b)%p==0
        row=[F(0)]*mod
        for t in range(p):
            j=(a*(r+mod*t)+b)//p % mod
            row[j]+=F(1,p)
        matrix.append(row)
    pi=stationary(matrix)
    slope_means={}
    for r,weight in enumerate(pi):
        a=multiplier(r)
        slope_means[a]=slope_means.get(a,F(0))+weight
    growth=sum(float(w)*log(a) for a,w in slope_means.items())
    rate=growth/log(p)
    # The next hundredth is checked exactly, not inferred from its decimal.
    upper=F(int(100*rate)+1,100)
    assert sum(w*interval_log(a)[1] for a,w in slope_means.items() if a>1)<upper*interval_log(p)[0]
    print('CLS',label,'multiplier frequencies',slope_means,'threshold',f'{rate:.12f}','verified example',upper)
    return pi

if __name__=='__main__':
    fixed_divisor('004/061',3,1,lambda r: (1,4,4)[r],lambda r: (0,-1,1)[r])
    fixed_divisor('005/062',3,1,lambda r: (1,4,4)[r],lambda r: (0,2,1)[r])
    fixed_divisor('008/063',3,1,lambda r: (1,5,5)[r],lambda r: (0,1,2)[r])
    fixed_divisor('048/064',2,2,lambda r: 5 if r==1 else 1,lambda r: r%2)
    fixed_divisor('049/065',2,2,lambda r: 5 if r==1 else 1,lambda r: 3*(r%2))
    fixed_divisor('051',3,1,lambda r: (1,4,2)[r],lambda r: (0,5,2)[r])
    fixed_divisor('052',2,5,lambda r: 3 if r%2 and r not in (19,27,31) else 1,lambda r:r%2)
    fixed_divisor('053',2,2,lambda r: 7 if r==1 else 1,lambda r:r%2)
