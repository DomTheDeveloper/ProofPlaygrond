"""Independent direct-orbit, counting, residue and certificate checks."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import subprocess, sys
from mixed_drift import configurations

def step(n):
    if n%2==0:
        return n//2
    r=n%3
    return n//3 if not r else (n+17*r)//3

def raw_basin(n):
    seen=set()
    while n not in seen:
        seen.add(n); n=step(n)
    return min(c for c in (1,5,17) if c in seen)

def q17_check(cpp):
    N=48000
    colors=[None]+[raw_basin(n) for n in range(1,N+1)]
    assert all((colors[i]==17)==(i%17==0) for i in range(1,N+1))
    output=subprocess.check_output([cpp,str(N)],text=True).splitlines()
    scale=int(output[1].split()[1])
    for label,line in zip((1,5,17),output[2:]):
        f=[int(c==label) for c in colors]
        full=[0]; odds=[0]
        for n in range(1,N+1):
            full.append(full[-1]+f[n]); odds.append(odds[-1]+(n%2)*f[n])
        weights=[odds[n]-2*odds[n//3]-full[n//6] for n in range(1,N+1)]
        assert max(map(abs,weights))<=11
        for k in range(0,N//6-2):
            h=lambda j: odds[2*j]
            assert h(3*k)+full[2]+h(6)==full[k+2]+h(k)+h(k+6)
        for n in range(1,N+1):
            assert full[n]==full[n//2]+odds[n]
        tokens=line.split()
        assert int(tokens[3])==sum(e*(scale//(n*(n+1))) for n,e in enumerate(weights,1))
        assert int(tokens[5])==sum(map(abs,weights))
        assert int(tokens[7])==full[-1]
    print('Direct orbit labels, block sums, and independent integer numerators agree through',N)

def restricted(u):
    if not u%4: return 3*u//4
    if u%8==7: return (9*u+1)//8
    return None

def raw056(n):
    if n%8 in (5,7): return 1
    return n//2 if not n%2 else 3*n+1

def check056():
    done={1}
    for n in range(1,250001):
        path=[];z=n
        while z not in done:
            path.append(z); z=raw056(z); assert len(path)<1000
        done.update(path)
    for u in range(1,100001):
        s=8*u+1; v=restricted(u); x=s
        for _ in range(12):
            if x%8 in (5,7):
                assert v is None
                break
            x=x//2 if x%2==0 else 3*x+1
            if x%8==1:
                assert v is not None and x==8*v+1
                break
        else: raise AssertionError(s)
    for t in range(10000):
        u=2916*t+728
        v=2048*t+511
        for _ in range(3): v=restricted(v)
        assert v==u and restricted(u)==2187*t+546
        past=(2048*t+511)%3==0 or (2048*t+511)%9==8
        future=restricted(2187*t+546) is not None
        assert (past and future)==(t%9 in (1,2,4,7) and t%8 in (2,6,7))
    print('CLS-056 raw rule, reduced returns, and two-sided congruences agree')

def check_transitions():
    # Direct integer enumeration for a finite cylinder at each live residue state.
    # For a prescribed vector of exact valuations v, one extra p-adic digit
    # makes each possible unit output occur equally often at every activated p.
    from itertools import product
    from math import prod
    for a,primes in ((5,(2,3)),(7,(2,3)),(7,(2,3,5))):
        states,_=configurations(primes,a)
        for state in states:
            active=[(a*r+1)%p==0 for r,p in zip(state,primes)]
            v=[(1 if yes else 0) for yes in active]
            d=prod(p**e for p,e in zip(primes,v))
            period=d*prod(primes)
            hits=Counter()
            for n in range(1,period+1):
                if tuple(n%p for p in primes)!=state or (a*n+1)%d: continue
                y=(a*n+1)//d
                if any(y%p==0 for p in primes):continue
                hits[tuple(y%p for p in primes)]+=1
            possible=[]
            for i,p in enumerate(primes):
                if active[i]: possible.append(range(1,p))
                else: possible.append([(a*state[i]+1)*pow(d,-1,p)%p])
            assert hits==Counter(product(*possible))
    print('Mixed-prime transition cylinders agree with direct integer enumeration')

if __name__=='__main__':
    q17_check(sys.argv[1])
    check056()
    check_transitions()
