// Certified partial sums for the natural densities of the three CLS-057 basins.
// g++ -O3 -std=c++17 basin_sums.cpp -o basin_sums
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using u64=std::uint64_t;
using u128=unsigned __int128;
using i128=__int128;
std::string dec(i128 x) {
    if(x<0)return "-"+dec(-x);
    std::string s;
    do{s.push_back(char('0'+x%10)); x/=10;}while(x);
    std::reverse(s.begin(),s.end()); return s;
}
u64 step(u64 n) {return n%2==0 ? n/2 : (n+17*(n%3))/3;}
int main(int argc,char** argv) {
    if(argc!=2)throw std::invalid_argument("one argument: inclusive series cutoff");
    u64 nmax=std::stoull(argv[1]);
    if(nmax<17 || nmax>2000000000ULL)throw std::invalid_argument("range 17..2000000000");
    constexpr u128 scale=u128(1)<<90;
    std::vector<unsigned char> color(nmax+1);
    // Above 17 every step strictly shrinks, so these starts can be filled in order.
    for(u64 n=1;n<=17;++n) {
        u64 y=n;
        unsigned k=0;
        while(y!=1 && y!=5 && y!=17) {
            if(++k>17)throw std::logic_error("unclassified small state");
            y=step(y);
        }
        color[n]=y==1 ? 0 : y==5 ? 1 : 2;
    }
    if(step(1)!=6 || step(6)!=3 || step(3)!=1 || step(5)!=13 ||
       step(13)!=10 || step(10)!=5 || step(17)!=17)throw std::logic_error("incorrect cycles");
    std::array<long long,3> odd{},third{},sixth{},sample{};
    std::array<i128,3> numeric{},rounding{};
    std::array<int,3> min_error{},max_error{};
    for(u64 n=1;n<=nmax;++n) {
        if(n>17) {
            u64 s=step(n);
            if(s==0 || s>=n)throw std::logic_error("index did not descend");
            color[n]=color[s];
        }
        if((color[n]==2)!=(n%17==0))throw std::logic_error("basin invariant");
        if(n%2)++odd[color[n]];
        if(n%6==3)++third[color[n/3]];
        if(n%6==0)++sixth[color[n/6]];
        ++sample[color[n]];
        u64 denominator=n*(n+1);
        i128 weight=scale/denominator;
        for(unsigned i=0;i<3;++i) {
            auto e=odd[i]-2*third[i]-sixth[i];
            if(e < -10 || e > 11)throw std::logic_error("error term exceeded the proof bound");
            min_error[i]=std::min(min_error[i],int(e));
            max_error[i]=std::max(max_error[i],int(e));
            numeric[i]+=i128(e)*weight;
            rounding[i]+=(e<0?-e:e);
        }
    }
    std::cout<<"cutoff "<<nmax<<"\nscale "<<dec(scale)<<'\n';
    for(unsigned i=0;i<3;++i) {
        std::cout<<"basin "<<(i==0?1:i==1?5:17)<<" center "<<dec(numeric[i])
                 <<" rounding "<<dec(rounding[i])<<" sample "<<sample[i]
                 <<" min_error "<<min_error[i]<<" max_error "<<max_error[i]<<'\n';
    }
}
