#import "common.typ": *
#show: body=>style("Convergence through 128 bits for CLS-056 and uniform descent for eleven census maps","CONVERGENCE AND DESCENT",body)

= Every 128-bit start in CLS-056 converges
For CLS-056, a value congruent to 5 or 7 modulo 8 is sent to 1. Every other even value halves, and every other odd value takes the ordinary $3n+1$ step. These are the #link(base+"census/round2/literature/yah_avoid57.md")[original census rules].

#box[*Theorem.* Every positive start through $(2^130-1)/3$, inclusive, reaches the cycle $1→4→2→1$. This covers the whole unsigned 128-bit range. Any other positive cycle of this map would have at least *70,942,055,203,369,145,386* original steps.]

Yolcu, Aaronson and Heule reduce the problem to a partial map on a coordinate $u$. At an odd visit $x=8u+1$, the only two ways to continue to another such odd visit without encountering 5 or 7 modulo 8 are
$ A(u)=3u/4 quad (u≡0 mod 4), quad B(u)=(9u+1)/8 quad (u≡7 mod 8). $
Any other input exits these two branches and triggers the reset. The two branches use three and five ordinary steps, respectively. The coordinate $u=0$ corresponds to $x=1$.

Starting from any positive raw input, remove initial halvings. Odd inputs congruent to 5 or 7 are already resolved. A value congruent to 1 modulo 8 has $u=(n-1)/8$. From $n≡3 mod 8$ the next odd value is $(3n+1)/2$, congruent to 1 or 5 modulo 8. If its residue is 1 its coordinate is $u=(3n-1)/16$. In every case $n≤(2^130-1)/3$ implies $u≤2^126$. Page 2 gives the exhaustive certificate for this interval of $u$.

A divergent orbit of the original rule could still start above the range. For the underlying ordinary Collatz map, this calculation proves a visit to 1 or one of the two specified odd classes. The resets belong to CLS-056.

== What a counterexample would have to revisit
A counterexample must visit $x=23328t+5825$ infinitely often. Each run of $B$ is finite since $B(u)+1=9(u+1)/8$. A run of zero, one or two $B$ steps followed by $A$ strictly decreases every admissible $u>4$ because the three outputs are $3u/4$, $(27u+3)/32$ and $(243u+51)/256$. Infinitely many runs must therefore have length at least three. At an endpoint of at least three consecutive $B$ steps followed by $A$, the reduced coordinate is $u=2916t+728$. Three backward $B$ steps take it to $2048t+511$, and its next $A$ step takes it to $2187t+546$. Page 3 shows that requiring $l$ further steps of history and $l$ further steps of future keeps exactly $6^(-l)$ of all parameter residues. A counterexample must visit each of these explicit sets infinitely often.

#pagebreak()
= The exact range certificate
After a fixed word in $A,B$ the positive starts in its source class have the form $2^p t+r$ and the current value is $3^j t+b$. Initially both forms equal $t$. To append $A$ choose the unique $t$ residue modulo 4 making the current value zero modulo 4. To append $B$ choose the unique residue modulo 8 making it 7 modulo 8. All other residue choices halt. Each split updates both affine expressions by exact substitution.

When $3^j<2^p$, all parameters with $(2^p-3^j)t>b-r$ have already reached a smaller positive integer. Directly inspect the remaining parameters or use the suffix sieve below. By strong induction on the starting integer, descent or exit proves termination. Neither branch ever sends a positive legal integer to zero.

== Sorting the possible continuations
For a fixed number $f$ of low input bits, generate every residue from which the reduced map could keep going until at most two bits of precision remain. Each $A$ consumes two bits and each $B$ consumes three. The program counts a residue as possible as soon as fewer than three bits remain. A second implementation builds this list backwards. If $y$ is an admitted output residue, the two inverse lifts are $4(y/3)$ and $8((y-8)/9)+7$, with the divisions interpreted modulo the remaining power of two. The two lists agree exactly.

At a prefix with current value $3^j t+b$, multiplication of the suffix list by the inverse of $3^j$ modulo $2^f$ gives a sorted list of possible $t+b/3^j$ residues. A range query discards all parameters whose orbit must exit. Each remaining parameter is followed until exit or a drop below its own initial value. Path arithmetic outside the 128-bit range switches to arbitrary-precision integers.

#align(center)[#table(columns:(auto,auto,auto,auto),align:(right,right,right,right),
 [*Prefix bits*],[*Suffix bits*],[*Prefix nodes*],[*Direct continuations*],
 [97],[43],[99,735,535],[353,050,862],
 [99],[42],[150,973,445],[189,070,808])]

Both completed runs cover $1≤u≤2^126$. In the second, 2,921,794 continuations used arbitrary precision. The verifier fails on an unresolved start, an arithmetic guard or overlapping suffix classes. Direct raw-rule checks through 250,000 starts also passed. The known cylinder identity and a different listing algorithm appear in #link("https://rstation.ai/problems/collatz/papers/62")[Constructive survivor lists for an injective Collatz restriction] (2026).

#pagebreak()
= The cycle bound and the rarer classes
Let a hypothetical further reduced cycle use $a$ letters $A$ and $b$ letters $B$. Both counts are positive since $A$ strictly decreases and $B$ strictly increases. Put $J=a+2b$, $D=2a+3b$ and $U=2^126$. All its positive points exceed $U$ by page 2. The correction to the linear slope is exactly 1 on $A$ and $1+1/(9u)$ on $B$. Multiplying around the cycle gives
$ 0<D log 2-J log 3=sum_B log(1+1/(9u))<b/(9U). $
Since $b=2J-D$, putting $alpha=log(3)/log(2)$ forces
$ alpha < D/J < beta=alpha+ (2-alpha)/(1+9U log 2). $
The entire interval $(alpha,beta)$ lies between the fractions
$ 36143248623210700400/22803850947114245497
  quad "and" quad 7354673373747273033/4640282259296926456. $
Their determinant has absolute value 1. Any fraction strictly between them has denominator at least the sum of their denominators, namely 27,444,133,206,411,171,953. This applies even if $D/J$ was initially unreduced. The mediant lies inside $(alpha,beta)$, so the denominator test is sharp for this inequality. A raw cycle has $D+J$ steps, strictly greater than $(1+alpha)J$. Exact logarithm enclosures give the lower bound on page 1.

== Exact two-sided sieve on the previous progression
The two forward branches each map one residue class bijectively onto the 2-adic integers, with source masses $1/4$ and $1/8$. The inverse is defined on $0 mod 3$ and $8 mod 9$, with respective maps $4y/3$ and $(8y-1)/9$. Each maps its class bijectively onto the 3-adic integers. The masses are $1/3$ and $1/9$. Finite versions of these assertions follow by solving the affine congruence with an invertible coefficient.

For fixed $l$, requiring $l$ extra legal future letters from $2187t+546$ retains $(3/8)^l$ of the parameter classes at binary precision $3l$. Requiring $l$ extra inverse letters from $2048t+511$ retains $(4/9)^l$ at ternary precision $2l$. The leading coefficients are units in their respective bases. The Chinese remainder theorem makes the joint fraction exactly $6^(-l)$. A positive counterexample revisits these long-run endpoints arbitrarily late, so it has the required history and future there. For $l=1$ the tests are $t mod 8∈{2,6,7}$ and $t mod 9∈{1,2,4,7}$.

#pagebreak()
= Descent in every interval
Fix a row and any $theta$ strictly between the indicated threshold $theta_*$ and 1. There are constants $C,epsilon>0$, depending only on the row and $theta$, with the following property. In *every* interval of $X≥2$ consecutive positive integers, at most $C X^(1-epsilon)$ starts $n$ fail to reach a value at most $n/X^(1-theta)$. In particular, among the first $X$ starts, that many at most fail to reach $n^theta$. The earlier density-one first-descent argument gave a fixed fractional reduction for the rewriting maps. Here the reduction factor grows with $X$, with an exceptional-set bound uniform over translations.

#align(center)[#table(columns:(auto,auto,auto),align:(left,right,right),
 [*Census entries*],[*Threshold, approximate*],[*Proved example of $theta$*],
 [001 / 058],[0.717315455],[0.72],
 [002 / 059],[0.691350583],[0.70],
 [003 / 060],[0.951330507],[0.96],
 [004 / 061 and 005 / 062],[0.841239671],[0.85],
 [008 / 063],[0.976649014],[0.98],
 [048 / 064 and 049 / 065],[0.580482024],[0.59],
 [051],[0.630929754],[0.64],
 [052],[0.520435448],[0.53],
 [053],[0.467892487],[0.47])]

For the last six table rows use the shortcut $(a_r n+b_r)/p$. A forced first division after a growth step may be included here. Conditional on a current residue $r mod p^h$, the next $p$ lifts are equally likely. The numerator multiplier is coprime to $p$, so the output is uniform within each resulting class. This gives a finite Markov chain. Write $L$ for the product of linear slopes and $mu$ for the stationary mean one-step log slope. The threshold is $theta_*=1+mu/(log p)$.

For the two split-5 maps the stationary frequency of numerator multiplier 5 is $1/4$. For CLS-052 the frequency of 3 is $22/67$. For CLS-053 the frequency of 7 is $1/6$. The ternary maps have independent uniform branch digits. The checker verifies irreducibility, the stationary equations and the strict example inequalities using rational arithmetic. These are eleven distinct maps represented by nineteen entries.

#pagebreak()
= The mixed-prime calculation
For the first three rows on page 4, divide out all permitted primes until the input is a unit at each of them. A growth round multiplies by $a$, adds 1 and removes all factors supported on $P$. The three rows have $(a,P)=(7,{2,3,5}),(5,{2,3}),(7,{2,3})$. The finite state is the tuple of nonzero residues at the primes of $P$. Start with uniform independent local integers conditioned on the residues, understood at each finite precision by the Chinese remainder theorem.

If $a r_p+1≡0 mod p$, the valuation $v_p$ in this round has probabilities $(p-1)/p^k$ for $k≥1$. Its stripped unit is uniform, independent of $v_p$. Otherwise the valuation is zero and the output residue at $p$ is $(a r_p+1) product_(l≠p) l^(-v_l) mod p$. Conditional on all valuations and output residues, the higher local digits again have the same independent uniform law. This gives exact cylinder probabilities, including correlations between successive rounds.

For the eight-state case each valuation needs only its residue modulo the common order of its prime at the other primes. For order $h$, residue representatives $1≤j≤h$ have mass $(p-1)p^(h-j)/(p^h-1)$. Solving the finite stationary equations yields the following exact means.

#align(center)[#table(columns:(auto,auto,auto,auto),align:center,
 [*Entries*],[$bb(E)v_2$],[$bb(E)v_3$],[$bb(E)v_5$],
 [001 / 058],[2],[$27334/40165$],[$2889/8033$],
 [002 / 059],[2],[$6/7$],[—],
 [003 / 060],[2],[$3/5$],[—])]

Write $D$ for the product of removed prime powers in a path of $k$ rounds. Its linear slope is $L=a^k/D$. The mean log slope is $mu=log a-sum_(p∈P)(bb(E)v_p)log p<0$. The threshold in the first three rows is $theta_*=log(a)/(log(a)-mu)$. For multiplier 5 the active residue at 3 has stationary probability $4/7$. For multiplier 7 with just two primes it has probability $2/5$.

== Controlling the tail of the slope distribution
For all eleven maps let $Y$ be one step's log slope and weight each transition from $i$ to $j$ by $e^(eta Y)$, taking the conditional expectation of this weight times the transition indicator given $i$. Call this matrix $K(eta)$. Its positive Perron root $lambda$ has $lambda(0)=1$ and right derivative $lambda'(0)=mu$, by differentiating against the stationary row and the all-ones column. The valuations have geometric tails and the positive slopes are bounded. The positive Perron eigenvector gives $bb(E)_i L^eta≤C_eta lambda(eta)^k$ uniformly in the initial state.

#pagebreak()
= Turning drift into an integer bound
Put $gamma=1-theta$. Ignore the at most $X^sigma$ inputs below $X^sigma$, with any $gamma<sigma<1$. Take $k=floor(c log X)$. If none of the first $k$ recorded iterates falls to $n/X^gamma$, all relevant inputs exceed $X^(sigma-gamma)$. The affine additive corrections consequently multiply to at most $exp(O(k X^(gamma-sigma)))$. Thus this exceptional event requires $L≥(1-o(1))X^(-gamma)$.

For the fixed-denominator rows choose $c$ with $gamma/(-mu)<c<1/(log p)$. For the mixed-prime rows choose $gamma/(-mu)<c<(1-gamma)/(log a)$. These intervals are nonempty under the stated strict threshold conditions. The bound on page 5, applied with small positive $eta$, gives a cylinder probability $O(X^(-epsilon))$ since $log lambda(eta)/eta→mu$ and $c mu<-gamma$.

In the fixed-denominator case depth $k$ is determined modulo $p^(k+h)≤X$ for sufficiently large $X$. In the mixed case, along any exceptional history one has $D=a^k/L≤(1+o(1))a^k X^gamma$. Let $Q=product_(p∈P)p$. A list of valuations and terminal residues is determined on classes of modulus $Q D$. Indeed changing the initial value by a multiple of $Q D$ changes each intermediate value by a multiple of $Q D/D_i$, times a numerator power, where $D_i$ is the product consumed up to that point. Every valuation and terminal residue is preserved. For the chosen $c$, $Q D≤X$. The histories are disjoint. In any interval of $X$ integers a residue of modulus $M≤X$ occurs at most $2X/M$ times. The probability estimate therefore gives $O(X^(1-epsilon))$ integer exceptions, decreasing $epsilon$ if needed to absorb the initially ignored inputs.

Finally take an arbitrary input in a mixed-prime map and write $n=s u$ with $s$ supported on $P$ and $u$ a unit there. If $s≥X^gamma$, stripping alone suffices. Otherwise $u$ lies in an interval of at most $W=ceil(X/s)$ integers. A drop to $u/W^gamma$ suffices since $W≥X/s$ and $s^gamma≤s$. Sum the unit exception bounds over $s$, using $sum_s s^(-(1-epsilon))=product_(p∈P)(1-p^(-(1-epsilon)))^(-1)<infinity$ for $0<epsilon<1$.

== Sources and files
The #link(base+"census/open_collatz_systems.txt")[census] and its #link(base+"census/round2/rewriting")[rewriting records] give the map definitions and previous finite descent tables. Yolcu, Aaronson and Heule give the reduction for CLS-056 in #link("https://doi.org/10.1007/s10817-022-09658-8")[An Automated Approach to the Collatz Conjecture], Proposition 4.15. The accompanying archive contains the range verifier, exact interval and stationary-distribution checks, commands and completed outputs.
