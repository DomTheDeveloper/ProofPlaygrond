#let ink=rgb("#172c3b")
#let teal=rgb("#165d63")
#let dim=rgb("#526872")
#let line=rgb("#cedbdc")
#let base="https://github.com/rain-1/collatz-like-systems/blob/7d749f4ac5a021a6079efa76f6337bdc22811751/"
#let style(title,short,body)={
  set document(title:title,date:datetime(year:2026,month:11,day:25))
  set page(paper:"us-letter",margin:(left:0.83in,right:0.83in,top:0.82in,bottom:0.75in),
    header:block(width:100%,inset:(bottom:4pt),stroke:(bottom:0.5pt+line))[
      #set text(font:"DejaVu Sans",size:8pt,fill:dim)
      COLLATZ-LIKE SYSTEMS CENSUS #h(1fr) #short
    ],
    footer:context [#set text(font:"DejaVu Sans",size:8pt,fill:dim)
      25 November 2026 #h(1fr) #counter(page).display("1") / #counter(page).final().first()])
  set text(font:"Libertinus Serif",size:12pt,fill:ink)
  set par(leading:0.75em,spacing:0.79em,justify:true)
  show heading.where(level:1): it=>block(above:0pt,below:10pt)[#text(font:"DejaVu Sans",size:20pt,weight:"bold",fill:ink,it.body)]
  show heading.where(level:2): it=>block(above:7pt,below:4pt)[#text(font:"DejaVu Sans",size:11.9pt,weight:"bold",fill:teal,it.body)]
  show link: it=>text(fill:teal,it)
  set table(stroke:0.4pt+line,inset:(x:7pt,y:4pt))
  body
}
#let box(body)=block(width:100%,inset:9pt,fill:rgb("#ebf5f3"),stroke:(left:2pt+teal),body)
