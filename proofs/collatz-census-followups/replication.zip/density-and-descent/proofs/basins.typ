#import "common.typ": *
#show: body=>style("Natural densities of the three CLS-057 basins","CLS-057  /  BASIN DENSITIES",body)

= How often does each cycle occur?
CLS-057 halves an even positive integer. For odd $n$, it takes $(n+17c)/3$, where $c$ is the remainder of $n$ modulo 3. Every start reaches one of three cycles. The #link(base+"census/lhf/q17-family/CLS-057.md#L99-L105")[census follow-up] explicitly left open whether the proportions entering those cycles have limits. The earlier resolution of the numbered entry concerned the existence of a finite-state classifier.

#box[*Theorem.* Each basin has a positive natural density. For every row below, the number of starting integers at most $X$ that reach the displayed cycle, divided by $X$, converges to a value in the indicated interval.]

#align(center)[#table(columns:(1fr,1.85fr),align:(left,left),
  [*Cycle*],[*Certified limiting proportion*],
  [$1 → 6 → 3 → 1$],[$[0.628576297, 0.628576317]$],
  [$5 → 13 → 10 → 5$],[$[0.312600154, 0.312600174]$],
  [$17 → 17$],[$1/17$ exactly])]

Above 17 every step strictly decreases. Checking the first 17 integers gives the three displayed cycles, and every step preserves divisibility by 17. Thus the third basin contains exactly the positive multiples of 17. The first two densities sum to $16/17$. Their intervals come from an absolutely convergent series with an explicit remainder bound. For comparison, counting the first 1.5 billion starts gives 942,469,286 in the first basin, a proportion of about 0.628313. The limit itself is determined more accurately by the series.

== What happens in arithmetic progressions?
Every progression of positive integers whose modulus is coprime to 17 has the same three limiting proportions as the full set of integers. This includes powers of 2 and 3. In a fixed nonzero residue class modulo 17, the first two limiting shares instead lie between 66.78623% and 66.78624%, and between 33.21376% and 33.21377%, respectively. If the modulus is divisible by 17, the residue of the progression modulo 17 determines which case applies.

The proof extends to every mixed-multiplier family $A_(m) (q)$ in the census, for every odd $m≥3$ and $q≥2$ with $gcd(q,2m)=1$. Pages 2–4 prove the scalar limit. Pages 5–6 give the family and progression results. Page 7 explains how to reproduce the certificates.

#pagebreak()
= Counting the three odd branches
Fix a basin. Write $f(n)=1$ when $n$ belongs to it, and zero otherwise. Let $F(x)$ count all its members up to $x$, and $O(x)$ its odd members. Both counts are zero for $x<1$. Since $f(2n)=f(n)$, there is an exact identity
$ F(x)=O(x)+F(x/2)=sum_(j≥0) O(x/2^j). $

An odd integer has exactly one of the following forms. In the middle column the ordinary even step has already been used when appropriate.

#align(center)[#table(columns:(auto,auto,auto),align:center,
 [*Input*],[*Same basin as*],[*Contribution, up to endpoints*],
 [$6k+1$],[$k+3$],[$F(x/6)$],
 [$6k+3$],[$2k+1$],[$O(x/3)$],
 [$6k+5$],[$2k+13$],[$O(x/3)$])]

For an exact boundary formula let $H(k)$ count the first $k$ positive odd numbers belonging to the basin. Summing the three rows for $0≤j<k$ gives
$ H(3k)+F(2)+H(6)= F(k+2)+H(k)+H(k+6). $
Define the signed correction for every real $x$ by
$ E(x)=O(x)-2O(x/3)-F(x/6). $
It is constant between successive integers. The preceding identity gives $abs(E(6k))≤8$, since $F(k+2)-F(k)$ and $H(k+6)-H(k)$ lie between zero and 2 or 6. For $6k≤x<6k+6$, $O(x)$ changes by at most three, $O(x/3)$ by at most one, and $F(x/6)$ stays fixed. Hence $-10≤E(x)≤11$ and $abs(E(x))≤11$. Lean checks the partition, block identity and absolute bound for every invariant 0/1 function.

== The exact recurrence
Substitute the even–odd identity for $F(x/6)$ in the definition of $E$ to obtain
$ O(x)=2O(x/3)+sum_(j≥1) O(x/(3 · 2^j))+E(x). $
All the infinite sums of counts are finite for fixed $x$. The terms express how much each earlier size contributes. The bound on $E$ holds uniformly as $x$ changes.

#pagebreak()
= Existence of the limits
Put $h(t)=e^(-t)O(e^t)$ and $z(t)=e^(-t)E(e^t)$, both zero for $t<0$. Define step sizes $l_j=log 3+j log 2$, with probabilities $p_0=2/3$ and $p_j=1/(3 · 2^j)$ for $j≥1$. Their mean is
$ mu=sum_(j≥0)p_j l_j=log 3+2/3 log 2. $
The counting recurrence now reads $h(t)=z(t)+sum_j p_j h(t-l_j)$. Its additive step group contains $log 3$ and $log 2$. Their ratio is irrational by unique prime factorization. The forcing $z$ is directly Riemann integrable because it has only finitely many jumps on each bounded interval and $abs(z(t))≤11e^(-t)$ for $t≥0$. The nonarithmetic key renewal theorem gives
$ lim_(t→infinity)h(t)=1/mu integral_0^infinity z(t) dif t. $
Here “nonarithmetic” means that the step sizes do not all belong to $d bb(Z)$ for any $d>0$. Page 4 supplies an independent proof for these step sizes.

The even–odd identity and dominated convergence, using $O(x)≤x$, give an absolutely convergent series for the full natural density.
$ d=lim_(x→infinity)F(x)/x= (2/mu) sum_(n≥1) E(n)/(n(n+1)). $
Indeed, on $[n,n+1)$ the correction equals $E(n)$ and the integral of $x^(-2)$ is $1/(n(n+1))$. Omission of all terms above $N$ costs at most $22/(mu(N+1))$ in $d$. This bounds the error in the limiting density itself.

== Certified decimals
The checker classifies $1≤n≤1,500,000,000$ in order. Every step from $n>17$ is strictly decreasing. It sums $E(n) floor(2^90/(n(n+1)))$ with integer arithmetic. Dividing by $2^90$ incurs absolute error at most $sum_(n≤N) abs(E(n))/2^90$ before multiplying by $2/mu$. A rational interval for $mu$, the series tail above and $d_1+d_5=16/17$ give the outward-rounded intervals on page 1. A direct orbit implementation independently checks the counts and fixed-point summation through 48,000.

#pagebreak()
= An elementary limit proof
This argument uses compactness and a fair-coin estimate. It proves the scalar limit directly and also applies to the family on page 5.

For $T→infinity$, every sequence of translates $h(T+t)$ has a subsequence converging uniformly on compact intervals to a bounded continuous $g(t)$. To see this, linearly interpolate $O(x)$ between integers. The interpolant is 1-Lipschitz and differs from the count by at most 1. Its normalized logarithmic translates are uniformly Lipschitz on compact intervals for large $T$, and the interpolation error there tends to zero. Compactness on successively larger intervals gives the claim.

Since $z(T+t)→0$, the limit obeys $g(t)=sum_j p_j g(t-l_j)$. More generally write $l_j=log m+j log 2$ with $m$ odd, and suppose $p_0,p_1>0$. After $k$ iterations,
$ g(t)=bb(E)g(t-k log m-S_k log 2), $
where $S_k$ is the sum of $k$ independent integer-valued indices with probabilities $p_j$. The total variation distance between $S_k$ and $S_k+1$ tends to zero. At each step, with probability $2 min(p_0,p_1)>0$, the index may be sampled as a fair zero or one. Conditional on the other choices and on the number $b$ of such steps, the sum contains an independent binomial $(b,1/2)$ term. Its distance from its unit shift equals its largest point probability, which tends to zero as $b$ grows. The number $b$ tends to infinity in probability.

It follows that $g(t+log 2)=g(t)$. The harmonic equation now gives $g(t)=g(t-log m)$ as well. The two periods generate a dense subgroup of the real line, so continuity forces $g$ to be constant.

Integrating the renewal equation up to $T$ identifies this constant.
$ integral_(-infinity)^T z(t) dif t = sum_j p_j integral_(T-l_j)^T h(s) dif s. $
Along the chosen subsequence the term of index $j$ tends to $g l_j$. The terms are dominated after weighting by $p_j l_j$ because $0≤h≤1$. The limit is $mu g$. Every translated subsequence therefore has the same constant limit, which proves $h(t)→mu^(-1)integral z$ and the density formula.

#pagebreak()
= Positive density for the whole family
Let $m≥3$ be odd, $q≥2$ and $gcd(q,2m)=1$. An even input halves. For odd $x$, choose the unique digit $0≤c<m$ with $m∣x+c q$ and set $T(x)=(x+c q)/m$. Every input above $q$ decreases and $[1,q]$ is invariant. Thus there are finitely many cycles and every start reaches one.

For an odd output $y$, its odd predecessors with no intervening halving are $m y-c q$ with $c$ even, whenever positive. The remaining odd predecessors of $y$ in the odd-to-odd map are $m · 2^j y-c q$, with $j≥1$ and $c$ odd. Each is counted once because the intervening number of halvings and the digit are uniquely recoverable. There are $o=(m+1)/2$ even digits and $e=(m-1)/2$ odd digits.

Before removing the intervening halvings, the contributions of the even digits are $o O(x/m)$ and those of the odd digits are $e F(x/(2m))$, each up to a bounded endpoint correction. The correction is bounded because the digit shifts have size at most $(m-1)q$ and there are only $m$ digits. Thus the scalar recurrence on page 3 holds with
$ p_0=o/m, quad p_j=e/(m · 2^j) space(j≥1), quad mu=log m+ (m-1)/m log 2. $
Page 4 proves the existence of each basin density. In particular $m$ may be composite.

== Strict positivity
Choose an odd point $w>q$ in the basin by multiplying an odd point on the cycle by a sufficiently large power of $m$. Every odd inverse branch just listed strictly increases its input above $q$. Distinct finite inverse words from $w$ reach distinct integers because the forward odd parent is unique, and an increasing reverse path cannot return to $w$.

Give each inverse letter of slope $s=m · 2^j$ probability $1/s$. Their probabilities sum to 1. Stop when the product of slopes first exceeds $R≥1$. At least half the stopped probability has product at most $2m R$. Indeed, from any partial product the threshold factor is some $t≥1$. Conditional on the next factor exceeding $t$, the chance it exceeds $2m t$ is at most $1/2$, by the geometric tail in $j$. This also holds for $t<m$, where all factors are at least $m$. Each stopped word has probability below $1/R$, so at least $R/2$ words have product at most $2m R$. Their integer images are at most $2m R w$, since all affine offsets are nonpositive. The basin therefore has positive lower density and hence positive density.

#pagebreak()
= Densities inside every residue class
Fix a modulus $M$. Give each odd count and total count a coordinate for its residue modulo $M$. In the recurrence on page 5 an inverse letter sends a residue $s$ to $m · 2^j s-c q$ modulo $M$, with weight $1/(m · 2^j)$. The vector equation has a bounded endpoint correction in each coordinate. The normalization on page 3 turns it into a finite-state renewal process. Indeed the even-digit contribution uses odd parents, and the odd-digit contribution uses all parents at scale $2m$. Splitting these latter parents into powers of two times odd numbers produces exactly the letters with $j≥1$.

The chain lives on residues represented by odd integers. Apply the equation to the indicator of all positive integers. Its odd densities are equal on these states. This supplies a strictly positive uniform stationary vector, so every state is recurrent.

Within a communicating class the clock for a return to any state has finite mean, by finite-state recurrence and the common finite mean of one step. Its support generates a nonarithmetic additive group. Repeating the letter $(j,c)=(0,0)$ produces a circuit with clock an integer multiple of $log m$. Repeating $(1,1)$ produces a circuit with clock an integer multiple of $log(2m)$. Both lie in the class. Paths to and from either circuit show that if all return times at a base state belonged to $d bb(Z)$, both circuit lengths would belong to it. Their ratio is irrational.

For completeness, the measure of all visits from a state $s$ to a state $r$ is the convolution of its first-hitting measure with the ordinary renewal measure of the return clock at $r$. Iterate the vector equation and apply the scalar key renewal theorem to each directly Riemann integrable forcing coordinate. Convolution with the first-hitting measure preserves existence of its limit by bounded convergence. Thus all odd residue densities exist. Their limit vector is stationary. On each class the stationary vector is unique up to scale and uniform.

== Which residues communicate?
Put $g=gcd(M,q)$. The classes are exactly the lifts, among odd inputs, of the orbits of $⟨2,m⟩$ acting by multiplication modulo $g$. Each branch preserves the stated orbit. For the converse split $M=S K$, where the primes of $S$ divide $2m$ and $gcd(K,2m)=1$. Modulo $K$ the letters permute the residues. The letters $m s$ and $m s-2q$ generate translation by $-2q$ using an inverse, realizable by a positive word in a finite group. These translations cover every difference divisible by $g$. The multipliers $m$ and $2m$ generate the required orbit modulo $g$. Thus some word takes the first state to the second modulo $K$. A common further word $m · 2^j(m^h s)-q$, with $j,h$ large, collapses both states to $-q$ modulo $S$ and preserves their equality modulo $K$. Their paths meet modulo $M$. Recurrence puts them in the same class.

Even parts preserve the same proportions by the exact decomposition into powers of two times odd members. Equivalently, compare with the indicator of the entire compatible orbit modulo $g$. Its odd counts have uniform limits on the class too, and the even-part identity preserves this common ratio. For $q=17$, $3^8≡-1 mod 17$, so every nonzero residue belongs to the same orbit.

#pagebreak()
= Proof sources and reproducibility
The #link(base+"census/open_collatz_systems.txt")[numbered census] records the three cycles and its existing resolution of the classifier problem. The #link(base+"census/lhf/q17-family/CLS-057.md#L99-L105")[family sweep, line 101] lists the existence of the densities as unresolved. That file also supplies the $A_(m) (q)$ family and its finite-state non-automaticity result. The density question and the finite-state question are distinct.

The renewal theorem is stated in Richard Serfozo, #link("https://www.stat.yale.edu/~jtc5/251/readings/Basics%20of%20Applied%20Stochastic%20Processes_Serfozo.pdf")[Basics of Applied Stochastic Processes], Chapter 2, Theorem 35. Pages 2–4 give an elementary argument for the three scalar limits independent of that theorem. The residue-class extension on page 6 uses its usual scalar form.

== Reproducing the numerical result
The following commands reproduce the main checks from the root of the accompanying archive.

```sh
g++ -O3 -std=c++17 basin_sums.cpp -o basin_sums
./basin_sums 1500000000 > basin-output.txt
python3 basin_intervals.py basin-output.txt
python3 crosscheck.py ./basin_sums
lean BasinCounts.lean
```

The three Lean theorems check the even–odd partition, the exact sum over the odd residue branches and the uniform bound on the renewal error. They compile with Lean 4.14.0 and its standard library. The rational interval code bounds logarithms using the expansion $log x=2 sum_(i≥0) z^(2i+1)/(2i+1)$, $z=(x-1)/(x+1)$, with its positive geometric remainder. The C++ summation uses signed 128-bit accumulators. Since $abs(E(n))≤11$ and $sum 1/(n(n+1))=1$, the absolute sum of fixed-point terms is at most $11 · 2^90$, which fits.

== Finite sequences of consecutive basin labels
In the census the number of distinct words of length $w$ over the three labels had been checked through $w=7$. The count is exactly 1,280 at width 8, 2,816 at width 9, 6,144 at width 10, 13,312 at width 11 and 28,672 at width 12. For $w≤16$, the upper bound $(w+2)2^(w-1)$ follows because a block contains either no multiple of 17 or one at a specified position. The remaining letters are binary. The archive gives a starting integer for every permitted width-12 word, which also realizes every shorter permitted word. Iterating the original rule checks every witness.

For example, starting at 1,111,382,124,727,833,530 gives the word `BABBBBBBBX`, with A for the cycle of 1, B for the cycle of 5 and X for 17. This fills the last gap left by a scan of 1.5 billion starts at width 10. At width 12, the word `BBBBBBBBXBBB` occurs at 533,513,909,639,548. A separate check verifies the predicted residue classes and uniform stationarity in 634 exact transition matrices for seven family members.
