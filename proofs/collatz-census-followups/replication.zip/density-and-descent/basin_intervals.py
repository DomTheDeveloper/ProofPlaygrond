"""Read the integer certificate, enclose its tails, and outward-round the densities."""
from fractions import Fraction as F
from pathlib import Path
from math import floor, ceil
import sys
from mixed_drift import interval_log


def densities(path):
    lines=Path(path).read_text().splitlines()
    n=int(lines[0].split()[1])
    scale=int(lines[1].split()[1])
    l2,h2=interval_log(2)
    l3,h3=interval_log(3)
    mu_lo,mu_hi=l3+F(2,3)*l2,h3+F(2,3)*h2
    data={}
    for row in lines[2:]:
        s=row.split()
        j,center,rounding=int(s[1]),int(s[3]),int(s[5])
        error=F(11,n+1)+F(rounding,scale)
        low=2*(F(center,scale)-error)/mu_hi
        high=2*(F(center,scale)+error)/mu_lo
        assert 0<low<high<1
        data[j]=(low,high)
    assert data[17][0]<F(1,17)<data[17][1]
    first=(max(data[1][0],F(16,17)-data[5][1]),min(data[1][1],F(16,17)-data[5][0]))
    second=F(16,17)-first[1],F(16,17)-first[0]
    assert first[0]<first[1]
    for j,(l,h) in [(1,first),(5,second),(17,(F(1,17),F(1,17)))]:
        for digits in (9,):
            step=10**digits
            lo,hi=floor(l*step),ceil(h*step)
            print(f'basin {j}: {lo//step}.{lo%step:0{digits}d} .. {hi//step}.{hi%step:0{digits}d}')
    return first,second


if __name__=='__main__':
    densities(sys.argv[1])
