"""Verify each consecutive word directly under the original CLS-057 map."""
from functools import cache
from itertools import product
from pathlib import Path
import sys


@cache
def label(n):
    if n <= 0:
        raise ValueError("positive starts required")
    if n in (1, 5, 17):
        return {1: "A", 5: "B", 17: "X"}[n]
    if n % 2 == 0:
        return label(n // 2)
    return label((n + 17 * (n % 3)) // 3)


def permitted(width):
    words = {"".join(bits) for bits in product("AB", repeat=width)}
    for bits in product("AB", repeat=width - 1):
        for position in range(width):
            words.add("".join(bits[:position]) + "X" + "".join(bits[position:]))
    return words


def check(path):
    rows = [line.split() for line in Path(path).read_text().splitlines()]
    width = len(rows[0][0])
    assert 1 <= width <= 16
    expected = permitted(width)
    checked = set()
    for word, raw in rows:
        start = int(raw)
        assert start > 0 and word not in checked and word in expected, (word, start)
        actual = "".join(label(start + j) for j in range(width))
        assert actual == word, (word, start, actual)
        checked.add(word)
    assert checked == expected, sorted(expected - checked)
    for k in range(1, width + 1):
        shorter = {word[:k] for word in checked}
        assert shorter == permitted(k)
        assert len(shorter) == (k + 2) * 2 ** (k - 1)
        print(f"width {k:2}: all {len(shorter):,} permitted words")
    rare_start = 1_111_382_124_727_833_530
    assert "".join(label(rare_start + j) for j in range(10)) == "BABBBBBBBX"
    print("All witness positions agree with direct iteration of the original map.")


if __name__ == "__main__":
    default = Path(__file__).with_name("word-witnesses.txt")
    check(sys.argv[1] if len(sys.argv) > 1 else default)
