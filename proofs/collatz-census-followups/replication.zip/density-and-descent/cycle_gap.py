"""Certificate for the least arithmetically possible positive cycle in CLS-056."""
from fractions import Fraction as F
from math import floor, ceil
from mixed_drift import interval_log


def bracket(x, limit):
    # Continued-fraction Farey neighbours with denominators at most limit.
    p,q=x.numerator,x.denominator
    a,b,c,d=0,1,1,0
    while q:
        k,r=divmod(p,q)
        if b+k*d>limit:
            break
        a,b,c,d=c,d,a+c*k,b+d*k
        p,q=q,r
    if q==0:
        raise ValueError("logarithm enclosure needs more precision")
    k=(limit-b)//d
    left,right=sorted([F(a+k*c,b+k*d),F(c,d)])
    assert left < x < right
    assert right.numerator*left.denominator-left.numerator*right.denominator==1
    assert left.denominator<=limit and right.denominator<=limit<left.denominator+right.denominator
    return left,right


def first_admissible():
    u=2**126
    lp,up=interval_log(2)
    lq,uq=interval_log(3)
    lower,upper=lq/up,uq/lp
    # beta = alpha + (2-alpha)/(1+9*u*log 2).
    beta_lo=lower + (2-upper)/(1+9*u*up)
    beta_hi=upper + (2-lower)/(1+9*u*lp)
    middle=(lower+upper)/2
    low,high=1,2
    def exists(n):
        left,right=bracket(middle,n)
        assert left<lower<upper<right
        if right<beta_lo: return True
        assert beta_hi<right
        return False
    while not exists(high):
        low,high=high,high*2
    while high-low>1:
        mid=(low+high)//2
        if exists(mid): high=mid
        else: low=mid
    left,right=bracket(middle,high-1)
    candidate=bracket(middle,high)[1]
    assert right>beta_hi and left<lower and upper<candidate<beta_lo
    assert candidate.denominator==high
    extrap=[
        ('odd steps J',high),
        ('reduced H steps',floor((lower-1)*high)+1),
        ('ordinary Collatz steps',floor((lower+1)*high)+1),
        ('B steps',floor((2-beta_hi)*high)+1),
        ('A steps',floor((2*lower-3)*high)+1)]
    print('excluded at all denominators <',high)
    print('Farey bracket',left,right)
    print('first admissible D/J',candidate)
    for name,val in extrap: print(name,format(val,',d'))
    return extrap


if __name__=='__main__':
    first_admissible()
