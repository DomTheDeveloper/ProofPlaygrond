"""Check the residue-class part of the density proof on exact finite matrices."""
from collections import defaultdict
from fractions import Fraction
from math import gcd, lcm


def grouped_letters(m, modulus):
    # Group the infinite geometric series by the first repeating power of two.
    positions = {}
    j, power = 1, 2 % modulus
    while power not in positions:
        positions[power] = j
        j += 1
        power = 2 * power % modulus
    period_start = positions[power]
    period = j - period_start
    letters = [(c, m % modulus, Fraction(1, m)) for c in range(0, m, 2)]
    for power, j in positions.items():
        weight = Fraction(1, m * (1 << j))
        if j >= period_start:
            weight /= 1 - Fraction(1, 1 << period)
        for c in range(1, m, 2):
            letters.append((c, m * power % modulus, weight))
    assert sum(weight for _, _, weight in letters) == 1
    denominator = lcm(*(weight.denominator for _, _, weight in letters))
    return [(c, slope, int(weight * denominator)) for c, slope, weight in letters], denominator


def reachable(start, edges):
    seen = {start}
    todo = [start]
    while todo:
        for y in edges[todo.pop()]:
            if y not in seen:
                seen.add(y)
                todo.append(y)
    return seen


def check(m, q, modulus):
    assert m >= 3 and m % 2 == 1 and gcd(q, 2 * m) == 1
    letters, denominator = grouped_letters(m, modulus)
    states = list(range(modulus)) if modulus % 2 else list(range(1, modulus, 2))
    row_total = defaultdict(int)
    column_total = defaultdict(int)
    edges = defaultdict(set)
    for s in states:
        for c, slope, weight in letters:
            r = (slope * s - c * q) % modulus
            row_total[s] += weight
            column_total[r] += weight
            edges[s].add(r)
    assert set(column_total) == set(states)
    assert all(row_total[s] == column_total[s] == denominator for s in states)
    g = gcd(modulus, q)
    orbit_edges = {r: {(2 * r) % g, (m * r) % g} for r in range(g)}
    grouped = set()
    for s in states:
        if s in grouped:
            continue
        orbit = reachable(s % g, orbit_edges)
        predicted = {r for r in states if r % g in orbit}
        actual = reachable(s, edges)
        # A positive uniform stationary distribution prohibits transient states.
        assert actual == predicted, (m, q, modulus, s)
        grouped.update(actual)


if __name__ == "__main__":
    cases = 0
    for m, q in ((3, 17), (5, 19), (7, 13), (3, 25), (9, 35), (15, 49), (11, 5)):
        for modulus in sorted(set(range(1, 89)) | {2 * q, 3 * q, 4 * q, 6 * q, 17 ** 2}):
            check(m, q, modulus)
            cases += 1
    print(f"Uniform stationarity and the predicted communicating classes hold in all {cases} exact matrices.")
