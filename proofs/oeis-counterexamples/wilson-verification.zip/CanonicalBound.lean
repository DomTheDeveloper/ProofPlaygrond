import AllCases

namespace WilsonArithmetic.Canonical

/-- Every list of positive exponents with sum at most k occurs in shapes k. -/
theorem shape_complete (k : Nat) : ∀ s : List Nat,
    (∀ e ∈ s, 0 < e) → s.sum ≤ k → s ∈ shapes k := by
  induction k with
  | zero =>
    intro s hpos hsum
    cases s with
    | nil => simp [shapes]
    | cons e es =>
      have h := hpos e (by simp)
      simp only [List.sum_cons] at hsum
      omega
  | succ k ih =>
    intro s hpos hsum
    cases s with
    | nil => simp [shapes]
    | cons e es =>
      have he := hpos e (by simp)
      have htail : ∀ d ∈ es, 0 < d := fun d hd => hpos d (by simp [hd])
      simp only [List.sum_cons] at hsum
      apply List.mem_cons_of_mem
      apply List.mem_flatMap.mpr
      cases e with
      | zero => omega
      | succ e =>
        cases e with
        | zero =>
          refine ⟨es, ih es htail (by omega), ?_⟩
          cases es <;> simp
        | succ e =>
          refine ⟨(e + 1) :: es, ih _ ?_ ?_, ?_⟩
          · simpa using htail
          · simp only [List.sum_cons]; omega
          · simp

/-- All smaller canonical products satisfy the lower bound in the finite proof. -/
theorem bound_for_exponents (s : List Nat) (hpos : ∀ e ∈ s, 0 < e)
    (hnonempty : s ≠ []) (htotal : s.sum ≤ 10)
    (hsmall : product eight s < candidate) :
    9 * adjacentProducts 0 (ordered eight s) ≤ product eight s ^ 2 := by
  have mem := shape_complete 10 s hpos htotal
  have hs : small s = true := by
    cases s with
    | nil => contradiction
    | cons e es => simpa [small] using hsmall
  have h := List.all_eq_true.mp checked s (List.mem_filter.mpr ⟨mem, hs⟩)
  simpa [passes] using h

#print axioms bound_for_exponents
end WilsonArithmetic.Canonical
