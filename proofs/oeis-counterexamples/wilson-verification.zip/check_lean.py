"""Compile the OEIS A251758 certificates with Lean 4.33.1."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", default="lean", help="Lean 4.33.1 executable")
    args = parser.parse_args()
    lean = shutil.which(args.lean)
    if lean is None:
        parser.error(f"Lean executable not found: {args.lean}")
    root = Path(__file__).resolve().parent
    sources = [Path("WilsonArithmetic.lean"), Path("Cases/Definitions.lean")]
    sources.extend(p.relative_to(root) for p in sorted((root / "Cases").glob("Block*.lean")))
    sources.extend([Path("AllCases.lean"), Path("CanonicalBound.lean")])
    subprocess.run([lean, "--version"], check=True)
    with TemporaryDirectory(prefix="wilson-lean-") as tmp:
        output = Path(tmp)
        env = os.environ.copy()
        env["LEAN_PATH"] = os.pathsep.join(p for p in [str(output), env.get("LEAN_PATH")] if p)
        for source in sources:
            target = output / source.with_suffix(".olean")
            target.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run([lean, "-j1", "-M", "1150", "-o", str(target), str(source)],
                           cwd=root, env=env, check=True)
    print(f"Verified {len(sources)} Lean source modules.")


if __name__ == "__main__":
    main()
