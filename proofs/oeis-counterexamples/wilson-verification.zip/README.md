# Verification of the first 8 in OEIS A251758

The least integer with sequence value 8 is **35,336,848,261**. For integers with all prime factors at least 11, the exact minimum for a fixed number of distinct prime factors is 10 for one or two factors, 9 for three through seven, and 8 for eight or more. The paper proves the least-index claim by bounding an infinite family of integers with a product of seven geometric series. A second proof reduces all smaller integers to 332 ordered exponent lists.

## Reproduce the results

```sh
python3 verify.py
python3 check_lean.py
```

Use Python 3.10 or later. The second command also requires Lean 4.33.1. To use a specific executable, run `python3 check_lean.py --lean /path/to/lean`. Only Lean's bundled standard library is needed. Compiled files go into a temporary directory.

## Verification coverage

- `WilsonArithmetic.lean` constructs the three rational bounds directly from the primes. It checks the strict inequalities in the paper, including the two supplementary bounds and three sharpness witnesses for the classification. It constructs the sorted subset products of the eight primes and proves the exact adjacent-product sum, 139494930817713648343, and integer quotient, 8.
- `Cases/Definitions.lean` enumerates exponent lists and computes ordered divisor lists by merging prime-power multiples. The 42 block modules prove each numerical inequality.
- `AllCases.lean` proves that the list produced by the finite enumeration is exactly the 332 listed vectors, and every vector passes.
- `CanonicalBound.lean` proves by induction that the generator includes every positive exponent list of the allowed sum. Its theorem `WilsonArithmetic.Canonical.bound_for_exponents` proves the inequality for any such nonempty list with total at most ten and product below the proposed minimum.
- `verify.py` independently computes the rational bounds and enumerates the compressed products. At the proposed minimum it computes the divisor list again by trial division through the square root.

The paper proves divisor reflection, the reduction from arbitrary prime factors to consecutive primes, and the geometric-series bound. The full upstream `IsLeast` statement has not been checked end to end in Lean.

## Primary sources

Robert G. Wilson v proposed this minimum on December 18, 2014. [OEIS A251758](https://oeis.org/A251758).

Google DeepMind records the least-index question in [Formal Conjectures, OEIS/251758.lean](https://github.com/google-deepmind/formal-conjectures/blob/2055e5adadae0b2e392365938faa82ef6f1464f0/FormalConjectures/OEIS/251758.lean).

Tom Adamczewski's table of first occurrences skips 8. [OEIS Open, Table 1, page 11](https://arxiv.org/pdf/2608.11941#page=11).

An October 4, 2026 public comment had already posted a computational argument excluding every smaller integer. Its follow-up records that its authors stopped short of a formal delivery. [Prior computation](https://github.com/the-omega-institute/trureturing/issues/12805#issuecomment-5976408068) and [status](https://github.com/the-omega-institute/trureturing/issues/12805#issuecomment-5976486797).
