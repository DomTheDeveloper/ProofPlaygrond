"""Independent exact checks for Robert G. Wilson v's first-8 question (OEIS A251758)."""

from collections import Counter
from fractions import Fraction
from math import isqrt, prod

PRIMES = (11, 13, 17, 19, 23, 29, 31, 37)
N = prod(PRIMES)


def edges(primes):
    return sum(Fraction(1, a * b) for a, b in zip((1,) + primes, primes))


def euler(primes):
    return prod(Fraction(p * p, p * p - 1) for p in primes)


def analytic():
    seven = PRIMES[:-1]
    upper7 = edges(seven) + Fraction(1, 31 * 121) + euler(seven) - 1
    upper7 -= sum(Fraction(1, p * p) for p in seven)
    lower8 = edges(PRIMES)
    upper8 = Fraction(1, 11) + euler(PRIMES) - 1
    if not (upper7 < Fraction(1, 9) < lower8 <= upper8 < Fraction(1, 8)):
        raise ArithmeticError("A rational bound failed")
    two = PRIMES[:2]
    upper2 = edges(two) + Fraction(1, 13 * 121) + euler(two) - 1
    upper2 -= sum(Fraction(1, p * p) for p in two)
    all_upper = lower8 + Fraction(1, 2 * 37)
    if not (upper2 < Fraction(1, 10) and all_upper < Fraction(1, 8)):
        raise ArithmeticError("Sharp classification bound failed")
    for n, value in [(121, 10), (143, 10), (2431, 9)]:
        ds = [k for k in range(1, n + 1) if n % k == 0]
        if n * n // adjacent_sum(ds) != value:
            raise ArithmeticError(f"Witness failed at {n}")
    print(f"Two-prime and universal upper bounds: {upper2}, {all_upper}")
    print(f"Seven-prime upper bound: {upper7}")
    print(f"Eight-prime lower and upper bounds: {lower8}, {upper8}")


def families(i=0, n=1, divisors=(1,)):
    if i:
        yield i, n, divisors
    if i == len(PRIMES):
        return
    p = PRIMES[i]
    power = p
    extended = divisors
    while n * power < N:
        extended += tuple(power * d for d in divisors)
        yield from families(i + 1, n * power, extended)
        power *= p


def adjacent_sum(divisors):
    ordered = sorted(divisors)
    return sum(a * b for a, b in zip(ordered, ordered[1:]))


def finite():
    counts = Counter()
    least = None
    for r, n, divs in families():
        s = adjacent_sum(divs)
        if n * n < 9 * s:
            raise ArithmeticError(f"Lower bound failed at {n}")
        counts[r] += 1
        test = (Fraction(n * n, s), n)
        if least is None or test < least:
            least = test
    if [counts[r] for r in range(1, 8)] != [10, 37, 81, 101, 67, 28, 8] or counts.total() != 332:
        raise ArithmeticError("Unexpected number of cases")
    # Recompute the witness without using its prime factorization.
    divs = {d for j in range(1, isqrt(N) + 1) if N % j == 0 for d in (j, N // j)}
    s = adjacent_sum(divs)
    if (len(divs), s, N**2 // s) != (256, 139494930817713648343, 8):
        raise ArithmeticError("Witness check failed")
    print(f"Checked {counts.total()} products. Smallest ratio: {least[0]} at {least[1]}")
    print(f"At {N}: {len(divs)} divisors, adjacent-product sum {s}, floor {N**2 // s}")


if __name__ == "__main__":
    analytic()
    finite()

