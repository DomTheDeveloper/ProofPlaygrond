import Init
import Init.Data.Rat

/- Exact numerical lemmas for the proof that the first 8 in OEIS A251758
   occurs at 35336848261. Run `lean WilsonArithmetic.lean` with Lean 4.33.1. -/
namespace WilsonArithmetic

def seven : List Nat := [11, 13, 17, 19, 23, 29, 31]
def eight : List Nat := seven ++ [37]
def candidate : Nat := eight.prod

def reciprocalEdges (previous : Nat) : List Nat → Rat
  | [] => 0
  | d :: rest => 1 / ((previous : Rat) * d) + reciprocalEdges d rest

def eulerBound (primes : List Nat) : Rat :=
  (primes.map fun (p : Nat) => (p : Rat) ^ 2 / ((p : Rat) ^ 2 - 1)).prod

def primeSquares (primes : List Nat) : Rat :=
  (primes.map fun (p : Nat) => 1 / ((p : Rat) ^ 2)).sum

def sevenUpper : Rat :=
  reciprocalEdges 1 seven + 1 / (31 * 121)
    + eulerBound seven - 1 - primeSquares seven

def eightLower : Rat := reciprocalEdges 1 eight
def eightUpper : Rat := 1 / 11 + eulerBound eight - 1

-- Each inequality checks the expression obtained directly from the primes.
theorem seven_bound : sevenUpper < (1 : Rat) / 9 := by decide +kernel
theorem eight_lower : (1 : Rat) / 9 < eightLower := by decide +kernel
theorem eight_upper : eightUpper < (1 : Rat) / 8 := by decide +kernel

theorem candidate_value : candidate = 35336848261 := by decide +kernel

-- Each exponent is 0 or 1 for this squarefree product.
def subproducts : List Nat → List Nat
  | [] => [1]
  | p :: tail =>
    let ds := subproducts tail
    ds ++ ds.map (p * ·)

def adjacentProducts (previous : Nat) : List Nat → Nat
  | [] => 0
  | d :: tail => previous * d + adjacentProducts d tail

-- Both input lists are sorted. The fuel bound is their combined length.
def merge : Nat → List Nat → List Nat → List Nat
  | 0, xs, ys => xs ++ ys
  | _ + 1, [], ys => ys
  | _ + 1, xs, [] => xs
  | k + 1, x :: xs, y :: ys =>
    if x ≤ y then x :: merge k xs (y :: ys) else y :: merge k (x :: xs) ys

def orderedSubproducts : List Nat → List Nat
  | [] => [1]
  | p :: tail =>
    let ds := orderedSubproducts tail
    merge (2 * ds.length) ds (ds.map (p * ·))

def sortedDivisors : List Nat := orderedSubproducts eight
def candidateSum : Nat := adjacentProducts 0 sortedDivisors

set_option maxRecDepth 20000
set_option maxHeartbeats 0

theorem divisor_count : (subproducts eight).length = 256 := by decide +kernel
theorem exact_sum : candidateSum = 139494930817713648343 := by decide +kernel
theorem candidate_quotient : candidate ^ 2 / candidateSum = 8 := by
  rw [candidate_value, exact_sum]

/-- The uniform lower bounds needed for the sharp classification by prime count. -/
def two : List Nat := [11, 13]
def twoUpper : Rat :=
  reciprocalEdges 1 two + 1 / (13 * 121)
    + eulerBound two - 1 - primeSquares two

theorem at_most_two : twoUpper < (1 : Rat) / 10 := by decide +kernel
theorem odd_tail_after_37 :
    reciprocalEdges 1 eight + (1 : Rat) / (2 * 37) < (1 : Rat) / 8 := by
  decide +kernel

theorem small_witnesses :
    121 ^ 2 / adjacentProducts 0 [1, 11, 121] = 10 ∧
    143 ^ 2 / adjacentProducts 0 (orderedSubproducts [11, 13]) = 10 ∧
    2431 ^ 2 / adjacentProducts 0 (orderedSubproducts [11, 13, 17]) = 9 := by
  decide +kernel

#print axioms at_most_two
#print axioms odd_tail_after_37
#print axioms small_witnesses
#print axioms seven_bound
#print axioms eight_lower
#print axioms eight_upper
#print axioms exact_sum
#print axioms candidate_quotient
end WilsonArithmetic
