import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group15 : List (List Nat) := [[2, 1, 4], [1, 2, 4], [3, 4], [1, 1, 5], [2, 5], [1, 6], [7], [2, 1, 1, 1, 1, 1, 1]]
private theorem case0 : passes [2, 1, 4] = true := by decide +kernel
private theorem case1 : passes [1, 2, 4] = true := by decide +kernel
private theorem case2 : passes [3, 4] = true := by decide +kernel
private theorem case3 : passes [1, 1, 5] = true := by decide +kernel
private theorem case4 : passes [2, 5] = true := by decide +kernel
private theorem case5 : passes [1, 6] = true := by decide +kernel
private theorem case6 : passes [7] = true := by decide +kernel
private theorem case7 : passes [2, 1, 1, 1, 1, 1, 1] = true := by decide +kernel
theorem group15_ok : group15.all passes = true := by
  simp only [group15, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
