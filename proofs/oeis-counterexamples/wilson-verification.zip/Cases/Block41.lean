import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group41 : List (List Nat) := [[1, 8], [9], [9, 1], [10]]
private theorem case0 : passes [1, 8] = true := by decide +kernel
private theorem case1 : passes [9] = true := by decide +kernel
private theorem case2 : passes [9, 1] = true := by decide +kernel
private theorem case3 : passes [10] = true := by decide +kernel
theorem group41_ok : group41.all passes = true := by
  simp only [group41, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3]
end WilsonArithmetic.Canonical
