import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group40 : List (List Nat) := [[1, 4, 4], [5, 4], [3, 1, 5], [2, 2, 5], [1, 3, 5], [4, 5], [3, 6], [2, 7]]
private theorem case0 : passes [1, 4, 4] = true := by decide +kernel
private theorem case1 : passes [5, 4] = true := by decide +kernel
private theorem case2 : passes [3, 1, 5] = true := by decide +kernel
private theorem case3 : passes [2, 2, 5] = true := by decide +kernel
private theorem case4 : passes [1, 3, 5] = true := by decide +kernel
private theorem case5 : passes [4, 5] = true := by decide +kernel
private theorem case6 : passes [3, 6] = true := by decide +kernel
private theorem case7 : passes [2, 7] = true := by decide +kernel
theorem group40_ok : group40.all passes = true := by
  simp only [group40, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
