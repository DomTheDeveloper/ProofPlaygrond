import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group30 : List (List Nat) := [[1, 2, 1, 4], [3, 1, 4], [1, 1, 2, 4], [2, 2, 4], [1, 3, 4], [4, 4], [1, 1, 1, 5], [2, 1, 5]]
private theorem case0 : passes [1, 2, 1, 4] = true := by decide +kernel
private theorem case1 : passes [3, 1, 4] = true := by decide +kernel
private theorem case2 : passes [1, 1, 2, 4] = true := by decide +kernel
private theorem case3 : passes [2, 2, 4] = true := by decide +kernel
private theorem case4 : passes [1, 3, 4] = true := by decide +kernel
private theorem case5 : passes [4, 4] = true := by decide +kernel
private theorem case6 : passes [1, 1, 1, 5] = true := by decide +kernel
private theorem case7 : passes [2, 1, 5] = true := by decide +kernel
theorem group30_ok : group30.all passes = true := by
  simp only [group30, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
