import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group39 : List (List Nat) := [[4, 2, 3], [3, 3, 3], [2, 4, 3], [1, 5, 3], [6, 3], [4, 1, 4], [3, 2, 4], [2, 3, 4]]
private theorem case0 : passes [4, 2, 3] = true := by decide +kernel
private theorem case1 : passes [3, 3, 3] = true := by decide +kernel
private theorem case2 : passes [2, 4, 3] = true := by decide +kernel
private theorem case3 : passes [1, 5, 3] = true := by decide +kernel
private theorem case4 : passes [6, 3] = true := by decide +kernel
private theorem case5 : passes [4, 1, 4] = true := by decide +kernel
private theorem case6 : passes [3, 2, 4] = true := by decide +kernel
private theorem case7 : passes [2, 3, 4] = true := by decide +kernel
theorem group39_ok : group39.all passes = true := by
  simp only [group39, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
