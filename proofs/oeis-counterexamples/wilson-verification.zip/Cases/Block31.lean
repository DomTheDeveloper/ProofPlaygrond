import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group31 : List (List Nat) := [[1, 2, 5], [3, 5], [1, 1, 6], [2, 6], [1, 7], [8], [5, 1, 1, 1, 1], [4, 2, 1, 1, 1]]
private theorem case0 : passes [1, 2, 5] = true := by decide +kernel
private theorem case1 : passes [3, 5] = true := by decide +kernel
private theorem case2 : passes [1, 1, 6] = true := by decide +kernel
private theorem case3 : passes [2, 6] = true := by decide +kernel
private theorem case4 : passes [1, 7] = true := by decide +kernel
private theorem case5 : passes [8] = true := by decide +kernel
private theorem case6 : passes [5, 1, 1, 1, 1] = true := by decide +kernel
private theorem case7 : passes [4, 2, 1, 1, 1] = true := by decide +kernel
theorem group31_ok : group31.all passes = true := by
  simp only [group31, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
