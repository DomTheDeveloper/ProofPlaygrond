import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group33 : List (List Nat) := [[4, 3, 1, 1], [3, 4, 1, 1], [2, 5, 1, 1], [1, 6, 1, 1], [7, 1, 1], [4, 1, 1, 2, 1], [3, 2, 1, 2, 1], [5, 1, 2, 1]]
private theorem case0 : passes [4, 3, 1, 1] = true := by decide +kernel
private theorem case1 : passes [3, 4, 1, 1] = true := by decide +kernel
private theorem case2 : passes [2, 5, 1, 1] = true := by decide +kernel
private theorem case3 : passes [1, 6, 1, 1] = true := by decide +kernel
private theorem case4 : passes [7, 1, 1] = true := by decide +kernel
private theorem case5 : passes [4, 1, 1, 2, 1] = true := by decide +kernel
private theorem case6 : passes [3, 2, 1, 2, 1] = true := by decide +kernel
private theorem case7 : passes [5, 1, 2, 1] = true := by decide +kernel
theorem group33_ok : group33.all passes = true := by
  simp only [group33, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
