import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group14 : List (List Nat) := [[2, 1, 1, 3], [1, 2, 1, 3], [3, 1, 3], [1, 1, 2, 3], [2, 2, 3], [1, 3, 3], [4, 3], [1, 1, 1, 4]]
private theorem case0 : passes [2, 1, 1, 3] = true := by decide +kernel
private theorem case1 : passes [1, 2, 1, 3] = true := by decide +kernel
private theorem case2 : passes [3, 1, 3] = true := by decide +kernel
private theorem case3 : passes [1, 1, 2, 3] = true := by decide +kernel
private theorem case4 : passes [2, 2, 3] = true := by decide +kernel
private theorem case5 : passes [1, 3, 3] = true := by decide +kernel
private theorem case6 : passes [4, 3] = true := by decide +kernel
private theorem case7 : passes [1, 1, 1, 4] = true := by decide +kernel
theorem group14_ok : group14.all passes = true := by
  simp only [group14, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
