import WilsonArithmetic

/- All ordered positive exponent lists of total at most 10 are enumerated by
   shapes. The admissible ones give the 332 canonical products in the proof. -/
namespace WilsonArithmetic.Canonical

def shapes : Nat → List (List Nat)
  | 0 => [[]]
  | k + 1 => [] :: (shapes k).flatMap (fun s =>
    match s with
    | [] => [[1]]
    | e :: es => [1 :: s, (e + 1) :: es])

def product : List Nat → List Nat → Nat
  | p :: ps, e :: es => p ^ e * product ps es
  | _, _ => 1

def small (s : List Nat) : Bool := !s.isEmpty && product eight s < candidate

def withPowers (p : Nat) (ds : List Nat) : Nat → List Nat
  | 0 => ds
  | k + 1 =>
    let rest := (withPowers p ds k).map (p * ·)
    merge (ds.length + rest.length) ds rest

def ordered : List Nat → List Nat → List Nat
  | p :: ps, e :: es => withPowers p (ordered ps es) e
  | _, _ => [1]

def passes (s : List Nat) : Bool :=
  9 * adjacentProducts 0 (ordered eight s) ≤ product eight s ^ 2

set_option maxRecDepth 64000
set_option maxHeartbeats 0

end WilsonArithmetic.Canonical
