import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group34 : List (List Nat) := [[4, 2, 2, 1], [3, 3, 2, 1], [2, 4, 2, 1], [1, 5, 2, 1], [6, 2, 1], [4, 1, 3, 1], [3, 2, 3, 1], [2, 3, 3, 1]]
private theorem case0 : passes [4, 2, 2, 1] = true := by decide +kernel
private theorem case1 : passes [3, 3, 2, 1] = true := by decide +kernel
private theorem case2 : passes [2, 4, 2, 1] = true := by decide +kernel
private theorem case3 : passes [1, 5, 2, 1] = true := by decide +kernel
private theorem case4 : passes [6, 2, 1] = true := by decide +kernel
private theorem case5 : passes [4, 1, 3, 1] = true := by decide +kernel
private theorem case6 : passes [3, 2, 3, 1] = true := by decide +kernel
private theorem case7 : passes [2, 3, 3, 1] = true := by decide +kernel
theorem group34_ok : group34.all passes = true := by
  simp only [group34, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
