import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group21 : List (List Nat) := [[1, 2, 2, 2, 1], [3, 2, 2, 1], [1, 1, 3, 2, 1], [2, 3, 2, 1], [1, 4, 2, 1], [5, 2, 1], [1, 1, 1, 1, 3, 1], [2, 1, 1, 3, 1]]
private theorem case0 : passes [1, 2, 2, 2, 1] = true := by decide +kernel
private theorem case1 : passes [3, 2, 2, 1] = true := by decide +kernel
private theorem case2 : passes [1, 1, 3, 2, 1] = true := by decide +kernel
private theorem case3 : passes [2, 3, 2, 1] = true := by decide +kernel
private theorem case4 : passes [1, 4, 2, 1] = true := by decide +kernel
private theorem case5 : passes [5, 2, 1] = true := by decide +kernel
private theorem case6 : passes [1, 1, 1, 1, 3, 1] = true := by decide +kernel
private theorem case7 : passes [2, 1, 1, 3, 1] = true := by decide +kernel
theorem group21_ok : group21.all passes = true := by
  simp only [group21, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
