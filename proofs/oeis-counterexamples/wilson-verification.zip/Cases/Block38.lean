import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group38 : List (List Nat) := [[2, 5, 2], [1, 6, 2], [7, 2], [4, 1, 1, 3], [3, 2, 1, 3], [2, 3, 1, 3], [5, 1, 3], [3, 1, 2, 3]]
private theorem case0 : passes [2, 5, 2] = true := by decide +kernel
private theorem case1 : passes [1, 6, 2] = true := by decide +kernel
private theorem case2 : passes [7, 2] = true := by decide +kernel
private theorem case3 : passes [4, 1, 1, 3] = true := by decide +kernel
private theorem case4 : passes [3, 2, 1, 3] = true := by decide +kernel
private theorem case5 : passes [2, 3, 1, 3] = true := by decide +kernel
private theorem case6 : passes [5, 1, 3] = true := by decide +kernel
private theorem case7 : passes [3, 1, 2, 3] = true := by decide +kernel
theorem group38_ok : group38.all passes = true := by
  simp only [group38, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
