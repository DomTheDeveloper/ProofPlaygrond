import Cases.Definitions
namespace WilsonArithmetic.Canonical
set_option maxRecDepth 24000
set_option maxHeartbeats 0
def group35 : List (List Nat) := [[1, 4, 3, 1], [5, 3, 1], [3, 1, 4, 1], [2, 2, 4, 1], [4, 4, 1], [3, 5, 1], [2, 6, 1], [1, 7, 1]]
private theorem case0 : passes [1, 4, 3, 1] = true := by decide +kernel
private theorem case1 : passes [5, 3, 1] = true := by decide +kernel
private theorem case2 : passes [3, 1, 4, 1] = true := by decide +kernel
private theorem case3 : passes [2, 2, 4, 1] = true := by decide +kernel
private theorem case4 : passes [4, 4, 1] = true := by decide +kernel
private theorem case5 : passes [3, 5, 1] = true := by decide +kernel
private theorem case6 : passes [2, 6, 1] = true := by decide +kernel
private theorem case7 : passes [1, 7, 1] = true := by decide +kernel
theorem group35_ok : group35.all passes = true := by
  simp only [group35, List.all_cons, List.all_nil, Bool.true_and, case0, case1, case2, case3, case4, case5, case6, case7]
end WilsonArithmetic.Canonical
