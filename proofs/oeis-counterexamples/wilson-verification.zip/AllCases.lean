import Cases.Block00
import Cases.Block01
import Cases.Block02
import Cases.Block03
import Cases.Block04
import Cases.Block05
import Cases.Block06
import Cases.Block07
import Cases.Block08
import Cases.Block09
import Cases.Block10
import Cases.Block11
import Cases.Block12
import Cases.Block13
import Cases.Block14
import Cases.Block15
import Cases.Block16
import Cases.Block17
import Cases.Block18
import Cases.Block19
import Cases.Block20
import Cases.Block21
import Cases.Block22
import Cases.Block23
import Cases.Block24
import Cases.Block25
import Cases.Block26
import Cases.Block27
import Cases.Block28
import Cases.Block29
import Cases.Block30
import Cases.Block31
import Cases.Block32
import Cases.Block33
import Cases.Block34
import Cases.Block35
import Cases.Block36
import Cases.Block37
import Cases.Block38
import Cases.Block39
import Cases.Block40
import Cases.Block41
namespace WilsonArithmetic.Canonical
set_option maxHeartbeats 0
set_option maxRecDepth 64000
def listing : List (List Nat) := [group0, group1, group2, group3, group4, group5, group6, group7, group8, group9, group10, group11, group12, group13, group14, group15, group16, group17, group18, group19, group20, group21, group22, group23, group24, group25, group26, group27, group28, group29, group30, group31, group32, group33, group34, group35, group36, group37, group38, group39, group40, group41].flatten
theorem all_listed : listing.all passes = true := by
  simp only [listing, List.flatten_cons, List.flatten_nil, List.all_append, List.all_nil, Bool.true_and, group0_ok, group1_ok, group2_ok, group3_ok, group4_ok, group5_ok, group6_ok, group7_ok, group8_ok, group9_ok, group10_ok, group11_ok, group12_ok, group13_ok, group14_ok, group15_ok, group16_ok, group17_ok, group18_ok, group19_ok, group20_ok, group21_ok, group22_ok, group23_ok, group24_ok, group25_ok, group26_ok, group27_ok, group28_ok, group29_ok, group30_ok, group31_ok, group32_ok, group33_ok, group34_ok, group35_ok, group36_ok, group37_ok, group38_ok, group39_ok, group40_ok, group41_ok]
theorem enumeration : (shapes 10).filter small = listing := by decide +kernel
theorem checked : ((shapes 10).filter small).all passes = true := by rw [enumeration, all_listed]
#print axioms checked
end WilsonArithmetic.Canonical
