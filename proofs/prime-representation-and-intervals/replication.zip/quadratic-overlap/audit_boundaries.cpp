#include <cmath>
#include <cstdint>
#include <exception>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using Integer = std::int64_t;

Integer floor_sqrt(Integer value) {
    Integer root = static_cast<Integer>(std::sqrt(static_cast<long double>(value)));
    while ((root + 1) * (root + 1) <= value) ++root;
    while (root * root > value) --root;
    return root;
}

Integer floor_div(Integer numerator, Integer denominator) {
    return numerator / denominator - (numerator % denominator < 0);
}

std::vector<bool> sieve(int limit) {
    std::vector<bool> primes(limit + 1, true);
    primes[0] = primes[1] = false;
    for (Integer p = 2; p * p <= limit; ++p) {
        if (!primes[p]) continue;
        for (Integer multiple = p * p; multiple <= limit; multiple += p) {
            primes[multiple] = false;
        }
    }
    return primes;
}

// Simultaneous negation lets us take y >= 0. The discriminant identity
// bounds the full interval of x, including negative x whenever necessary.
void mark_form(Integer a, Integer b, Integer c, unsigned char flag,
               int limit, std::vector<unsigned char>& membership) {
    const Integer abs_disc = 4 * a * c - b * b;
    const Integer max_y = floor_sqrt(4 * a * limit / abs_disc);
    for (Integer y = 0; y <= max_y; ++y) {
        const Integer radius = floor_sqrt(4 * a * limit - abs_disc * y * y);
        const Integer first_x = -floor_div(radius + b * y, 2 * a);
        const Integer last_x = floor_div(radius - b * y, 2 * a);
        for (Integer x = first_x; x <= last_x; ++x) {
            const Integer value = a * x * x + b * x * y + c * y * y;
            membership[value] |= flag;
        }
    }
}

Integer mod_power(Integer base, Integer exponent, Integer prime) {
    Integer result = 1;
    while (exponent > 0) {
        if (exponent % 2 == 1) result = result * base % prime;
        base = base * base % prime;
        exponent /= 2;
    }
    return result;
}

struct PairCounts {
    int both = 0, only_left = 0, only_right = 0;
    void add(bool left, bool right) {
        if (left && right) ++both;
        else if (left) ++only_left;
        else if (right) ++only_right;
    }
    int either() const { return both + only_left + only_right; }
    void print(const char* name) const {
        std::cout << name << ": both=" << both << " either=" << either()
                  << " only_left=" << only_left << " only_right=" << only_right;
        if (either() > 0) {
            std::cout << " observed=" << std::fixed << std::setprecision(9)
                      << static_cast<double>(both) / either();
        }
        std::cout << '\n';
    }
};

int main(int argc, char** argv) {
    int limit = 100000000;
    if (argc > 2) {
        std::cerr << "Usage: audit_boundaries [limit from 2 to 100000000]\n";
        return 2;
    }
    if (argc == 2) {
        try {
            std::string input(argv[1]);
            std::size_t used;
            int requested = std::stoi(input, &used);
            if (used != input.size() || requested < 2 || requested > limit) return 2;
            limit = requested;
        } catch (const std::exception&) { return 2; }
    }
    const auto primes = sieve(limit);
    std::vector<unsigned char> represented(limit + 1);
    constexpr unsigned char form_q = 1, form_r = 2, f3 = 4, h33 = 8, f9 = 16;
    mark_form(4, 2, 7, form_q, limit, represented);
    mark_form(7, 3, 9, form_r, limit, represented);
    mark_form(1, 0, 9, f3, limit, represented);
    mark_form(9, 6, 10, h33, limit, represented);
    mark_form(1, 0, 81, f9, limit, represented);

    PairCounts incomparable, nested;
    int total = 0, split = 0, cubic_mismatches = 0, nested_mismatches = 0;
    for (int p = 2; p <= limit; ++p) {
        if (!primes[p]) continue;
        ++total;
        const unsigned char flags = represented[p];
        bool q = flags & form_q, r = flags & form_r;
        bool f = flags & f3, h = flags & h33, small = flags & f9;
        incomparable.add(q, r);
        nested.add(f, h);
        // At 2 and 3 the five specific forms can be inspected directly.
        // None of them takes either prime as a value.
        if (p <= 3) {
            if (q || r) ++cubic_mismatches;
            if (f || h || small) ++nested_mismatches;
            continue;
        }
        bool q_by_cubes = false, r_by_cubes = false;
        if (p % 3 == 1) {
            ++split;
            q_by_cubes = mod_power(2, (p - 1) / 3, p) != 1;
            r_by_cubes = mod_power(3, (p - 1) / 3, p) != 1;
        }
        if (q != q_by_cubes || r != r_by_cubes) ++cubic_mismatches;
        // F3 has a remainder test. Within F3 the two other forms
        // partition the primes, by uniqueness of a two-squares representation.
        if (f != (p % 12 == 1) || f != (h || small) || (h && small)) {
            ++nested_mismatches;
        }
    }
    std::cout << "limit=" << limit << " all_primes=" << total
              << " primes_1_mod_3=" << split << '\n';
    nested.print("nested");
    incomparable.print("incomparable");
    std::cout << "cubic_test_mismatches=" << cubic_mismatches
              << " nested_partition_mismatches=" << nested_mismatches << '\n';
    return (cubic_mismatches || nested_mismatches) ? 1 : 0;
}
