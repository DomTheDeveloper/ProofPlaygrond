"""Decide attainable equal-density prime overlaps in one imaginary quadratic field.

Pass a negative fundamental discriminant (or 'any') and an exact rational overlap.
The finite decision uses prime factorizations and, in two unit cases, reduced
forms. See pages 15–17 of Prime-Overlap-Theorem.pdf for the proofs.
"""
import argparse
from fractions import Fraction
from math import gcd

from audit_equal_density import factorization, is_fundamental, quadratic_character
from check_examples import prime_flags, reduced_forms


def local_rows(d, target, exceptional=False):
    """Return conductor multipliers with local products equal to target.

    For each prime, an existing conductor prime contributes p**e. A new one
    contributes (p-chi_d(p))*p**(e-1). Prime factors contributing 1 may
    be omitted because only existence is at issue.
    """
    flags = prime_flags(target + 1)
    choices = []
    for prime in range(2, target + 2):
        if not flags[prime]:
            continue
        if d is None:
            starts = [prime - 1, prime, prime + 1]
        else:
            starts = [prime - quadratic_character(d, prime)]
        if not exceptional and d is not None:
            starts.append(prime)
        for start in set(starts):
            value, power = start, prime
            while value <= target:
                if value > 1 and target % value == 0:
                    choices.append((prime, power, value))
                power *= prime
                value *= prime
    choices.sort()

    def visit(offset, remaining, multiplier):
        if remaining == 1:
            yield multiplier
            return
        for index in range(offset, len(choices)):
            prime, power, value = choices[index]
            if remaining % value or multiplier % prime == 0:
                continue
            yield from visit(index + 1, remaining // value, multiplier * power)

    return set(visit(0, target, 1))


def has_non_self_inverse_class(d, conductor, degree):
    """Here the maximal order has class number one."""
    if degree & (degree - 1):
        return True  # The degree has an odd prime divisor.
    return any(0 < abs(b) < a < c for a, b, c in reduced_forms(d * conductor**2))


def index_pair(d, q, exceptional=False):
    """Find disjoint prime supports for the ordinary or exceptional test."""
    unit_index = {-4: 2, -3: 3}[d] if exceptional else 1
    rows = set()
    for degree in (q, 2 * q):
        for conductor in local_rows(d, unit_index * degree, exceptional):
            if exceptional and degree == 2 * q:
                if not has_non_self_inverse_class(d, conductor, degree):
                    continue
            rows.add(conductor)
    ordered = sorted(rows)
    for index, left in enumerate(ordered):
        for right in ordered[index + 1:]:
            if gcd(left, right) == 1:
                return (left, right)
    return None


def decision(d, overlap):
    """Decide for the given field, or for some common field when d is None."""
    if d is not None and (d >= 0 or not is_fundamental(d)):
        raise ValueError("The discriminant must be negative and fundamental.")
    if overlap == 0 or overlap == 1:
        return True, "endpoint"
    if not 0 < overlap < 1 or overlap.numerator != 1:
        return False, "outside the reciprocal spectrum"
    m = overlap.denominator
    if m % 2 == 0:
        if m == 2 and (d is None or quadratic_character(d, 2) == -1):
            return True, "inert 2 and the two cubic lifts"
        return False, "even reciprocal denominator excluded"
    q = (m + 1) // 2
    pair = index_pair(d, q)
    if pair:
        return True, f"ordinary local test, coprime multipliers {pair}"
    for exceptional_d in (-4, -3):
        if d is not None and exceptional_d != d:
            continue
        pair = index_pair(exceptional_d, q, exceptional=True)
        if pair:
            return True, f"maximal-order unit test in d = {exceptional_d}, conductors {pair}"
    return False, "both finite tests exhausted"


def prime_parameter(d, ell):
    """Closed criterion for a prime ell >= 11 and J=1/(2*ell-1)."""
    if ell < 11 or factorization(ell) != [(ell, 1)]:
        raise ValueError("ell must be prime and at least 11")
    for sign in (-1, 1):
        p = 2 * ell + sign
        if factorization(p) == [(p, 1)] and quadratic_character(d, p) == sign:
            return True
    if d != -3:
        return False
    return all(factorization(p) == [(p, 1)] for p in (6 * ell - 1, 6 * ell + 1))


def rational_argument(value):
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as error:
        raise argparse.ArgumentTypeError("use an exact rational with nonzero denominator") from error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("discriminant", help="negative fundamental discriminant or any")
    parser.add_argument("overlap", type=rational_argument, help="an exact rational, for example 1/33")
    args = parser.parse_args()
    try:
        d = None if args.discriminant == 'any' else int(args.discriminant)
        possible, reason = decision(d, args.overlap)
    except ValueError as error:
        parser.error(str(error))
    print(f"d = {args.discriminant}, J = {args.overlap}: {possible}. {reason}.")


if __name__ == "__main__":
    main()
