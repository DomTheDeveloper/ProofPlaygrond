"""Verify the Eisenstein family using direct representation and reduction (Python 3.9+)."""
import argparse
from fractions import Fraction

from check_examples import prime_flags, reduced_forms, represented_primes


def principal_form(conductor):
    """Principal form for the Eisenstein order of the indicated conductor."""
    if conductor % 2:
        return (1, 1, (1 + 3 * conductor**2) // 4)
    return (1, 0, 3 * (conductor // 2)**2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=1_000_000)
    args = parser.parse_args()
    if args.limit < 5:
        parser.error("choose a cutoff of at least 5")
    flags = prime_flags(args.limit)
    print(f"Cutoff {args.limit:,}. Class counts and set identities are checked separately.")
    print("j     left    right     both   either  predicted limit  observed")
    for j in range(1, 6):
        f = 3**j
        c = (1 + 3 * f*f) // 4
        left = represented_primes((4, 2, c), flags)
        right = represented_primes((9, 3, c), flags)
        principal = {}
        for k, expected_classes in ((1, f // 3), (2, f), (3, f), (6, 3*f)):
            conductor = k*f
            principal[k] = represented_primes(principal_form(conductor), flags) - {2, 3}
            classes = reduced_forms(-3 * conductor**2)
            assert len(classes) == expected_classes, (j, k, len(classes))
        assert left - {2, 3} == principal[1] - principal[2], j
        assert right - {2, 3} == principal[1] - principal[3], j
        assert principal[2] & principal[3] == principal[6], j
        both, either = len(left & right), len(left | right)
        observed = f"{both/either:.6f}" if either else "n/a"
        print(f"{j} {len(left):8} {len(right):8} {both:8} {either:8}"
              f"  {str(Fraction(1, 2)):>15}  {observed}")
    print("All 15 finite set identities and all 20 class-number checks passed.")


if __name__ == "__main__":
    main()
