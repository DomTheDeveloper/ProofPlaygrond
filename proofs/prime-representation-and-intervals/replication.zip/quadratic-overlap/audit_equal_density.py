"""Check the odd-index lemma and the equal-density quarter-overlap construction.

Run from the extracted source directory with Python 3.9 or later.
The conductor audit uses exact integer arithmetic. The prime tests compare
two separate enumerations of integer representations.
"""
import argparse
from fractions import Fraction
from math import gcd, isqrt

from check_examples import prime_flags, reduced_forms, represented_primes


def factorization(n):
    factors = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            exponent += 1
            n //= divisor
        if exponent:
            factors.append((divisor, exponent))
        divisor = 3 if divisor == 2 else divisor + 2
    if n > 1:
        factors.append((n, 1))
    return factors


def is_fundamental(d):
    if d % 4 == 1:
        radicand = d
    elif d % 4 == 0 and (d // 4) % 4 in (2, 3):
        radicand = d // 4
    else:
        return False
    return all(exponent == 1 for _, exponent in factorization(-radicand))


def quadratic_character(d, prime):
    if d % prime == 0:
        return 0
    if prime == 2:
        return 1 if d % 8 in (1, 7) else -1
    symbol = pow(d % prime, (prime - 1) // 2, prime)
    return 1 if symbol == 1 else -1


def class_number_ratio(d, factors):
    """h(d*f^2)/h(d) for a negative fundamental d and a factorization of f."""
    product = 1
    for prime, exponent in factors:
        product *= prime**(exponent - 1) * (prime - quadratic_character(d, prime))
    unit_index = {-3: 3, -4: 2}.get(d, 1) if factors else 1
    ratio, rem = divmod(product, unit_index)
    if rem:
        raise ArithmeticError((d, factors, product, unit_index))
    return ratio


def audit_conductors(field_limit, conductor_limit):
    factors = [()] + [factorization(f) for f in range(1, conductor_limit + 1)]
    fields = pairs = both_odd = common_three = equal_three = reduced_checks = 0
    for d in range(-field_limit, 0):
        if not is_fundamental(d):
            continue
        fields += 1
        ratios = [0] + [class_number_ratio(d, factors[f])
                        for f in range(1, conductor_limit + 1)]
        if -d <= 100:
            base_classes = len(reduced_forms(d))
            for f in range(1, min(conductor_limit, 12) + 1):
                assert len(reduced_forms(d * f * f)) == base_classes * ratios[f], (d, f)
                reduced_checks += 1
        for second in range(2, conductor_limit + 1):
            for first in range(1, second):
                pairs += 1
                base = ratios[gcd(first, second)]
                k1, rem1 = divmod(ratios[first], base)
                k2, rem2 = divmod(ratios[second], base)
                assert rem1 == 0 and rem2 == 0
                if k1 % 2 == 0 or k2 % 2 == 0:
                    continue
                both_odd += 1
                common = gcd(k1, k2)
                assert common in (1, 3), (d, first, second, k1, k2)
                if common == 3:
                    assert quadratic_character(d, 2) == -1, (d, first, second)
                    common_three += 1
                    if k1 == k2:
                        assert k1 == 3
                        equal_three += 1
    print(f"Negative fundamental discriminants |d| <= {field_limit}: {fields:,}")
    print(f"Conductors 1 <= f1 < f2 <= {conductor_limit}: {pairs:,} pairs across those fields")
    print(f"Both relative indices odd: {both_odd:,}")
    print(f"GCD 3: {common_three:,}. Both indices equal 3: {equal_three:,}.")
    print(f"Independent reduced-form class-number comparisons: {reduced_checks:,}.")
    print("No exceptions to the odd-index lemma in this range.")


def parent_congruences(d, moduli, flags):
    """Mark (u^2+d*v^2)-primes with u congruent to v or -v for each modulus."""
    limit = len(flags) - 1
    all_parent = set()
    eligible = {t: set() for t in moduli}
    for v in range(isqrt(limit // d) + 1):
        base = d * v * v
        for u in range(isqrt(limit - base) + 1):
            prime = u * u + base
            if not flags[prime]:
                continue
            all_parent.add(prime)
            for t in moduli:
                if (u - v) % t == 0 or (u + v) % t == 0:
                    eligible[t].add(prime)
    return all_parent, eligible


def show_pair(label, a, b, predicted):
    both, either = len(a & b), len(a | b)
    ratio = f"{both/either:.8f}" if either else "n/a"
    print(f"{label:>12} {len(a):>10,} {len(b):>10,} {both:>10,}"
          f" {either:>10,} {ratio:>12} {str(predicted):>12}")


def audit_fixed_fields(flags):
    print("Fixed-field boundary pairs")
    print("       field       left      right       both     either     observed        limit")
    # A common conductor divisible by 2*3*4 supports both relative lifts.
    for discriminant in (-4, -7):
        f = 24
        coefficient = -discriminant * f*f // 4
        _, congruence = parent_congruences(coefficient, (3, 4), flags)
        left = represented_primes((9, 6, coefficient + 1), flags)
        right = represented_primes((16, 8, coefficient + 1), flags)
        assert left == congruence[3] and right == congruence[4]
        show_pair(f"d = {discriminant}", left, right, Fraction(2, 5))

    # An inert-2 field beyond the original Eisenstein example.
    d, f = -11, 9
    c = (1 - d*f*f) // 4
    left = represented_primes((4, 2, c), flags)
    right = represented_primes((9, 3, c), flags)
    parent = represented_primes((1, 1, c), flags)
    child_2 = represented_primes((1, 0, -d*f*f), flags)
    child_3 = represented_primes((1, 1, (1 - d*(3*f)**2) // 4), flags)
    ramified = {2, 3, 11}
    assert left - ramified == parent - child_2 - ramified
    assert right - ramified == parent - child_3 - ramified
    show_pair("d = -11", left, right, Fraction(1, 2))
    print("All three boundary examples agree with the alternative membership tests.")


def audit_primes(limit):
    flags = prime_flags(limit)
    moduli = (5, 25, 125)
    parent_25, check_25 = parent_congruences(25, moduli, flags)
    parent_5, check_5 = parent_congruences(5, moduli, flags)
    split = {p for p, prime in enumerate(flags) if prime and p % 20 in (1, 9)}
    assert parent_25 - {5} == parent_5 - {5} == split
    print(f"Primes <= {limit:,}: {sum(flags):,}")
    print("        pair       left      right       both     either     observed        limit")
    for t in moduli:
        left = represented_primes((t*t, 2*t, 26), flags)
        right = represented_primes((t*t, 2*t, 6), flags)
        assert left == check_25[t] and right == check_5[t], t
        if t == 5:
            assert right == represented_primes((6, 2, 21), flags)
        assert len(reduced_forms(-100*t*t)) == 2*t
        assert len(reduced_forms(-20*t*t)) == 2*t
        show_pair(f"t = {t}", left, right, Fraction(1, t-1))
    left = represented_primes((1, 0, 17), flags)
    right = represented_primes((1, 0, 65), flags)
    show_pair("17 and 65", left, right, Fraction(1, 11))
    print("No membership mismatches between the two enumerations of the 5-power family.")
    print("The six class numbers at t = 5, 25, 125 also agree by reduction.")
    audit_fixed_fields(flags)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--field-limit", type=int, default=1000)
    parser.add_argument("--conductor-limit", type=int, default=200)
    parser.add_argument("--prime-limit", type=int, default=10_000_000)
    args = parser.parse_args()
    if min(args.field_limit, args.conductor_limit, args.prime_limit) < 2:
        parser.error("all cutoffs must be at least 2")
    audit_conductors(args.field_limit, args.conductor_limit)
    audit_primes(args.prime_limit)


if __name__ == "__main__":
    main()
