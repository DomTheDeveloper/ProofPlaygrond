"""Independent finite checks of the equal-density classification and its examples."""
from collections import Counter
from fractions import Fraction
from itertools import combinations_with_replacement
from math import gcd

from audit_equal_density import factorization, is_fundamental
from check_examples import prime_flags, reduced_forms, represented_primes
from equal_density_spectrum import decision, prime_parameter


def inverse_class(a, b, discriminant):
    """Gauss reduction with the two signs of the middle coefficient identified."""
    while True:
        b = (b + a) % (2 * a) - a
        c, remainder = divmod(b * b - discriminant, 4 * a)
        assert remainder == 0 and c > 0
        if a <= c:
            return a, abs(b), c
        a, b = c, -b


def orbit_size(form):
    a, b, c = form
    return 2 if 0 < b < a < c else 1


def class_at_prime(p, root_d, d, conductor):
    b = (conductor * root_d) % p
    if (b - d * conductor) % 2:
        b += p
    return inverse_class(p, b, d * conductor**2)


def sample_split_prime(form, d, conductor):
    """Find a represented unramified odd prime and a root of d modulo it."""
    a, b, c = form
    radius = 0
    while True:
        radius += 1
        for y in range(radius + 1):
            for x in range(-radius, radius + 1):
                if max(abs(x), y) != radius:
                    continue
                p = a * x*x + b*x*y + c*y*y
                if p <= 2 or gcd(p, 2 * d * conductor) != 1:
                    continue
                if factorization(p) != [(p, 1)]:
                    continue
                if y % p:
                    root = (2 * a * x + b * y) * pow(y, -1, p) % p
                else:
                    root = b % p
                root = root * pow(conductor, -1, p) % p
                assert (root*root - d) % p == 0
                assert class_at_prime(p, root, d, conductor) == form
                return p, root


def small_class_audit():
    """Compute actual restrictions using represented primes, without local products."""
    total = equal = positive = fields = halves = 0
    attained = set()
    for d in range(-80, 0):
        if not is_fundamental(d):
            continue
        fields += 1
        classes, numbers, restrictions = {}, {}, {}
        for f in range(1, 13):
            proper = reduced_forms(d*f*f)
            numbers[f] = len(proper)
            classes[f] = sorted({(a, abs(b), c) for a, b, c in proper})
            assert sum(map(orbit_size, classes[f])) == numbers[f]
            for form in classes[f]:
                prime, root = sample_split_prime(form, d, f)
                for g in range(1, f + 1):
                    if f % g == 0:
                        restrictions[f, form, g] = class_at_prime(prime, root, d, g)
        half_partners = Counter()
        for f1, f2 in combinations_with_replacement(range(1, 13), 2):
            g = gcd(f1, f2)
            for i, first in enumerate(classes[f1]):
                for second in classes[f2][i if f1 == f2 else 0:]:
                    total += 1
                    s1, s2 = orbit_size(first), orbit_size(second)
                    if s1 * numbers[f2] != s2 * numbers[f1]:
                        continue
                    equal += 1
                    parent = restrictions[f1, first, g]
                    if parent != restrictions[f2, second, g]:
                        attained.add((d, Fraction(0)))
                        continue
                    positive += 1
                    k, remainder = divmod(numbers[f1], numbers[g])
                    assert remainder == 0
                    inv = Fraction(2*k*orbit_size(parent), s1) - 1
                    assert inv.denominator == 1
                    attained.add((d, 1 / inv))
                    if inv == 2:
                        assert (f1, f2) == (2*g, 3*g)
                        assert d % 8 == 5 and g % 2 and (d*g) % 3 == 0 and (d, g) != (-3, 1)
                        half_partners[f1, first] += 1
                        half_partners[f2, second] += 1
                        halves += 1
        predicted_halves = sum(
            sum(orbit_size(form) == 1 for form in classes[g])
            for g in range(1, 5) if d % 8 == 5 and g % 2 and (d*g) % 3 == 0 and (d, g) != (-3, 1)
        )
        assert sum(half_partners.values()) == 2 * predicted_halves
        assert all(partners == 1 for partners in half_partners.values())
        for j in [1, 2, 3, 4, 5, 6]:
            assert not decision(d, Fraction(2, 2*j + 1))[0]
    for d, overlap in sorted(attained):
        assert decision(d, overlap)[0], (d, overlap)
    print(f"Reduced-form audit: {fields} fields with |d| <= 80, conductors 1 through 12.")
    print(f"Unordered inverse-class pairs, allowing equality: {total:,}.")
    print(f"Equal individual densities: {equal:,}; positive overlap among them: {positive:,}.")
    print(f"Distinct observed (field, overlap) cases admitted by the decision test: {len(attained):,}.")
    print(f"Half-overlap pairs: {halves}. Every prescribed parent gave one pair and every partner was unique.")


def arithmetic_audit():
    ds = [d for d in range(-300, 0) if is_fundamental(d)]
    ells = [ell for ell in range(11, 102) if factorization(ell) == [(ell, 1)]]
    matches = successes = 0
    for d in ds:
        for ell in ells:
            actual = decision(d, Fraction(1, 2*ell - 1))[0]
            assert actual == prime_parameter(d, ell), (d, ell, actual)
            successes += actual
            matches += 1
        assert not decision(d, Fraction(1, 25))[0]
        assert decision(d, Fraction(1, 33))[0] == (d == -3)
    print(f"Finite decision vs. prime-parameter criterion: {matches:,} agreements, {successes:,} attainable.")
    print(f"Range: {len(ds)} fields with |d| <= 300; {len(ells)} prime parameters 11 through 101.")
    print("No field in range admits 1/25. Only d = -3 admits 1/33.")
    global_ells = [ell for ell in range(11, 1001) if factorization(ell) == [(ell, 1)]]
    accepted = 0
    for ell in global_ells:
        numbers = (2*ell-1, 2*ell+1, 6*ell-1, 6*ell+1)
        left, right, lower, upper = [factorization(n) == [(n, 1)] for n in numbers]
        expected = left or right or (lower and upper)
        assert decision(None, Fraction(1, 2*ell - 1))[0] == expected
        accepted += expected
    print(f"Field allowed to vary: {len(global_ells)} prime parameters through 1,000, {accepted} attainable.")


def isolated_example(limit=10_000_000):
    flags = prime_flags(limit)
    d, conductors = -3, (101, 103)
    examples = ((7, 1, 1093), (7, 3, 1137))
    groups, direct = [], []
    for f, example in zip(conductors, examples):
        classes = reduced_forms(d*f*f)
        inverse = {(a, abs(b), c) for a,b,c in classes}
        groups.append({form for form in inverse if orbit_size(form) == 2})
        assert len(classes) == 34 and len(inverse) == 18 and len(groups[-1]) == 16
        assert example in groups[-1]
        direct.append(represented_primes(example, flags))
    counts = Counter()
    totals = [Counter(), Counter()]
    for p in range(7, limit + 1, 6):
        if not flags[p] or p in conductors:
            continue
        generator = 2
        w = pow(generator, (p-1)//3, p)
        while w == 1:
            generator += 1
            w = pow(generator, (p-1)//3, p)
        root = (2*w + 1) % p
        assert (root*root + 3) % p == 0
        pair = tuple(class_at_prime(p, root, d, f) for f in conductors)
        for i, form in enumerate(pair):
            if form == examples[i]:
                assert p in direct[i]
            totals[i][form] += 1
        counts[pair] += 1
    for i in range(2):
        clean = direct[i] - {2, 3, *conductors}
        assert totals[i][examples[i]] == len(clean)
    clean_common = (direct[0] & direct[1]) - {2, 3, *conductors}
    assert counts[examples] == len(clean_common)
    observed = [counts[left, right] for left in groups[0] for right in groups[1]]
    assert len(observed) == 256 and min(observed) > 0
    both, either = len(direct[0] & direct[1]), len(direct[0] | direct[1])
    print(f"Primes through {limit:,}: {sum(flags):,}. Both class numbers by reduction: 34.")
    print(f"One-element inverse orbits: 2 per conductor. Two-element orbits: 16 per conductor.")
    print(f"All 256 non-self-inverse pairs occurred, with {min(observed):,} to {max(observed):,} common unramified primes each.")
    print(f"Displayed polynomials: left {len(direct[0]):,}, right {len(direct[1]):,}, both {both:,}, either {either:,}.")
    print(f"Observed J = {both/either:.8f}; proved limit = 1/33.")
    print("Direct ellipse enumeration agreed with prime-form reduction for both displayed forms.")


if __name__ == "__main__":
    small_class_audit()
    arithmetic_audit()
    isolated_example()
    larger = prime_flags(100_000_000)
    left = represented_primes((7, 1, 1093), larger)
    right = represented_primes((7, 3, 1137), larger)
    common, union = len(left & right), len(left | right)
    print(f"Through 100,000,000: {len(left):,} left, {len(right):,} right, {common:,} both, {union:,} either.")
    print(f"Observed J at the larger cutoff: {common/union:.8f}.")
