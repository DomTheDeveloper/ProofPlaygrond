"""Direct finite checks for The overlap spectrum of primes represented by quadratic forms.

Run with Python 3.9 or later. No external packages are required.
"""
import argparse
from fractions import Fraction
from math import gcd, isqrt


def prime_flags(limit):
    flags = bytearray([1]) * (limit + 1)
    flags[:2] = bytes(2)
    for p in range(2, isqrt(limit) + 1):
        if flags[p]:
            flags[p*p::p] = bytes((limit - p*p) // p + 1)
    return flags


def represented_primes(form, flags):
    """List actual prime values of a positive-definite form by completing the square."""
    a, b, c = form
    abs_discriminant = 4*a*c - b*b
    limit = len(flags) - 1
    assert a > 0 and abs_discriminant > 0
    result = set()
    # (2ax+by)^2 + |D|y^2 = 4aQ(x,y). By symmetry, y >= 0 suffices.
    for y in range(isqrt(4*a*limit // abs_discriminant) + 1):
        radius = isqrt(4*a*limit - abs_discriminant*y*y)
        lo = -((radius + b*y) // (2*a))
        hi = (radius - b*y) // (2*a)
        for x in range(lo, hi + 1):
            value = a*x*x + b*x*y + c*y*y
            if value >= 2 and flags[value]:
                result.add(value)
    return result


def reduced_forms(discriminant):
    """Enumerate proper classes via the unique reduced representatives."""
    assert discriminant < 0 and discriminant % 4 in (0, 1)
    classes = []
    for a in range(1, isqrt(-discriminant // 3) + 1):
        for b in range(-a, a + 1):
            c, rem = divmod(b*b - discriminant, 4*a)
            if rem or a > c or (b < 0 and (abs(b) == a or a == c)):
                continue
            if gcd(gcd(a, abs(b)), c) == 1:
                classes.append((a, b, c))
    return classes


def subform(f, t):
    return (t*t, 2*t, f*f+1)


def sample(name, lhs, rhs, target, nominal_nesting, flags):
    left = represented_primes(lhs, flags)
    right = represented_primes(rhs, flags)
    both = left & right
    either = left | right
    if nominal_nesting:
        assert right <= left
    if target == 0:
        assert both <= {5}  # The residue classes mod 5 are disjoint on units.
    observed = f'{len(both) / len(either):.6f}' if either else 'n/a'
    print(f'{name:22} {len(left):8,} {len(right):8,} {len(both):8,} '
          f'{len(either):8,} {observed:>10} {str(target):>7}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--limit', type=int, default=1_000_000)
    limit = parser.parse_args().limit
    if limit < 2:
        parser.error('--limit must be at least 2')
    flags = prime_flags(limit)
    examples = []
    for n in (3, 4, 5, 8):
        examples.append((f'Nested, n={n}', (1, 0, n*n), subform(n, n),
                         Fraction(2, n), True))
    examples.extend([
        ('Incomparable, n=4', (4, 2, 7), (7, 3, 9), Fraction(1, 2), False),
        ('Incomparable, n=5', subform(12, 3), subform(12, 4),
         Fraction(2, 5), False),
        ('Zero overlap', (1, 0, 5), (2, 2, 3), Fraction(0), False),
        ('Full overlap', (1, 0, 1), (1, 0, 4), Fraction(1), True),
    ])
    print(f'Prime cutoff {limit:,} ({sum(flags):,} primes).')
    print(f'{"Pair":22} {"Left":>8} {"Right":>8} {"Both":>8} {"Either":>8} '
          f'{"Observed":>10} {"Limit":>7}')
    for item in examples:
        sample(*item, flags)
    # Verify class numbers independently by enumerating reduced forms.
    for n in range(3, 13):
        lower = reduced_forms(-4*n*n)
        higher = reduced_forms(-4*n**4)
        assert len(higher) == n * len(lower)
        a, b, c = subform(n, n)
        assert (a, b, c) in higher and (a, -b, c) in higher
    assert len(reduced_forms(-27)) == 1
    assert len(reduced_forms(-108)) == len(reduced_forms(-243)) == 3
    assert (4, 2, 7) in reduced_forms(-108) and (7, 3, 9) in reduced_forms(-243)
    # Check that two distinct inverse residues lift 1 modulo n in the split example.
    for n in range(3, 101):
        lifts = [a for a in range(1, n*n, n) if gcd(a, n*n) == 1]
        assert len(lifts) == n
        assert (1+n) * (1-n) % (n*n) == 1
        assert {(1+n) % (n*n), (1-n) % (n*n)} <= set(lifts)
    print('Reduced-form and residue-class checks passed.')


if __name__ == '__main__':
    main()
