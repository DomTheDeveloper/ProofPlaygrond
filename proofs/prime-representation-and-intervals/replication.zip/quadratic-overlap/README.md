# The Prime-Overlap Spectrum Theorem for Binary Quadratic Forms

The manuscript classifies the limiting proportion of common primes among those represented by at least one of two primitive positive-definite integral binary quadratic forms. With unrestricted individual densities it proves that every allowed value occurs with both prime sets arbitrarily sparse. When both forms belong to a prescribed imaginary quadratic field and each misses infinitely many of the other’s primes, the maximum is one half if 2 is inert, and two fifths otherwise. With equal individual densities the attainable values obey a separate finite criterion. An overlap of 1/33 then forces conductors 101 and 103 in the Eisenstein field, with each set representing exactly 1/34 of all primes. The proofs are unconditional.

## Manuscript

With a standard TeX Live installation, run the following twice in the extracted directory.

```sh
pdflatex Prime-Overlap-Theorem.tex
```

Pages 1–4 give the classification and constructions. Page 5 treats congruence tests and forms of positive discriminant. Pages 7–8 prove the equal-density family and sparsity strengthening, and derive the first extremal example again using Gauss’s cubic criteria. Pages 9–10 compare the claims with prior work, including Buell’s lift and an exact joint density computed by Campos-Vargas. Pages 11–13 prove the equal-density restriction, exhibit a quarter-overlap family with different fields, and give the full fixed-field spectrum. Page 14 documents the first fixed-field checks. Pages 15–16 contain the complete equal-density decision theorem for a prescribed field and for existence in some common field. Pages 17–18 prove the closed prime-parameter criterion. Page 19 gives the 1/25 exclusion and the 1/33 example. Page 20 proves density one for excluded prime parameters and identifies the precise prime-tuples problem. Page 21 classifies every one-half pair. Page 22 reports the independent checks and cites the theory used.

## Decide a proposed overlap

Supply a negative fundamental discriminant and an exact rational. Use `any` to ask whether some common imaginary quadratic field works. The test exhausts the finite cases in Theorem A. Its running time increases with the denominator.

```sh
python3 equal_density_spectrum.py -3 1/33
python3 equal_density_spectrum.py any 1/25
python3 equal_density_spectrum.py -11 1/2
```

## Reproduce the checks

With Python 3.9 or later, run the four scripts from the extracted directory. All use only the standard library.

```sh
python3 check_examples.py
python3 check_sparse_family.py
python3 audit_equal_density.py
python3 audit_full_spectrum.py
```

The first enumerates prime values and small reduced-form classes. The second checks the three exact set identities for the Eisenstein family at five levels and verifies the four class numbers used at each level. Both enumerate primes through one million by default. Their outputs are recorded in `example-counts.txt` and `sparse-family-counts.txt`.

The third script checks the odd-index lemma for negative fundamental discriminants through absolute value 1000 and conductor pairs through 200. It also checks the quarter-overlap family and fixed-field examples against direct prime representations through ten million. The output is in `equal-density-checks.txt`. Use `--help` to change the cutoffs for this script.

The fourth script independently restricts reduced forms using represented unramified primes, cross-checks the general decision against the closed prime criterion, and compares integer-point enumeration against reduction of prime forms for the conductors 101 and 103. It also enumerates the displayed pair through 100 million. Its exact output is in `full-spectrum-checks.txt`.
    
A separate C++17 implementation enumerates both boundary pairs and compares them prime by prime with arithmetic criteria. At the incomparable boundary the two independent checks are modular exponentiations for 2 and 3. At the nested boundary it checks a congruence and the partition given by uniqueness of a prime's two-squares representation.

```sh
c++ -std=c++17 -O3 audit_boundaries.cpp -o audit_boundaries
./audit_boundaries
```

The default is 100 million. Pass a smaller integer as the sole argument for a quicker run. The full output is in `audit-boundary-counts.txt`. These computations illustrate the limits and check individual representations. The proof covers all primes, all parameters, and all positive-definite pairs.
