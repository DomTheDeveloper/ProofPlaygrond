# Congruence rules for primes represented by binary quadratic forms

This archive accompanies *Which primes can a quadratic form represent?*, a computational research note dated 20 November 2026. All code uses the Python 3 standard library. The files are generated from the reduction inequalities for binary quadratic forms.

## Results

Let Q(x,y) = ax² + bxy + cy² have integer coefficients, a > 0, gcd(a,b,c) = 1 and discriminant Δ = b² − 4ac < 0. Write P(Q) for the set of primes that occur as values Q(x,y), x,y integers. Following Clark, Hicks, Parshall and Thompson, Q is regular if membership in P(Q) for p not dividing 2Δ depends only on p modulo some integer.

Among the regular forms there are **1,400 different prime sets up to finite differences**, and **1,439 different prime sets when all primes are counted**. The largest least modulus for a rule away from 2Δ is **40,755**. The underlying complete catalog has 425 discriminants and 2,779 proper form classes. Proper equivalence means an integral change of variables of determinant 1.

For example, x² + y² and x² + 4y² both give p ≡ 1 (mod 4) at all odd primes. Only x² + y² represents 2. In the catalogs these are two exact sets associated with one congruence rule.

## Running the computation

From the unzipped directory:

```sh
python3 classify.py --csv regenerated-forms.csv --rules-csv regenerated-rules.csv --check-primes 10000
python3 check_prime_sets.py
```

The first command enumerates all representatives, derives the congruences, checks their local images and cross-checks actual representations. Use a Python interpreter with assertions enabled. The second program independently reads `forms.csv` and groups the actual represented primes. It computes the counts without Legendre symbols or genus theory, using the finite catalog and an integer search. The proof in the note explains why the symbolic rules distinguish infinite prime sets and why the finite catalog is complete.

## Files

- `forms.csv` has one row per proper class and its coefficients, discriminant, congruence rule and exceptional represented primes.
- `rules.csv` has one row per distinct congruence rule with a representative, its least modulus and the number of corresponding form classes and exact prime sets.
- `classify.py` builds both catalogs from scratch. The optional scan covers all 1,229 primes up to 10,000 and all 2,779 forms, for 3,415,391 membership checks.
- `check_prime_sets.py` separately enumerates Q(x,y) over an enclosing rectangle. It checks all 1,439 exact prime-set labels and all 1,400 congruence-rule labels.
- `results.txt` records both program outputs for the distributed catalogs.

The signs in `odd_prime_legendre_signs` have the format q:+1 or q:-1. For a good prime p, test the given sign of the Legendre symbol (p/q) at every q in the column and test p modulo 8 against `allowed_odd_residues_mod_8`. An empty signs entry places no restriction at odd q. If p divides 2Δ, membership is given exactly by `represented_primes_dividing_2D`; an empty entry represents an empty set. IDs are local catalog identifiers. They follow the deterministic ordering in the generator.

## Proof of exhaustiveness

1. [Clark, Hicks, Parshall and Thompson, *Integers* 13 (2013), A37](https://math.colgate.edu/~integers/n37/n37.pdf), Theorems 1 and 2, characterize the regular forms and give the modular tests. Their table enumerates 2,779 classes and records a small correction to an earlier table. Its completeness was conditional on GRH.
2. [Voight, *Mathematics of Computation* 76 (2007), §§5 and 8](https://jvoight.github.io/articles/quadforms-mcom-fixed-errata-071918.pdf), Proposition 8.4, shows that a candidate fundamental discriminant d obeys |d| < 13,000,000,000 whenever its quadratic field zeta function is zero-free on [1 − 2/log|d|, 1). The proof of Theorem 8.6 states that this bound and the finite computations in §8 give precisely 226 maximal and 199 nonmaximal-order discriminants. The distinction between field discriminant d and order discriminant Δ = df² matters here.
3. The released [7/8 zero-free theorem](https://github.com/openai/math/tree/main/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026) applies to the Riemann zeta function and to every Dirichlet L-function. The [formal theorem statements](https://github.com/openai/math/blob/main/lean/docs/003.md) cover this precise scope. For |d| ≥ 13,000,000,000, log|d| > 16, so Voight's entire interval lies strictly to the right of 7/8. Since ζ_K(s) = ζ(s)L(s,χ_d), the interval is zero-free. Proposition 8.4 thus rules out every hypothetical large field, and the author's cited finite work covers the smaller fields and their qualifying orders. This implication uses the earlier 7/8 result independently of the November full-RH announcement.
4. The program regenerates the regular forms with |Δ| ≤ 87,360, the largest discriminant magnitude in the final 2013 table. The unique reduced representatives satisfy |b| ≤ a ≤ c with b ≥ 0 on either boundary. A class equals its inverse exactly when b=0, |b|=a or a=c. If h is the class number and t the number of such classes, h/t is the size of the square subgroup. When h/t=1 every class is regular. When h/t=2 the non-self-inverse classes are regular. All other cases give no regular classes. This is the subgroup criterion in Theorem 1. The resulting 425 discriminants and 2,779 proper classes attain the proven total.
5. For each form the odd-prime Legendre signs are fixed independently at exactly the odd prime divisors of Δ. The remaining conditions depend only on p mod 8, as derived in Theorem 2 and quadratic reciprocity. A signature consists of the signed list and that permitted subset of {1,3,5,7}. Two distinct signatures differ on at least one unit residue class modulo their combined period by the Chinese remainder theorem. Dirichlet's theorem gives infinitely many primes in that class. Thus comparing signatures is equivalent to comparing the prime sets up to finite differences. The exact membership of each prime dividing 2Δ is obtained by testing the identity 4ap = (2ax+by)² + |Δ|y² with bounded integer y. Grouping by signatures and then by these exceptional lists gives 1,400 and 1,439.
6. Each odd prime in the signed list is an essential factor of any possible modulus: while fixing the other conditions one may reverse its Legendre sign. The least 2-part is 1 if all four odd residues are allowed, 4 if membership depends nontrivially only on p mod 4, and 8 otherwise. These factors yield the least modulus of each rule by the Chinese remainder theorem and Dirichlet's theorem. The maximum 40,755 is attained by 23x² + xy + 443y². It requires signs −, −, +, +, + at the respective primes 3, 5, 11, 13 and 19.
7. Ignoring all primes dividing any catalog discriminant, direct enumeration separates all 1,400 rules using the 258 good primes through 1,979. Ending just before 1,979 yields 1,399 distinct sample patterns. The classification also reproduces Voight's independent check: 67 rules are shared by two or more fundamental fields, six by three fields, and there are 111 pairs across different fields in his convention.

This is an independently generated research computation and a deduction from existing theorems. First publication of the counts is unconfirmed.
