"""Independent direct check from the catalog, without using genus characters.

The two counts here come from literal integer values of the listed forms.
The separate proof establishes equality and distinction for all primes.
"""
import csv
from math import isqrt
from pathlib import Path

N = 10_000
root = Path(__file__).resolve().parent
with (root / 'forms.csv').open(newline='') as f:
    forms = list(csv.DictReader(f))

sieve = bytearray([1]) * (N + 1)
sieve[:2] = bytes(2)
for divisor in range(2, isqrt(N) + 1):
    if sieve[divisor]:
        sieve[divisor**2::divisor] = bytes((N - divisor**2) // divisor + 1)
primes = [p for p in range(2, N + 1) if sieve[p]]
discriminants = {abs(int(row['discriminant'])) for row in forms}
good = [p for p in primes if p > 2 and all(d % p for d in discriminants)]
good_set = set(good)

ordinary, exact = {}, {}
for row in forms:
    a, b, c = (int(row[col]) for col in ('a','b','c'))
    d = 4*a*c - b*b
    assert d == -int(row['discriminant'])
    # The square-completion identity bounds a rectangle in (x,y).
    # Exhaust it using Q itself; symmetry permits y >= 0.
    y_bound = isqrt((4*a*N)//d)
    x_bound = (isqrt(4*a*N) + abs(b)*y_bound)//(2*a)
    values = set()
    for x in range(-x_bound, x_bound + 1):
        for y in range(y_bound + 1):
            value = a*x*x + b*x*y + c*y*y
            if 2 <= value <= N and sieve[value]:
                values.add(value)
    pattern = frozenset(values & good_set)
    all_primes_pattern = frozenset(values)
    i, j = int(row['rule_id']), int(row['exact_prime_set_id'])
    assert ordinary.setdefault(i, pattern) == pattern
    assert exact.setdefault(j, all_primes_pattern) == all_primes_pattern

assert len(set(ordinary.values())) == len(ordinary) == 1400
assert len(set(exact.values())) == len(exact) == 1439
initial = frozenset(p for p in good if p <= 1979)
assert len(initial) == 258
assert len({s & initial for s in ordinary.values()}) == 1400
assert len({s & (initial - {1979}) for s in ordinary.values()}) == 1399
print(f"{len(forms)} forms, {len(primes)} primes, {len(forms)*len(primes):,} checks.")
print("Observed 1,400 distinct patterns on the common good primes and 1,439 on all primes.")
print("All 1,400 ordinary patterns are distinguished on the 258 common good primes through 1,979.")
