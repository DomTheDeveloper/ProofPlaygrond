"""Compute congruence tests for primes represented by primitive positive definite forms.

All computations are exact. Standard Python 3. The proof of completeness and the
mathematical inputs are set out in the companion note.
"""
import argparse
import csv
from collections import Counter, defaultdict
from functools import lru_cache
from math import gcd, isqrt, prod
from pathlib import Path

LIMIT = 87360
ODD_EIGHTHS = (1, 3, 5, 7)


def reduced_unsigned(limit):
    # Use the unique standard reduced representative for each proper class.
    # Interior forms come with both signs of B. Boundary forms must have B >= 0.
    for a in range(1, isqrt(limit // 3) + 1):
        for b in range(a + 1):
            common = gcd(a, b)
            for c in range(a, (limit + b*b) // (4*a) + 1):
                if gcd(common, c) == 1:
                    yield 4*a*c-b*b, a, b, c, b == 0 or b == a or c == a


def regular_forms():
    h, ambiguous = Counter(), Counter()
    for d, _, _, _, boundary in reduced_unsigned(LIMIT):
        h[d] += 1 if boundary else 2
        ambiguous[d] += boundary
    # The size of Cl(D)^2 is h divided by the number of elements of order <=2.
    kind = {d: h[d] // ambiguous[d] for d in h if h[d] <= 2 * ambiguous[d]}
    assert all(h[d] == kind[d] * ambiguous[d] and kind[d] in (1, 2) for d in kind)
    forms = []
    for d, a, b, c, boundary in reduced_unsigned(LIMIT):
        if d in kind and (kind[d] == 1 or not boundary):
            forms.append((d, a, b, c))
            if not boundary:
                forms.append((d, a, -b, c))
    return sorted(forms), kind


@lru_cache(None)
def factors(n):
    items = []
    p = 2
    while p*p <= n:
        power = 0
        while n % p == 0:
            n //= p
            power += 1
        if power:
            items.append((p, power))
        p = 3 if p == 2 else p + 2
    if n > 1:
        items.append((n, 1))
    return tuple(items)


def legendre(v, p):
    residue = pow(v % p, (p-1)//2, p)
    return -1 if residue == p-1 else residue


def rule(d, a, b, c):
    # d is |Delta|. For each odd prime q|d impose a Legendre sign.
    odds = []
    sign_minus = 1  # Delta is negative, hence a factor (-1/p).
    power_of_two = 0
    odd_product = 1
    for q, power in factors(d):
        if q == 2:
            power_of_two = power
            continue
        nonzero = a if a % q else c
        sign = legendre(nonzero, q)
        assert sign in (-1, 1)
        odds.append((q, sign))
        if power % 2:
            sign_minus += (q-1)//2
            odd_product *= sign
    allowed = []
    for u in ODD_EIGHTHS:
        # Quadratic reciprocity for (Delta/p), using u = p mod 8.
        minus_symbol = -1 if u % 4 == 3 else 1
        two_symbol = -1 if u in (3, 5) else 1
        if minus_symbol**(sign_minus % 2) * two_symbol**(power_of_two % 2) * odd_product != 1:
            continue
        if d % 16 == 0 and any(v % 2 and u % 4 != v % 4 for v in (a,c)):
            continue
        if d % 32 == 0 and any(v % 2 and u % 8 != v % 8 for v in (a,c)):
            continue
        allowed.append(u)
    assert allowed
    return tuple(odds), tuple(allowed)


def independent_local_check(a, b, c, signature):
    odds, allowed = signature
    local_two = {(a*x*x+b*x*y+c*y*y) % 8 for x in range(8) for y in range(8)}
    assert set(allowed) == local_two & set(ODD_EIGHTHS)
    for q, sign in odds:
        # Over F_q the discriminant vanishes, hence the nonzero values of the
        # binary form comprise a single square class. On the projective line
        # every direction has coordinates (1,t) or (0,1).
        image = {legendre(a + b*t + c*t*t, q) for t in range(q)} | {legendre(c, q)}
        assert image - {0} == {sign}


def least_modulus(signature):
    odds, allowed = signature
    if len(allowed) == 4:
        two_part = 1
    elif allowed in ((1,5),(3,7)):
        two_part = 4
    else:
        two_part = 8
    return two_part * prod(q for q, _ in odds)


def represented_primes(d, a, b, c, last, primes):
    # 4*a*Q(x,y) = (2*a*x + b*y)^2 + d*y^2. Checking y>=0 is enough
    # because Q(x,y)=Q(-x,-y).
    result = set()
    for y in range(isqrt(4*a*last//d) + 1):
        s = isqrt(4*a*last - d*y*y)
        lo = -((s+b*y)//(2*a))
        hi = (s-b*y)//(2*a)
        for x in range(lo, hi+1):
            v = a*x*x + b*x*y + c*y*y
            if v in primes:
                result.add(v)
    return result


def represents(d, a, b, c, p):
    # Test both signs of the square root of 4*a*p - d*y^2, including 0.
    for y in range(isqrt((4*a*p)//d) + 1):
        square = 4*a*p - d*y*y
        root = isqrt(square)
        if root*root == square and ((root-b*y) % (2*a) == 0 or (-root-b*y) % (2*a) == 0):
            return True
    return False


def exceptional_primes(d, a, b, c):
    return tuple(p for p, _ in factors(2*d) if represents(d, a, b, c, p))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', type=Path)
    parser.add_argument('--rules-csv', type=Path)
    parser.add_argument('--check-primes', type=int, default=0)
    args = parser.parse_args()
    forms, kind = regular_forms()
    groups = defaultdict(list)
    for d, a, b, c in forms:
        key = rule(d, a, b, c)
        independent_local_check(a, b, c, key)
        groups[key].append((d, a, b, c))
    print('discriminants:', len(kind), 'types:', dict(Counter(kind.values())))
    print('proper classes:',len(forms),'up to sign of B:',len({(d,a,abs(b),c) for d,a,b,c in forms}))
    print('distinct rules:',len(groups),'least moduli:',len({least_modulus(k) for k in groups}))
    print('largest least modulus:',max(map(least_modulus,groups)))
    print('largest absolute discriminant:',max(d for d,*_ in forms))
    print('multiplicities:',dict(sorted(Counter(map(len, groups.values())).items())))
    records = []
    exact_keys = set()
    for i, key in enumerate(sorted(groups), 1):
        for d, a, b, c in groups[key]:
            exc = exceptional_primes(d, a, b, c)
            exact_key = (i, exc)
            exact_keys.add(exact_key)
            records.append((i, key, d, a, b, c, exc))
    exact_ids = {pair:i for i,pair in enumerate(sorted(exact_keys), 1)}
    print('distinct full prime sets:', len(exact_ids))
    field_profile = Counter()
    mixed_pairs = 0
    for forms_for_rule in groups.values():
        # Identify opposite middle coefficients, which are integrally equivalent
        # by (x,y) -> (x,-y), before counting Voight's cross-field pairs.
        unsigned = {(d,a,abs(b),c) for d,a,b,c in forms_for_rule}
        field_counts = Counter()
        for d, a, b, c in unsigned:
            squarefree = -prod(p for p,e in factors(d) if e % 2)
            field_d = squarefree if squarefree % 4 == 1 else 4*squarefree
            field_counts[field_d] += 1
        field_profile[len(field_counts)] += 1
        mixed_pairs += (len(unsigned)**2 - sum(n*n for n in field_counts.values())) // 2
    print('rules spanning 1, 2, 3 quadratic fields:',tuple(field_profile[n] for n in (1,2,3)))
    print('different-field pairs in Voight convention:', mixed_pairs)
    assert sum(n for k,n in field_profile.items() if k>=2) == 67
    assert field_profile[3] == 6 and mixed_pairs == 111
    if args.rules_csv:
        variants = defaultdict(set)
        for i,exc in exact_keys:
            variants[i].add(exc)
        with args.rules_csv.open('w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['rule_id','least_modulus','allowed_odd_residues_mod_8',
                             'odd_prime_legendre_signs','proper_form_classes','exact_prime_sets',
                             'example_a','example_b','example_c'])
            for i,(key,entries) in enumerate(sorted(groups.items()),1):
                odds,allowed = key
                _,a,b,c = entries[0]
                writer.writerow([i,least_modulus(key),'/'.join(map(str,allowed)),
                                 ' '.join(f'{q}:{s:+d}' for q,s in odds),len(entries),
                                 len(variants[i]),a,b,c])
    if args.csv:
        with args.csv.open('w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['rule_id','exact_prime_set_id','discriminant','a','b','c','least_modulus','allowed_odd_residues_mod_8','odd_prime_legendre_signs','represented_primes_dividing_2D'])
            for i,key,d,a,b,c,exc in records:
                odds,allowed=key
                writer.writerow([i,exact_ids[(i,exc)],-d,a,b,c,least_modulus(key),'/'.join(map(str,allowed)),
                                 ' '.join(f'{q}:{sign:+d}' for q,sign in odds),' '.join(map(str,exc))])
    if args.check_primes:
        last = args.check_primes
        primes = {n for n in range(2,last+1) if all(n%v for v in range(2,isqrt(n)+1))}
        common = sorted(primes - {p for d in kind for p,_ in factors(2*d)})
        global_masks, full_masks = {}, {}
        number_tests = 0
        for i,key,d,a,b,c,exc in records:
            odds,allowed = key
            predicted = {p for p in primes if p%8 in allowed and all(legendre(p,q)==sign for q,sign in odds)}
            # Directly enumerate Q(x,y) for ALL primes; this method does not use
            # either modular predicates or the separate test for ramified primes.
            actual = represented_primes(d,a,b,c,last,primes)
            assert actual == predicted | (set(exc) & primes), (d,a,b,c)
            number_tests += len(primes)
            observed = sum(1 << j for j,p in enumerate(common) if p in actual)
            assert global_masks.setdefault(i,observed) == observed
            full = frozenset(actual)
            assert full_masks.setdefault((i,exc),full) == full
        obs_count = len(set(global_masks.values()))
        full_count = len(set(full_masks.values()))
        print('direct form/prime tests:', number_tests, 'through', last)
        print('distinct patterns on globally unramified sample:',obs_count)
        print('distinct patterns including exceptional primes:',full_count)
        if obs_count == len(groups):
            lo, hi = 0, len(common)
            while lo < hi:
                mid = (lo+hi)//2
                mask = (1<<mid)-1
                if len({x & mask for x in global_masks.values()}) == len(groups):
                    hi = mid
                else:
                    lo = mid+1
            print('first globally unramified prime cutoff distinguishing all rules:',common[lo-1])
        if last >= 10000:
            assert obs_count == len(groups) and full_count == len(exact_keys)
    assert len(forms)==2779 and len(kind)==425
    assert len(groups)==1400 and len(exact_keys)==1439


if __name__=='__main__':
    main()
