// Verify the minimum length of a freely chosen contiguous window of interior
// bits that guarantees a prime in every odd, exact-width 32-bit binary format.
// Build: c++ -std=c++20 -O3 prime_window.cpp -o prime_window
// Run:   ./prime_window          (or ./prime_window 7 8 for specific lengths)
// No external libraries or unproved number-theoretic assumptions are used.
#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using std::uint32_t;
using std::uint64_t;
constexpr uint32_t interior_bits = 30;
constexpr uint64_t first_odd = (uint64_t{1} << 31) + 1;
constexpr uint32_t odd_count = uint32_t{1} << interior_bits;

std::vector<uint32_t> small_odd_primes() {
    constexpr unsigned limit = 65535;
    std::vector<bool> prime(limit + 1, true);
    for (unsigned p = 2; p * p <= limit; ++p) {
        if (prime[p])
            for (unsigned m = p * p; m <= limit; m += p)
                prime[m] = false;
    }
    std::vector<uint32_t> result;
    for (unsigned p = 3; p <= limit; p += 2)
        if (prime[p]) result.push_back(p);
    return result;
}

std::vector<uint64_t> sieve_interval() {
    const auto divisors = small_odd_primes();
    std::vector<uint64_t> bits(odd_count / 64);
    constexpr uint32_t segment_size = 1u << 17;
    std::vector<unsigned char> segment(segment_size);
    uint64_t prime_count = 0;
    // Bit j represents first_odd + 2*j. Every composite has an odd
    // prime factor <= 65535, and first_odd exceeds every sieving prime.
    for (uint32_t offset = 0; offset < odd_count; offset += segment_size) {
        std::fill(segment.begin(), segment.end(), 1);
        const uint64_t low = first_odd + 2ULL * offset;
        for (const auto p : divisors) {
            uint64_t multiple = ((low + p - 1) / p) * p;
            if (multiple % 2 == 0) multiple += p;
            for (auto j = (multiple - low) / 2; j < segment_size; j += p)
                segment[j] = 0;
        }
        for (uint32_t j = 0; j < segment_size; j += 64) {
            uint64_t word = 0;
            for (unsigned bit = 0; bit < 64; ++bit) {
                if (segment[j + bit]) {
                    word |= uint64_t{1} << bit;
                    ++prime_count;
                }
            }
            bits[(offset + j) / 64] = word;
        }
    }
    std::cout << "Primes in [2^31, 2^32): " << prime_count << '\n';
    return bits;
}

void check_width(const std::vector<uint64_t>& prime, unsigned width) {
    uint64_t tested = 0, failed = 0;
    bool printed_witness = false;
    // The word is 1 | high bits | free bits | low bits | 1.
    // The initial and trailing 1 are implicit in first_odd + 2*j.
    for (unsigned low_bits = 0; low_bits + width <= interior_bits; ++low_bits) {
        const unsigned high_bits = interior_bits - low_bits - width;
        const uint32_t stride = 1u << low_bits;
        const uint32_t choices = 1u << width;
        uint64_t misses = 0;
        for (uint32_t high = 0; high < (1u << high_bits); ++high) {
            for (uint32_t low = 0; low < stride; ++low) {
                const uint32_t base = (high << (low_bits + width)) | low;
                bool has_prime = false;
                for (uint32_t middle = 0; middle < choices; ++middle) {
                    const uint32_t j = base + middle * stride;
                    if ((prime[j / 64] >> (j % 64)) & 1u) {
                        has_prime = true;
                        break;
                    }
                }
                if (!has_prime) {
                    ++misses;
                    if (!printed_witness) {
                        std::cout << "Witness for width " << width << ": "
                                  << first_odd + 2ULL * base << " + "
                                  << 2ULL * stride << " * m, 0 <= m < " << choices << '\n';
                        printed_witness = true;
                    }
                }
            }
        }
        const uint32_t templates = 1u << (interior_bits - width);
        std::cout << "width=" << width << " low_window_bit=" << low_bits + 1
                  << " templates=" << templates << " misses=" << misses << '\n';
        tested += templates;
        failed += misses;
    }
    std::cout << "Total for width " << width << ": " << tested
              << " templates, " << failed << " prime-free.\n" << std::flush;
}

// Count primes by deleting the eight free bits from the index of each prime.
// This counts one prime at a time. The Python verifier instead sums along
// an array axis for each group of 256 candidates.
void count_eight_bit_completions(const std::vector<uint64_t>& prime) {
    constexpr unsigned width = 8;
    std::vector<std::uint16_t> counts(1u << (interior_bits - width));
    std::vector<uint64_t> histogram((1u << width) + 1);
    for (unsigned low_bits = 0; low_bits <= interior_bits - width; ++low_bits) {
        std::fill(counts.begin(), counts.end(), 0);
        const uint32_t low_mask = (1u << low_bits) - 1;
        for (uint32_t slot = 0; slot < prime.size(); ++slot) {
            uint64_t word = prime[slot];
            while (word != 0) {
                const uint32_t j = slot * 64 + std::countr_zero(word);
                const uint32_t high = j >> (low_bits + width);
                const uint32_t key = (high << low_bits) | (j & low_mask);
                ++counts[key];
                word &= word - 1;
            }
        }
        for (const auto count : counts) ++histogram[count];
    }
    const auto first = std::find_if(histogram.begin(), histogram.end(),
                                    [](uint64_t n) { return n != 0; });
    std::cout << "Width 8 minimum: " << (first - histogram.begin())
              << " primes; attained by " << *first << " templates.\n";
}

int main(int argc, char** argv) {
    std::vector<unsigned> widths;
    for (int i = 1; i < argc; ++i) {
        const std::string value(argv[i]);
        std::size_t parsed = 0;
        try {
            const auto width = std::stoul(value, &parsed);
            if (parsed != value.size() || width < 1 || width > interior_bits)
                throw std::invalid_argument("width");
            widths.push_back(static_cast<unsigned>(width));
        } catch (const std::exception&) {
            std::cerr << "Widths must be integers from 1 to 30.\n";
            return 1;
        }
    }
    if (widths.empty()) widths = {7, 8};
    const auto prime = sieve_interval();
    for (auto width : widths) {
        check_width(prime, width);
        if (width == 8) count_eight_bit_completions(prime);
    }
}
