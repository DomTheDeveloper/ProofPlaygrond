"""Exact prime counts for every 7- and 8-bit interior window of a 32-bit word.

Run with Python 3.9+ and NumPy. Peak memory is about 1.1 GiB.
Each bit at either end of the word is fixed to one.
"""
from math import isqrt
import numpy as np

WORD_BITS = 32
INTERIOR_BITS = WORD_BITS - 2
FIRST_ODD = (1 << (WORD_BITS - 1)) + 1


def prime_flags():
    """Entry j is true exactly when FIRST_ODD + 2*j is prime."""
    limit = isqrt((1 << WORD_BITS) - 1)
    small = np.ones(limit + 1, dtype=bool)
    small[:2] = False
    for p in range(2, isqrt(limit) + 1):
        if small[p]:
            small[p*p::p] = False
    divisors = [int(p) for p in np.flatnonzero(small) if p != 2]
    odd = np.empty(1 << INTERIOR_BITS, dtype=bool)
    block_size = 1 << 20
    # Solve FIRST_ODD + 2*j == 0 (mod p) for each odd sieving prime.
    residues = [(-FIRST_ODD * ((p + 1) // 2)) % p for p in divisors]
    for start in range(0, odd.size, block_size):
        block = odd[start:start + block_size]
        block.fill(True)
        for p, residue in zip(divisors, residues):
            block[(residue - start) % p::p] = False
    return odd


def check_width(odd, width):
    histogram = np.zeros((1 << width) + 1, dtype=np.int64)
    minimum = 1 << width
    witnesses = []
    for low_bits in range(INTERIOR_BITS - width + 1):
        # Axes are the fixed high bits, the free bits and the fixed low bits.
        # Each cell in counts is one template; its value is its number of primes.
        choices = odd.reshape(-1, 1 << width, 1 << low_bits)
        counts = choices.sum(axis=1, dtype=np.uint16)
        histogram += np.bincount(counts.ravel(), minlength=histogram.size)
        local_min = int(counts.min())
        if local_min < minimum:
            minimum = local_min
            witnesses = []
        if local_min == minimum:
            for high, low in zip(*np.nonzero(counts == minimum)):
                j = (int(high) << (low_bits + width)) + int(low)
                witnesses.append((FIRST_ODD + 2*j, 1 << (low_bits + 1)))
    print(f"Width {width}: {histogram.sum():,} templates, minimum {minimum}, "
          f"attained by {histogram[minimum]:,} templates.")
    print("First extremal template(s) as (base, step):", witnesses[:2])
    if width == 8:
        for base, step in witnesses:
            primes = [base + step*k for k in range(1 << width)
                      if odd[(base + step*k - FIRST_ODD) // 2]]
            print(f"base {base:#x}, step {step}: {primes}")
    print("Histogram for counts 0 through 10:", histogram[:11].tolist(), flush=True)


if __name__ == "__main__":
    flags = prime_flags()
    print(f"Primes: {np.count_nonzero(flags):,}", flush=True)
    for width in (7, 8):
        check_width(flags, width)
