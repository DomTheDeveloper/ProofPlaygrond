# How many consecutive bits guarantee a 32-bit prime?

## Exact finite result

Take any 32-bit binary word with its leading and trailing bits fixed to 1. Select any eight consecutive positions among the 30 interior bits. Assign arbitrary values to the other 22 interior positions. Among the 256 fillings of the eight free positions, at least four give primes. Exactly two templates have only four prime completions. With seven consecutive free bits, 137 templates have no prime completion. Thus eight is the least universally sufficient width, and four is the sharp multiplicity at width eight.

These findings were computed with AI assistance on November 20, 2026. The statement concerns numbers in [2^31, 2^32). It is unconditional.

## Why the enumeration proves the claim

Every odd number in the interval has a unique representation n = 2^31 + 1 + 2j, with 0 ≤ j < 2^30. Every composite in the interval has an odd prime divisor at most 65,535. A segmented sieve by precisely these primes therefore tests primality exactly. The resulting list contains 98,182,656 primes.

For a window of k bits with b of the interior positions below it, write j = H·2^(b+k) + M·2^b + L, where 0 ≤ L < 2^b and 0 ≤ M < 2^k. Here H and L are held fixed, and M takes all possible values. Each b from 0 through 30−k describes one placement. For each placement there are exactly 2^(30−k) pairs (H,L).

| Free bits | Placements | Total templates | Least prime completions | Templates attaining minimum |
|---|---:|---:|---:|---:|
| 7 | 24 | 201,326,592 | 0 | 137 |
| 8 | 23 | 96,468,992 | 4 | 2 |

Any shorter window inside a failing seven-bit template also fails when its other bits are fixed to any of their possible values. This proves the minimality statement for all widths below eight.

## Sharp examples

For each row, numbers have the form base + step·m, with 0 ≤ m < 2^k.

| k | Base, hexadecimal | Step | Values of m giving primes |
|---|---|---:|---|
| 7 | 0x89259901 | 2 | None |
| 8 | 0xbc2c0045 | 128 | 30, 80, 89, 171 |
| 8 | 0xcd300d4f | 4,096 | 52, 61, 64, 188 |

## Reproduce the result

The C++20 implementation requires a C++20 compiler and the standard library. It tests each template for existence, then separately traverses the set of primes and counts them by template for all eight-bit placements. The executable uses under 200 MiB of memory on a typical 64-bit system.

```sh
c++ -std=c++20 -O3 prime_window.cpp -o prime_window
./prime_window
```

The Python/NumPy implementation groups a Boolean primality array along the free-bit axis and counts its entries. It requires Python 3.9 or later, NumPy, and about 1.1 GiB of free memory. Both output transcripts are included.

```sh
python count_completions.py
```

## What the literature already establishes

Wacław Sierpiński proved in 1959 that any prescribed leading digits and admissible trailing digits occur together in infinitely many primes. This includes binary prefixes beginning in 1 and suffixes ending in 1. The number of intervening digits is allowed to grow. [Original paper](https://doi.org/10.4064/aa-5-3-265-266) · [Pollack and Singha Roy’s account](https://www.pollack-math.net/DSB.pdf)

The seven-bit counterexample above is already implied by L. J. Lander and T. R. Parkin’s 1967 paper *On First Appearance of Prime Differences*, Table I, page 488. Their consecutive primes 2,300,942,549 and 2,300,942,869 bracket all 128 candidates from 2,300,942,593 through 2,300,942,847. Their published gap therefore establishes the lower bound of eight on the required width. [Table I](https://doi.org/10.1090/S0025-5718-1967-0230677-4)

Glyn Harman, *Primes with preassigned digits*, Acta Arithmetica 125 (2006), discusses prescribing blocks at either end. Jesse Thorner and Asif Zaman, *Refinements to the prime number theorem for arithmetic progressions*, Corollary 3.2, give an asymptotic count for primes with a prescribed prefix and suffix in any base. Their stated condition fixes less than 5/12 of the digits as the word length grows. The eight-bit calculation fixes 24 of 32 positions. [Harman](https://www.impan.pl/shop/en/publication/transaction/download/product/82296) · [Thorner and Zaman](https://arxiv.org/pdf/2108.10878)

The fixed prefix restricts each candidate to a dyadic interval. The fixed suffix restricts it to an odd residue class modulo a power of two. A complete list of the ordinary 32-bit primes already suffices to calculate every count in this report by grouping those data. [Volker Schatz’s complete prime table](https://volkerschatz.de/liberatedcontent/maths/binprimes.html)

As a check for earlier sequence entries, the November 20, 2026 OEIS numerical download contained 401,715 records. Neither of the following runs appeared as a contiguous sequence of terms in those records.

- Minimum sufficient window for word lengths 3 through 22 (allowing a zero-bit window): 0, 1, 2, 2, 3, 3, 4, 4, 4, 5, 5, 5, 6, 5, 6, 6, 6, 6, 7, 7.
- Least number of prime completions for a fixed eight-bit window, for word lengths 10 through 19: 75, 66, 60, 52, 47, 41, 36, 28, 29, 26.

This search covers the main sequence terms and can miss a result stated in comments, papers, supplementary tables, or under a different indexing convention. [OEIS download documentation](https://oeis.org/wiki/Download)

The exhaustive calculation establishes the minimum of four over all placements and outside-bit assignments and identifies its two extremal templates. I found no earlier source explicitly stating those exact statistics. Priority remains unverified. The broad problem, the seven-bit obstruction used here, and the prime data all have prior sources. The evidence supports reporting a finite computation and does not identify a previously open conjecture that this computation settles.

## Related conditional result for 256-bit words

Assume the generalized Riemann hypothesis for Dirichlet L-functions. In a 256-bit word, fix the leading 55 bits, with the first bit 1, and the trailing 64 bits, with the last bit 1. Every such template contains at least 2^(127.5) primes. Uniformly sampling the 137 free middle bits independently and using an exact primality test therefore takes fewer than 725 tests in expectation. Conditional on acceptance, all matching primes are equally likely.

This is an application of A. Dudek, L. Grenié and G. Molteni, *Explicit short intervals for primes in arithmetic progressions on GRH*, Theorem 1.1 and Table 1. [Paper](https://sites.unimi.it/molteni/research/papers-pdf/42-molteni-Explicit_short_intervals_for_primes_in_arithmetic_progressions_on_GRH.pdf)

To see the constants, let x be the midpoint of the interval determined by the high bits. Its radius h is 2^200, and 2^255 < x < 2^256. The fixed suffix gives an odd residue a modulo q = 2^64, with φ(q) = 2^63. The theorem gives at least √x primes when h ≥ φ(q)(2 ln x + 8)√x and √x ≥ 46φ(q)ln q. For the first inequality, the right side is less than 363·2^191 < 2^200. For the second, 46·2^63·64 ln 2 < 2^75 < √x. The only endpoints of the prefix interval are even and cannot be among the counted primes. The expected number of samples is at most 2^137/√x < 2^9.5 < 725.

The 256-bit result specializes a published conditional theorem. Its proof does not verify GRH or establish a priority claim for this application.
