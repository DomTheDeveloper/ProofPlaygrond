// Exhaustive increasing-start search for a block of 15 consecutive primes
// with integral prefix means, including 14-term near misses.
#include "prime_stream.hpp"

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: scan_averages FIRST_NUMBER LAST_NUMBER\n";
        return 2;
    }
    const u64 first = std::stoull(argv[1]);
    const u64 last = std::stoull(argv[2]);
    if (last < first || last < 2 || last > 10000000000000ULL) return 2;
    std::array<u64, 32> sums{}, primes{};
    u64 count = 0;
    u64 running = 0;
    std::cout << "length,start_prime,end_prime\n";
    for_each_prime(first, last, [&](u64 p) {
        ++count;
        primes[count % 32] = p;
        running += p;
        sums[count % 32] = running;
        if (count < 15) return;
        // Unsigned subtraction recovers the exact sum of up to 15 primes:
        // even at the input limit, it is strictly less than 2^64.
        u64 base = sums[(count - 15) % 32];
        auto prefix = [&](unsigned len) { return sums[(count - 15 + len) % 32] - base; };
        if (prefix(3) % 3 || prefix(4) % 4 || prefix(5) % 5 || prefix(7) % 7 ||
            prefix(2) % 2 || prefix(6) % 6 || prefix(8) % 8 || prefix(9) % 9 ||
            prefix(10) % 10 || prefix(11) % 11 || prefix(12) % 12 || prefix(13) % 13 ||
            prefix(14) % 14) return;
        u64 start = primes[(count - 14) % 32];
        std::cout << "14," << start << ',' << primes[(count - 1) % 32] << '\n';
        if (prefix(15) % 15 == 0) std::cout << "15," << start << ',' << p << '\n';
    });
    if (count >= 15)
        std::cerr << "last_fully_checked_start=" << primes[(count - 14) % 32] << '\n';
}
