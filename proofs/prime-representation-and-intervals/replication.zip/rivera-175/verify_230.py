"""Independently certify the witness and the minimal start for Puzzle 175 at k=230.

Python 3, standard library only. Run from any directory.
"""
from csv import DictReader
from functools import lru_cache
from math import isqrt
from pathlib import Path
import sys


def primes_through(last):
    # Direct trial division independently verifies every prime in this small range.
    return [x for x in range(2, last + 1) if all(x % d for d in range(2, isqrt(x) + 1))]


def integral_prefix_order(block):
    """Exact backward search. The mask records the primes still available."""
    total = sum(block)
    if total % len(block):
        return None
    # For a set of size r and sum S, a possible last element x has
    # x = S (mod r-1). A bit in the lookup identifies one element of this block.
    residues = [{} for _ in block]
    for modulus in range(2, len(block)):
        by_residue = residues[modulus]
        for index, prime in enumerate(block):
            rem = prime % modulus
            by_residue[rem] = by_residue.get(rem, 0) | (1 << index)

    last_member = {}

    @lru_cache(None)
    def visit(active, size, subtotal):
        if size <= 2:
            # The current sum is divisible by size. Either element may come first.
            return True
        smaller = size - 1
        candidates = active & residues[smaller].get(subtotal % smaller, 0)
        while candidates:
            bit = candidates & -candidates
            index = bit.bit_length() - 1
            if visit(active ^ bit, smaller, subtotal - block[index]):
                last_member[active] = index
                return True
            candidates ^= bit
        return False

    active = (1 << len(block)) - 1
    if not visit(active, len(block), total):
        return None
    suffix = []
    while active in last_member:
        index = last_member[active]
        suffix.append(block[index])
        active ^= 1 << index
    first_two = [p for i, p in enumerate(block) if active & (1 << i)]
    return first_two + list(reversed(suffix))


if __name__ == "__main__":
    path = Path(__file__).with_name("230-witness.csv")
    with path.open(newline="") as f:
        rows = list(DictReader(f))
    order = [int(row["prime_in_order"]) for row in rows]
    assert len(order) == len(set(order)) == 230
    assert min(order) == 30271 and max(order) == 32633
    primes = primes_through(max(order))
    i = primes.index(min(order))
    assert sorted(order) == primes[i:]
    total = 0
    for length, (p, row) in enumerate(zip(order, rows), 1):
        total += p
        assert length == int(row["prefix_length"])
        assert total == int(row["prefix_sum"])
        assert total % length == 0 and total // length == int(row["prefix_mean"])
    assert total == 7242700

    count_integral_totals = 0
    for position in range(i):
        block = primes[position:position + len(order)]
        if sum(block) % len(order) == 0:
            count_integral_totals += 1
            assert integral_prefix_order(block) is None, f"Earlier solution at {block[0]}"
    print(f"Validated all {len(order)} prefix means, final mean {total // len(order)}.")
    print(f"Eliminated all {i} earlier blocks; {count_integral_totals} had integral full mean.")
    print(f"Minimum start {min(order)}, last prime {max(order)}.")
    if "--rediscover" in sys.argv:
        earlier = primes[i:i + len(order)]
        regenerated = integral_prefix_order(earlier)
        assert regenerated is not None
        running = 0
        for length, p in enumerate(regenerated, 1):
            running += p
            assert running % length == 0
        print("Regenerated an ordering directly from the primes:")
        print(*regenerated)
