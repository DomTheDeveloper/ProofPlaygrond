#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using u128 = unsigned __int128;

constexpr std::array<unsigned, 8> residues = {1, 7, 11, 13, 17, 19, 23, 29};
// Each block starts at a multiple of 30*7*11*13*17, so it shares a seed mask.
constexpr unsigned block_bytes = 8 * 7 * 11 * 13 * 17;
constexpr u64 block_length = 30ULL * block_bytes;
constexpr unsigned blocks_per_batch = 32;

std::string decimal(u128 x) {
    std::string result;
    do {
        result.push_back('0' + static_cast<unsigned>(x % 10));
        x /= 10;
    } while (x);
    std::reverse(result.begin(), result.end());
    return result;
}

std::vector<unsigned> small_primes(u64 last) {
    std::vector<bool> composite(last + 1);
    std::vector<unsigned> primes;
    for (u64 p = 2; p <= last; ++p) {
        if (composite[p]) continue;
        primes.push_back(p);
        for (u64 v = p * p; v <= last; v += p) composite[v] = true;
    }
    return primes;
}

// Enumerate primes in the inclusive interval [first, limit], in increasing order.
template <class Consumer>
void for_each_prime(u64 first, u64 limit, Consumer check_prime) {
    const u64 root = static_cast<u64>(std::sqrt(static_cast<long double>(limit))) + 1;
    const auto primes = small_primes(root);
    std::array<unsigned, 30> bit_number{};
    for (unsigned bit = 0; bit < 8; ++bit) bit_number[residues[bit]] = bit;
    std::vector<unsigned char> seed(block_bytes, 255);
    for (unsigned byte = 0; byte < block_bytes; ++byte) {
        for (unsigned bit = 0; bit < 8; ++bit) {
            unsigned v = 30 * byte + residues[bit];
            if (v % 7 == 0 || v % 11 == 0 || v % 13 == 0 || v % 17 == 0)
                seed[byte] &= ~(1U << bit);
        }
    }

    for (unsigned p : {2, 3, 5, 7, 11, 13, 17})
        if (p >= first && p <= limit) check_prime(p);

    for (u64 batch = first / block_length; batch <= limit / block_length; batch += blocks_per_batch) {
        std::vector<std::vector<unsigned>> offsets(blocks_per_batch);
        #pragma omp parallel for schedule(dynamic, 1)
        for (int b = 0; b < static_cast<int>(blocks_per_batch); ++b) {
            const u64 low = (batch + b) * block_length;
            if (low > limit) continue;
            const u64 high = std::min(low + block_length - 1, limit);
            auto bits = seed;
            for (unsigned p : primes) {
                if (p < 19) continue;
                if (u64(p) * p > high) break;
                // Mark p*m with m >= p, in each unit residue class modulo 30.
                const u64 first_m = std::max<u64>(p, (low + p - 1) / p);
                for (unsigned r : residues) {
                    u64 m = (first_m / 30) * 30 + r;
                    if (m < first_m) m += 30;
                    unsigned bit = bit_number[(p % 30) * r % 30];
                    unsigned char keep = static_cast<unsigned char>(~(1U << bit));
                    for (u64 byte = (p * m - low) / 30; byte < block_bytes; byte += p)
                        bits[byte] &= keep;
                }
            }
            offsets[b].reserve(block_bytes * 2);
            for (unsigned byte = 0; byte < block_bytes; ++byte) {
                unsigned mask = bits[byte];
                while (mask) {
                    unsigned d = 30 * byte + residues[__builtin_ctz(mask)];
                    if (low + d >= 19 && low + d >= first && low + d <= high) offsets[b].push_back(d);
                    mask &= mask - 1;
                }
            }
        }
        // Blocks are constructed independently but consumed in increasing order.
        for (unsigned b = 0; b < blocks_per_batch; ++b) {
            u64 low = (batch + b) * block_length;
            for (unsigned d : offsets[b]) check_prime(low + d);
        }
    }
}
