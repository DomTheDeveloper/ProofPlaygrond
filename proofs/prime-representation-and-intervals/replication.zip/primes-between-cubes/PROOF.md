# Four last digits between consecutive cubes

## Conditional result

Assume the generalized Riemann hypothesis for Dirichlet L-functions. For every integer $n\ge 2$, the open interval $(n^3,(n+1)^3)$ contains at least one prime in each residue class $1,3,7,9$ modulo 10.

The starting point is sharp. The interval $(1,8)$ contains the primes 2, 3, 5, and 7. In the next interval, $(8,27)$, the primes 11, 13, 17, and 19 give all four endings.

This calculation specializes a published short-interval theorem. Its infinite-range conclusion is conditional on Dirichlet GRH. The finite certificate below is unconditional. The calculation does not establish publication priority.

## Proof for all integers 10,000 and above

Dudek, Grenié, and Molteni prove the following in Theorem 1.2 of *Explicit short intervals for primes in arithmetic progressions on GRH*. At modulus 10, each of the four classes contains a prime $p$ with $|p-x|<h$ whenever both inequalities below hold. All logarithms are natural. [Author-hosted paper, Theorem 1.2](https://air.unimi.it/retrieve/dfa8b99e-9aeb-748b-e053-3a05fe0a3a96/43-molteni-Explicit_short_intervals_for_primes_in_arithmetic_progressions_on_GRH.pdf)

$$
x\ge(32\log(10)\log\log(10))^2,\qquad
\frac{h}{\sqrt{x}}\ge 60+2\log(100x).
$$

Set $m=n+1$. Take $x=((m-1)^3+m^3)/2$ and $h=(m^3-(m-1)^3)/2$. Then $(x-h,x+h)$ is exactly the requested interval. For $n\ge10{,}000$, the midpoint exceeds $10^{12}$, well above the first threshold, which is below 3,777.

Since $h=(3m^2-3m+1)/2$, we have $h\ge(7/5)m^2$ for $m\ge15$. This is equivalent to $m^2-15m+5\ge0$. Also $x<m^3$, so

$$
\frac{h}{\sqrt{x}}\ge \frac75\sqrt m,\qquad
60+2\log(100x)<60+2\log(100)+6\log m.
$$

At $m=10{,}000$, the left comparison value is 140 and the right comparison value is $60+28\log 10<125$. Their difference increases thereafter, because its derivative is $(0.7\sqrt m-6)/m>0$. Thus the second hypothesis holds throughout the range. Applying the theorem separately to each residue class proves the claim for every $n\ge10{,}000$.

## Finite proof for 2 through 9,999

`witnesses.csv` contains one row for every integer from 2 through 9,999. Its four entries after $n$ are primes ending in 1, 3, 7, and 9, in that order. The certificate contains 9,998 intervals and 39,992 primes.

`verify.cpp` checks consecutive row numbers, strict interval membership, final digits, and primality. It generates every prime up to one million by the sieve of Eratosthenes. Since each witness is smaller than $10^{12}$, trial division by all of these primes up to the square root of the witness proves primality. The verifier also rejects missing or extra rows. It uses only the C++17 standard library.

To reproduce the check, unzip the archive and run these commands in that directory.

```sh
c++ -O3 -std=c++17 verify.cpp -o verify
./verify witnesses.csv
```

Expected output is `Verified 9998 intervals and 39992 prime witnesses.` This completes the proof of the stated implication.
