#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using Integer = std::uint64_t;

constexpr int cutoff = 10000;
constexpr int factor_limit = 1000000;
constexpr std::array<int, 4> endings = {1, 3, 7, 9};

std::vector<int> prime_divisors() {
    std::vector<bool> composite(factor_limit + 1, false);
    std::vector<int> primes;
    for (int p = 2; p <= factor_limit; ++p) {
        if (composite[p]) continue;
        primes.push_back(p);
        if (p <= factor_limit / p) {
            for (int multiple = p * p; multiple <= factor_limit; multiple += p) {
                composite[multiple] = true;
            }
        }
    }
    return primes;
}

bool is_prime(Integer value, const std::vector<int>& primes) {
    if (value < 2) return false;
    for (const int factor : primes) {
        if (Integer(factor) * factor > value) break;
        if (value % factor == 0) return false;
    }
    return true;
}

bool verifies_row(const std::string& line, Integer n, const std::vector<int>& primes) {
    std::istringstream row(line);
    Integer recorded_n;
    if (!(row >> recorded_n) || recorded_n != n) return false;
    const Integer low = n * n * n;
    const Integer high = (n + 1) * (n + 1) * (n + 1);
    for (const int digit : endings) {
        char comma;
        Integer witness;
        if (!(row >> comma >> witness) || comma != ',') return false;
        if (witness <= low || witness >= high || witness % 10 != Integer(digit)) return false;
        if (!is_prime(witness, primes)) return false;
    }
    row >> std::ws;
    return row.eof();
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: verify witnesses.csv\n";
        return 1;
    }
    std::ifstream data(argv[1]);
    std::string line;
    std::getline(data, line);
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line != "n,ends_in_1,ends_in_3,ends_in_7,ends_in_9") {
        std::cerr << "Missing or invalid certificate header.\n";
        return 1;
    }
    const auto primes = prime_divisors();
    for (int n = 2; n < cutoff; ++n) {
        if (!std::getline(data, line) || !verifies_row(line, n, primes)) {
            std::cerr << "Invalid or missing witness row for n = " << n << ".\n";
            return 1;
        }
    }
    if (std::getline(data, line) || data.bad()) {
        std::cerr << "Unexpected data after the final interval or read error.\n";
        return 1;
    }
    constexpr auto intervals = cutoff - 2;
    std::cout << "Verified " << intervals << " intervals and "
              << intervals * endings.size() << " prime witnesses.\n";
}
