"""Check the complete reduction against a truth table and the raw graph."""
from itertools import product
from sat_to_four import reduce_cnf, read_dimacs, exact_modulus
from grouped_counter import grouped_count
from raw_counter import contract
from fibonacci_colorings import filter_depth
from verify_modular import valid, components_without


def main():
    cases = [(0, []), (0, [()]), (1, []), (1, [(1,)]), (1, [(-1,)]),
             (1, [(1,),(-1,)]), (1, [(1,-1)]), (2, []),
             (2, [(1,2),(-1,2),(1,-2)]), (2, [(1,1),(-2,-2)])]
    assert read_dimacs("c example\np cnf 2 2\n1\n-2 0 0") == (2, [(1,-2), ()])
    rows, max_order = 0, 0
    for m in (3,5,9):
        for n, clauses in cases:
            count = sum(all(any(x[abs(lit)-1] == (lit>0) for lit in clause)
                            for clause in clauses) for x in product((0,1),repeat=n))
            witness = []
            g, factor = reduce_cnf(n,clauses,m,witness)
            assert valid(g,witness) and len(components_without(g,g.pins))==2
            z = grouped_count(g,filter_depth(m),m)
            decoded = z * pow(factor,-1,m) % m
            assert decoded==count%m, (m,n,clauses,z,factor,count)
            rows+=1
            max_order = max(max_order,len(g.side))
        print(f"Ten complete CNF-to-graph reductions passed modulo {m}.", flush=True)
    for n in range(257):
        m = exact_modulus(n)
        assert m > (1 << n) and m % 2 and filter_depth(m) < 2*n + 7
    for clauses in ([(1,), (1,)], [(1,), (-1,)]):
        m = exact_modulus(1)
        witness = []
        g,u = reduce_cnf(1, clauses, m, witness)
        z = grouped_count(g,filter_depth(m),m)
        exact = sum(all(any(bits[abs(l)-1] == (l>0) for l in c) for c in clauses)
                    for bits in product((0,1),repeat=1))
        raw = contract(g.side,g.edges,g.pins)
        assert raw > 0 and raw % m == z
        print(f"Generic integer contraction: {raw}.", flush=True)
        assert valid(g,witness) and (z*pow(u,-1,m)) % m == exact
        print(f"Matched pair: {clauses}, {len(g.side)} vertices, m={m}, factor={u}, "
              f"graph residue={z}, exact #SAT={exact}.", flush=True)
    extra = [(3, [(1,2), (-1,3)]), (4, []),
             (6, [(1,2,3),(-3,4),(5,-6)]), (8, [(1,),(-1,)])]
    for n,clauses in extra:
        m = exact_modulus(n)
        witness = []
        g,u = reduce_cnf(n, clauses, m, witness)
        exact = sum(all(any(bits[abs(l)-1] == (l>0) for l in c) for c in clauses)
                    for bits in product((0,1),repeat=n))
        z = grouped_count(g,filter_depth(m),m)
        assert valid(g,witness) and z*pow(u,-1,m)%m==exact
        print(f"Exact Fibonacci decoder: n={n}, m={m}, vertices={len(g.side)}, "
              f"graph residue={z}, model count={exact}.", flush=True)
    print("Odd Fibonacci decoding moduli checked for 0 through 256 variables.")
    print(f"{rows} partition-guided target counts decoded correctly, largest {max_order} vertices.")


if __name__ == "__main__":
    main()
