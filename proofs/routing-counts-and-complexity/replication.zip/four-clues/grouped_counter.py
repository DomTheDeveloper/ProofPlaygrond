"""Read each proposed four-port block from the raw graph, then eliminate edge variables.

The block partition is an ordering hint. All entries of every tensor are computed
from graph incidence and the clues. No SAT assignment or formula is consulted.
"""
from itertools import permutations
import numpy as np
from raw_counter import contract


def reduce_factors(factors, modulus):
    scalar = 1
    while factors:
        scopes = {}
        for i,(vs,_) in enumerate(factors):
            for v in vs:
                scopes.setdefault(v, []).append(i)
        if not scopes:
            for _, t in factors:
                scalar = scalar * int(t) % modulus
            break
        variable = min(scopes,key=lambda v:(len(set().union(*(factors[i][0] for i in scopes[v]))),
                                              len(scopes[v]), v))
        selected = set(scopes[variable])
        scope = sorted(set().union(*(factors[i][0] for i in selected)))
        value = 1
        for i in selected:
            variables, tensor = factors[i]
            value = (value * tensor.reshape(tuple(3 if v in variables else 1 for v in scope))) % modulus
        combined = np.sum(value, axis=scope.index(variable)) % modulus
        rest = tuple(v for v in scope if v != variable)
        factors = [f for i,f in enumerate(factors) if i not in selected]
        if rest:
            factors.append((rest, combined))
        else:
            scalar = scalar * int(combined) % modulus
    return scalar


def grouped_count(graph, depth, modulus):
    sides, edges, pins = graph.side, graph.edges, graph.pins
    box_size = 2+6*depth
    step = 2+2*box_size
    comparisons, tail = divmod(len(sides),step)
    if tail not in (0,8):
        raise ValueError("graph order does not fit this optional contraction order")
    incident = [[] for _ in sides]
    for i,(u,v) in enumerate(edges):
        incident[u].append(i)
        incident[v].append(i)
    parent = list(range(len(edges)))
    def root(a):
        while a!=parent[a]:
            parent[a]=parent[parent[a]]
            a=parent[a]
        return a
    scalar = 1
    rest_vertices = set(range(len(sides)))
    remaining_edges = set(range(len(edges)))
    cache = {}
    factors = []
    for c in range(comparisons):
        for b in range(2):
            base = c*step+2+b*box_size
            vertices = range(base,base+box_size)
            rest_vertices.difference_update(vertices)
            internal, boundary = [], []
            for i in sorted({i for u in vertices for i in incident[u]}):
                u,v=edges[i]
                if u in vertices and v in vertices:
                    internal.append(i)
                else:
                    boundary.append((i,(u if u in vertices else v)-base))
            if len(boundary) not in (2,4):
                raise ValueError("invalid four-port block hint")
            remaining_edges.difference_update(internal)
            local_edges = tuple((edges[i][0]-base,edges[i][1]-base) for i in internal)
            fixed = tuple((j,pins[i]) for j,i in enumerate(internal) if i in pins)
            stubs = tuple(v for _,v in boundary)
            key = tuple(sides[base:base+box_size]),local_edges,fixed,stubs
            if key not in cache:
                tensor=contract(key[0],local_edges,dict(fixed),stubs,modulus)
                a=int(tensor[(0,)*len(stubs)])
                diagonal = a!=0 and all(tensor[(i,)*len(stubs)]==a for i in range(3)) and np.count_nonzero(tensor)==3
                cache[key] = (a,diagonal,tensor)
            a,diagonal,tensor = cache[key]
            variables = [i for i,_ in boundary]
            if diagonal:
                scalar = scalar*a % modulus
                for v in variables[1:]:
                    parent[root(v)]=root(variables[0])
            else:
                # The odd-modulus compiler always hits the diagonal case.
                raise ValueError("this specialized elimination order requires modular equality blocks")
    dtype = object if modulus>10**6 else np.int64
    distinct = np.zeros((3,3,3),dtype=dtype)
    for p in permutations(range(3)):
        distinct[p]=1
    for u in rest_vertices:
        variables=tuple(sorted(root(i) for i in incident[u]))
        if len(set(variables))!=3:
            return 0
        factors.append((variables,distinct))
    for i,v in pins.items():
        if i in remaining_edges:
            mask=np.array([int(c==v) for c in range(3)],dtype=dtype)
            factors.append(((root(i),),mask))
    used={x for variables,_ in factors for x in variables}
    unused={root(i) for i in remaining_edges}-used
    scalar=scalar*pow(3,len(unused),modulus)%modulus
    return scalar*reduce_factors(factors,modulus)%modulus
