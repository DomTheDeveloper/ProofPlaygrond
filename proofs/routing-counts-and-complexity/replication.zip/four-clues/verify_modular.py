"""Compare a source independent-set count with a raw target graph contraction."""
from itertools import product
from fibonacci_colorings import Graph, fibonacci_box, filter_depth, weights, compile_instance
from raw_counter import contract
from grouped_counter import grouped_count
from four_cut import cut_coloring


def independent_sets(left, right, edges):
    return sum(all(not (bits[i] and bits[left + j]) for i, j in edges)
               for bits in product((0, 1), repeat=left + right))


def valid(graph, colors):
    if len(graph.edges) != len(colors) or len(set(graph.edges)) != len(graph.edges):
        return False
    seen = [[] for _ in graph.side]
    for (u, v), c in zip(graph.edges, colors):
        if graph.side[u] != 0 or graph.side[v] != 1:
            return False
        seen[u].append(c)
        seen[v].append(c)
    return all(sorted(s) == [0, 1, 2] for s in seen) and all(
        colors[edge] == c for edge, c in graph.pins.items())


def components_without(graph, removed):
    adj = [[] for _ in graph.side]
    for i, (u, v) in enumerate(graph.edges):
        if i not in removed:
            adj[u].append(v)
            adj[v].append(u)
    seen = set()
    sizes = []
    for v in range(len(adj)):
        if v in seen:
            continue
        seen.add(v)
        stack = [v]
        count = 0
        while stack:
            u = stack.pop()
            count += 1
            for w in adj[u]:
                if w not in seen:
                    seen.add(w)
                    stack.append(w)
        sizes.append(count)
    return sorted(sizes)


def main():
    for k in range(25):
        g = Graph()
        p = fibonacci_box(g, k)
        Z = contract(g.side, g.edges, open_vertices=p.left + p.right)
        a, b = weights(k)
        for x, y, u, v in product(range(3), repeat=4):
            expected = 0
            if sorted((x, y)) == sorted((u, v)):
                expected = a if x == y else b
            assert int(Z[x, y, u, v]) == expected
    for modulus in range(3, 302, 2):
        k = filter_depth(modulus)
        a, b = weights(k)
        from math import gcd
        assert b % modulus == 0 and gcd(a, modulus) == 1
    print("All 2,025 terminal assignments at depths 0 through 24 matched raw integer contractions.")
    print("All 150 odd moduli from 3 through 301 passed the zero and unit checks.")
    maximum = graphs = bond_instances = 0
    for mask in range(16):
        edges = [(i, j) for i in range(2) for j in range(2) if mask >> (2*i+j) & 1]
        count = independent_sets(2, 2, edges)
        for modulus in (3, 5, 7, 9, 11):
            for pins in (0, 1, 2, 4):
                colors = []
                g, q = compile_instance(2, 2, edges, modulus, pins, witness=colors)
                assert valid(g, colors)
                assert components_without(g, ()) == [len(g.side)]
                assert len({u for i in g.pins for u in g.edges[i]}) == 2 * pins
                if pins == 4:
                    assert len(components_without(g, g.pins)) == 2
                    assert cut_coloring(g.side, g.edges, g.pins, construct=False)[0] == "yes"
                    bond_instances += 1
                z = contract(g.side, g.edges, g.pins, modulus=modulus)
                a, _ = weights(filter_depth(modulus))
                expected = {0: 6, 1: 2, 2: 1, 4: 2}[pins] * pow(a, q, modulus) * count
                assert grouped_count(g, filter_depth(modulus), modulus) == z
                assert z == expected % modulus, (mask, modulus, pins, z, expected)
                graphs += 1
                maximum = max(maximum, len(g.side))
    print(f"{graphs} closed graphs from all 16 labeled 2-by-2 bipartite sources; 5 moduli, 4 pin counts.")
    print(f"All raw residues and all {graphs} witnesses matched. {bond_instances} disjoint four-clue bonds; "
          f"largest graph {maximum} vertices.")
    edges = [(0, 0)]
    for pin_count in (0, 1, 2, 4):
        g, q = compile_instance(1, 1, edges, 5, pin_count)
        exact = contract(g.side, g.edges, g.pins)
        print(f"Single source edge, p=5, {pin_count} clues, {len(g.side)} vertices: "
              f"exact count {exact}, residue {exact % 5}.")
    for m in (3, 5, 7, 9, 11, 13, 25):
        k = filter_depth(m)
        a, b = weights(k)
        print(f"m={m}, k={k}, vertices per box={2+6*k}, A mod m={a%m}, B mod m={b%m}")


if __name__ == "__main__":
    main()
