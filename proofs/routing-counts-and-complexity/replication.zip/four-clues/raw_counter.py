"""Contract raw all-different tensors. Only vertex incidence and fixed edge colors are used."""
import argparse
import heapq
import itertools
import json
import numpy as np


def contract(sides, edges, pins=None, open_vertices=(), modulus=None):
    if modulus is not None and modulus < 2:
        raise ValueError("modulus must be at least two")
    pins = pins or {}
    incidence = [[] for _ in sides]
    owners = {}
    for edge, (u, v) in enumerate(edges):
        if u == v or sides[u] == sides[v]:
            raise ValueError("nonbipartite edge")
        incidence[u].append(edge)
        incidence[v].append(edge)
        owners[edge] = (u, v)
    open_axes = []
    for i, vertex in enumerate(open_vertices, start=len(edges)):
        incidence[vertex].append(i)
        open_axes.append(i)
    if any(len(axes) != 3 for axes in incidence):
        raise ValueError("all vertices must have degree three, including terminal stubs")
    neighbors = [set() for _ in sides]
    for u, v in owners.values():
        neighbors[u].add(v)
        neighbors[v].add(u)
    dtype = object if modulus is None or modulus > 10**6 else np.int64
    factors = {}
    for i, axes in enumerate(incidence):
        tensor = np.zeros((3, 3, 3), dtype=dtype)
        for values in itertools.permutations(range(3)):
            if all(e not in pins or pins[e] == x for e, x in zip(axes, values)):
                tensor[values] = 1
        factors[i] = (axes, tensor)
    heap = []

    def schedule(i, j):
        common = len(set(factors[i][0]).intersection(factors[j][0]))
        combined = len(factors[i][0]) + len(factors[j][0])
        heapq.heappush(heap, (combined - 2 * common, combined - common,
                              min(i, j), max(i, j)))

    for i, adj in enumerate(neighbors):
        for j in adj:
            if i < j:
                schedule(i, j)
    next_id = len(sides)
    while len(factors) > 1:
        if not heap:
            raise ValueError("counter expects a connected graph")
        _, _, i, j = heapq.heappop(heap)
        if i not in factors or j not in factors:
            continue
        ia, ta = factors.pop(i)
        ja, tb = factors.pop(j)
        common = set(ia).intersection(ja)
        pairs = sorted(common)
        remaining = [e for e in ia + ja if e not in common]
        if modulus and dtype != object and 3**len(pairs) * (modulus-1)**2 >= 2**63:
            ta, tb = ta.astype(object), tb.astype(object)
        z = np.tensordot(ta, tb, axes=([ia.index(e) for e in pairs],
                                      [ja.index(e) for e in pairs]))
        if modulus is not None:
            z = z % modulus
        factors[next_id] = (remaining, z)
        adj = (neighbors[i] | neighbors[j]) - {i, j}
        neighbors.append(adj)
        for v in adj:
            neighbors[v].difference_update((i, j))
            neighbors[v].add(next_id)
            schedule(v, next_id)
        next_id += 1
    axes, z = next(iter(factors.values()))
    if not open_axes:
        return int(z)
    return np.asarray(z).transpose([axes.index(e) for e in open_axes])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph")
    parser.add_argument("--modulus", type=int)
    a = parser.parse_args()
    with open(a.graph) as f:
        g = json.load(f)
    pins = {int(edge): color for edge, color in g["pins"].items()}
    print(contract(g["sides"], g["edges"], pins, modulus=a.modulus))
