"""Construct a coloring if four prescribed edges, two of each color, form a cut."""
from collections import deque


def color_shore(sides, vertices, edges, forced_red, blue=None):
    """Construct a coloring with the given red edges and at most one blue edge."""
    forced_red = list(forced_red)
    matching = {}
    for edge in forced_red:
        u, v = edges[edge]
        if edge == blue or u in matching or v in matching:
            return None
        matching[u], matching[v] = v, u
    blocked = set(matching)
    by_left = {u: [] for u in vertices if sides[u] == 0}
    for edge, (u, v) in enumerate(edges):
        if edge != blue and u not in blocked and v not in blocked:
            by_left[u].append((v, edge))
    red_indices = set(forced_red)
    chosen = {}
    for root in by_left:
        if root in blocked:
            continue
        queue = deque([root])
        pred = {root: None}
        end = None
        while queue and end is None:
            u = queue.popleft()
            for v, edge in by_left[u]:
                if v in pred:
                    continue
                pred[v] = u, edge
                if v not in matching:
                    end = v
                    break
                w = matching[v]
                if w not in pred:
                    pred[w] = v
                    queue.append(w)
        if end is None:
            return None
        while end is not None:
            u, edge = pred[end]
            old = matching.get(u)
            matching[u], matching[end] = end, u
            chosen[u] = edge
            end = old
    red_indices.update(chosen.values())
    colors = [0 if i in red_indices else None for i in range(len(edges))]
    incident = {u: [] for u in vertices}
    for i, (u, v) in enumerate(edges):
        if colors[i] is None:
            incident[u].append(i)
            incident[v].append(i)
    for first in ([] if blue is None else [blue]) + list(range(len(edges))):
        if colors[first] is not None:
            continue
        colors[first] = 1
        stack = [first]
        while stack:
            current = stack.pop()
            for u in edges[current]:
                for neighbor in incident[u]:
                    if colors[neighbor] is None:
                        colors[neighbor] = 3 - colors[current]
                        stack.append(neighbor)
    return colors


def cut_coloring(sides, edges, pins, construct=True):
    """Return ('outside', None), ('no', None), or ('yes', valid edge-color list).

    Inputs must be a connected cubic bipartite graph with edge endpoints ordered
    left to right. Colors 0 and 1 are red and blue. Green is 2.
    """
    if sorted(pins.values()) != [0, 0, 1, 1]:
        raise ValueError("provide two red and two blue edges")
    adjacency = [[] for _ in sides]
    for i, (u, v) in enumerate(edges):
        adjacency[u].append((v, i))
        adjacency[v].append((u, i))
    shore = {0: 0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v, edge in adjacency[u]:
            required = shore[u] ^ (edge in pins)
            if v in shore:
                if shore[v] != required:
                    return "outside", None
            else:
                shore[v] = required
                stack.append(v)
    if len(shore) != len(sides):
        raise ValueError("expected a connected graph")
    # Each component left after removing the four clues must balance each color.
    components = {}
    for start in range(len(sides)):
        if start in components:
            continue
        components[start] = start
        stack = [start]
        while stack:
            u = stack.pop()
            for v, edge in adjacency[u]:
                if edge not in pins and v not in components:
                    components[v] = start
                    stack.append(v)
    balances = {}
    for edge, color in pins.items():
        for u in edges[edge]:
            key = components[u], color
            balances[key] = balances.get(key, 0) + (1 if sides[u] == 0 else -1)
    if any(balances.values()):
        return "no", None
    if not construct:
        return "yes", None
    coloring = [pins.get(i) for i in range(len(edges))]
    for half in (0, 1):
        vertices = [u for u in shore if shore[u] == half]
        ids = [i for i, (u, v) in enumerate(edges) if shore[u] == shore[v] == half]
        closed = [edges[i] for i in ids]
        for color in (0, 1):
            endpoints = [u for edge, c in pins.items() if c == color
                         for u in edges[edge] if shore[u] == half]
            if len(endpoints) != 2 or sides[endpoints[0]] == sides[endpoints[1]]:
                return "no", None
            closed.append(tuple(sorted(endpoints, key=lambda u: sides[u])))
        local = color_shore(sides, vertices, closed, [len(ids)], len(ids) + 1)
        if local is None:
            return "no", None
        for i, c in zip(ids, local):
            coloring[i] = c
    return "yes", coloring


if __name__ == "__main__":
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph")
    parser.add_argument("--witness", help="write an edge coloring if one exists")
    args = parser.parse_args()
    with open(args.graph) as f:
        data = json.load(f)
    status, solution = cut_coloring(data["sides"], data["edges"],
                                   {int(i): c for i,c in data["pins"].items()},
                                   construct=bool(args.witness))
    print(status)
    if solution is not None and args.witness:
        with open(args.witness, "w") as f:
            json.dump(solution, f)
            f.write("\n")
