"""Verify the fractional coloring exactly and enumerate the integral obstructions."""
from pathlib import Path
import json
from itertools import permutations
from fibonacci_colorings import Graph
from four_cut import cut_coloring
from verify_cut import all_colorings


def main():
    data = json.loads(Path(__file__).with_name("fractional_obstruction.json").read_text())
    pins = {int(i): c for i,c in data["pins"].items()}
    graph = Graph(data["sides"], list(map(tuple, data["edges"])), pins)
    n = len(graph.side) // 2
    edges = graph.edges
    for i, row in enumerate(data["twice_weights"]):
        assert len(row) == 3 and sum(row) == 2 and min(row) >= 0
        if i in pins:
            assert row[pins[i]] == 2
    for v in range(2*n):
        incident = [i for i, e in enumerate(edges) if v in e]
        assert len(incident) == 3
        for c in range(3):
            assert sum(data["twice_weights"][i][c] for i in incident) == 2
    colors = all_colorings(graph)
    def matches(cs, ignored=None):
        return all(i == ignored or cs[i] == c for i,c in pins.items())
    assert not any(matches(cs) for cs in colors)
    deletions = [sum(matches(cs, i) for cs in colors) for i in pins]
    assert all(deletions) and cut_coloring(graph.side, edges, pins)[0] == "outside"
    required = {i for i,c in pins.items() if c == 0}
    forbidden = [i for i,c in pins.items() if c == 1]
    index = {e:i for i,e in enumerate(edges)}
    candidates = 0
    for perm in permutations(range(n)):
        if any((i, n+j) not in index for i,j in enumerate(perm)):
            continue
        reds = {index[i,n+j] for i,j in enumerate(perm)}
        if not required <= reds or set(forbidden) & reds:
            continue
        candidates += 1
        current = forbidden[0]
        u,v = edges[current]
        cycle = [current]
        while True:
            nxt, = (i for i,e in enumerate(edges) if v in e and i != current and i not in reds)
            if nxt == cycle[0]:
                break
            cycle.append(nxt)
            x,y = edges[nxt]
            v = y if x == v else x
            current = nxt
        offset = cycle.index(forbidden[1])
        assert offset % 2 == 1
        print(''.join(chr(65+j) for j in perm), len(cycle), offset)
    print(f"{candidates} red candidates. Both blue clues are at odd separation on the same cycle in every case.")
    print(f"Raw unrestricted colorings: {len(colors)}. With four clues: 0. Single-deletion counts: {deletions}.")
    print("All 24 half-integral edge distributions and 48 vertex-color equalities checked with integers.")


if __name__ == '__main__':
    main()
