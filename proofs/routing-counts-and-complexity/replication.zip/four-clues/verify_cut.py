"""Generate cubic bipartite graphs and compare every four-edge cut with exact DFS."""
from collections import Counter
import itertools
import random
from fibonacci_colorings import Graph
from four_cut import cut_coloring
from verify_modular import components_without, valid


def closed_graph(size, pairs):
    return Graph([0] * size + [1] * size, [(u, size + v) for u, v in sorted(pairs)])


def all_colorings(graph):
    used = [0] * len(graph.side)
    colors = [-1] * len(graph.edges)
    def visit():
        best = None
        for i, (u, v) in enumerate(graph.edges):
            if colors[i] == -1:
                options = 7 ^ (used[u] | used[v])
                if not options:
                    return
                item = options.bit_count(), i, options
                if best is None or item < best:
                    best = item
        if best is None:
            yield tuple(colors)
            return
        _, i, options = best
        u, v = graph.edges[i]
        for c in range(3):
            bit = 1 << c
            if bit & options:
                colors[i] = c
                used[u] ^= bit
                used[v] ^= bit
                yield from visit()
                used[u] ^= bit
                used[v] ^= bit
                colors[i] = -1
    return list(visit())


def four_cuts(graph):
    masks = [0] * len(graph.side)
    for i, (u, v) in enumerate(graph.edges):
        masks[u] |= 1 << i
        masks[v] |= 1 << i
    cut = 0
    for i in range(1, 1 << (len(graph.side) - 1)):
        cut ^= masks[(i & -i).bit_length() - 1]
        if cut.bit_count() == 4:
            yield tuple(j for j in range(len(graph.edges)) if cut >> j & 1)


def source_graphs():
    rng = random.Random(9251)
    for size in range(3, 9):
        seen = set()
        for shifts in ((0, 1, 2), (0, 1, 3)):
            if len({d % size for d in shifts}) == 3:
                pairs = {(i, (i+d) % size) for i in range(size) for d in shifts}
                seen.add(tuple(sorted(pairs)))
        for _ in range(40 if size > 3 else 0):
            chosen = set()
            for _ in range(3):
                for _ in range(100):
                    perm = list(range(size))
                    rng.shuffle(perm)
                    matching = set(enumerate(perm))
                    if not (chosen & matching):
                        chosen.update(matching)
                        break
            if len(chosen) == 3 * size:
                seen.add(tuple(sorted(chosen)))
            if len(seen) >= 6:
                break
        for pairs in sorted(seen):
            g = closed_graph(size, pairs)
            if len(components_without(g, ())) == 1:
                yield g
    # A four-piece ring also gives a four-edge cut with disconnected shores.
    for blocks in (3, 4):
        pairs = {(3*k+i, 3*k+j) for k in range(blocks)
                 for i in range(3) for j in range(3) if i or j}
        pairs.update((3*k, 3*((k+1) % blocks)) for k in range(blocks))
        yield closed_graph(3 * blocks, pairs)



def main():
    totals = dict(graphs=0, cuts=0, bonds=0, feasible=0, infeasible=0,
                  disjoint=0, noncut=0, oracle_colorings=0, odd_bonds=0, even_bonds=0)
    for graph in source_graphs():
        totals["graphs"] += 1
        colorings = all_colorings(graph)
        totals["oracle_colorings"] += len(colorings)
        cuts = set(four_cuts(graph))
        for cut in cuts:
            totals["cuts"] += 1
            bond = len(components_without(graph, cut)) == 2
            totals["bonds"] += bond
            signatures = Counter(tuple(cs[i] for i in cut) for cs in colorings)
            successes = 0
            parities = set()
            for red in itertools.combinations(cut, 2):
                pins = {i: int(i not in red) for i in cut}
                graph.pins = pins
                expected = tuple(pins[i] for i in cut) in signatures
                decision, _ = cut_coloring(graph.side, graph.edges, pins, construct=False)
                assert (decision == "yes") == expected and decision != "outside"
                status, cs = cut_coloring(graph.side, graph.edges, pins)
                assert status == decision
                if expected:
                    parities.add(signatures[tuple(pins[i] for i in cut)] % 2)
                    assert valid(graph, cs)
                successes += expected
                totals["feasible" if expected else "infeasible"] += 1
                totals["disjoint"] += len({v for i in cut for v in graph.edges[i]}) == 8
            if bond:
                assert successes == 4 and len(parities) == 1
                totals["odd_bonds" if 1 in parities else "even_bonds"] += 1
        if len(graph.side) <= 10:
            for quad in itertools.combinations(range(len(graph.edges)), 4):
                if quad not in cuts:
                    pins = {i: int(i not in quad[:2]) for i in quad}
                    assert cut_coloring(graph.side, graph.edges, pins)[0] == "outside"
                    totals["noncut"] += 1
    for key, count in totals.items():
        print(key, count)
    print("All six color placements checked on every four-edge cut. Every bond admitted exactly four.")
    print("All accepted witnesses were valid. No noncut placement tested was classified as a cut.")


if __name__ == "__main__":
    main()
