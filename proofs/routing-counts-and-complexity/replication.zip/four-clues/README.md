# Four clues and Fibonacci counts

The reduction turns a Boolean formula into a connected, simple, cubic bipartite graph with four disjoint precolored edges and a known valid coloring. The graph's coloring count, taken modulo one explicitly chosen odd Fibonacci number, recovers the exact number of satisfying assignments.

The manuscript source is `Four_Clues_and_Fibonacci_Counts.tex`. The five verification logs are collected in `CHECK_RESULTS.txt`. All CLI examples run from the directory containing this README. The compilers, the cut solver and the Latin-square converter require Python 3.10 or newer. Independent counting and the check suite also use NumPy.

## A satisfiable and an unsatisfiable formula

Two fully generated 1,142-vertex instances are in `examples/`. Each includes its source formula and a valid full coloring. The first formula is x AND x. The second is x AND (NOT x).

```bash
python3 four_cut.py examples/matched_sat.graph.json
python3 four_cut.py examples/matched_unsat.graph.json
python3 raw_counter.py examples/matched_sat.graph.json --modulus 3
python3 raw_counter.py examples/matched_unsat.graph.json --modulus 3
```

The first two commands both print `yes`. The two counts have residues 2 and 0. Multiplying each by 2 modulo 3 gives the exact SAT model counts 1 and 0. Omitting `--modulus 3` computes each 105-digit graph count directly.

Generate the same instances from the formulas, or substitute your own DIMACS file.

```bash
python3 sat_to_four.py examples/matched_sat.cnf rebuilt.json --exact --witness rebuilt-witness.json
python3 raw_counter.py rebuilt.json --modulus 3
python3 four_cut.py rebuilt.json --witness cut-witness.json
```

`--exact` picks the first odd Fibonacci number satisfying both `m >= 3` and `m > 2**n`. The CLI reports the factor and its modular inverse. Computing the residue of a general compiled graph is the hard step. The raw counter uses edge endpoints and clues only. Its running time and memory may grow exponentially. Use `--modulus 5` in place of `--exact` to request a particular odd modulus. The result then gives the model count modulo 5.

## An independent-set example and its Latin rectangle

The input `example_input.json` describes one edge between one left and one right vertex, with three independent sets. The supplied `example_graph.json` and `example_witness.json` are reproducible as follows.

```bash
python3 fibonacci_colorings.py example_input.json built.json --modulus 5 --pins 4 --witness coloring.json
python3 raw_counter.py built.json --modulus 5
python3 latin.py built.json rectangle.json --witness coloring.json
```

This graph has 332 vertices and 498 edges. Its exact count is 563814076452372728421176836096. The remainder is 1 modulo 5, equal to twice the independent-set count modulo 5. The Latin output has order 166, its first 163 rows filled, four prescribed cells in the remaining rows, and a witness for those rows. The compiler also supports 0, 1 or 2 clues.

## Reproduce the checks

```bash
python3 verify_cut.py
python3 verify_obstruction.py
python3 verify_modular.py
python3 verify_sat.py
python3 verify_latin.py
```

- `verify_cut.py` enumerates whole colorings by edge backtracking and tests all six placements on each generated four-edge cut. The cut solver distinguishes `outside` (arbitrary placement), `no` and `yes`.
- `verify_obstruction.py` checks `fractional_obstruction.json` using integers, enumerates every red candidate and tests all single-clue deletions. Each triple in its extra field is twice the fractional edge-color distribution.
- `verify_modular.py` contracts raw incidence tensors over the integers for 25 four-end graphs. It compares two contraction orders, the predicted residue and a full witness on 320 closed graphs.
- `verify_sat.py` uses raw vertex incidence inside each proposed block. A block partition guides the elimination order on the larger target graphs. The checker measures every local signature and uses the detected equalities to eliminate variables. Four additional truth-table comparisons exercise the exact decoder up to 80,846 graph vertices. The matched SAT/UNSAT pair also runs through the generic integer counter.
- `verify_latin.py` compares small Latin rectangles with direct Latin enumeration and verifies three generated full squares.

Graph files give the bipartition bit of each vertex, a list of left-to-right endpoint pairs, and a map from edge indices to colors. All indices are zero-based. Red is 0, blue is 1 and green is 2. A full coloring lists the color of every edge in file order.

## Scope

The four-edge cut theorem decides a geometrically restricted case. The complexity of completion with four arbitrary clues is not determined by this work. Exact counting hardness without clues was published by Boehmer and coauthors in 2023. The manuscript attributes that theorem, the modular independent-set framework and the Latin correspondence, and identifies the refinements for which publication priority remains unverified.
