"""Enumerate Latin completions directly and compare with the independent graph counter."""
from itertools import permutations
from fibonacci_colorings import Graph, compile_instance
from latin import convert
from raw_counter import contract


def main():
    total = 0
    for n in (3, 4, 5):
        symbols = tuple(range(n))
        row_perms = list(permutations(symbols))
        if n == 3:
            rectangles = [[]]
        elif n == 4:
            rectangles = [[p] for p in row_perms]
        else:
            rectangles = [[symbols, p] for p in row_perms if all(a != b for a,b in zip(symbols,p))]
        for rows in rectangles:
            avail = [set(symbols)-{r[c] for r in rows} for c in symbols]
            edges = [(c,n+s) for c in symbols for s in sorted(avail[c])]
            good = [p for p in row_perms if all(x in avail[c] for c,x in enumerate(p))]
            # The residual third permutation is forced once the first two are selected.
            count = sum(all(a != b for a,b in zip(p,q)) for p in good for q in good)
            assert count == contract([0]*n+[1]*n, edges)
            total += 1
    for m in (3,5,7):
        witness = []
        graph,_ = compile_instance(1,1,[(0,0)],m,4,witness=witness)
        result = convert(graph.data(),witness)
        print(f"Verified full Latin square of order {result['order']} and four prescribed cells (m={m}).")
    print(f"{total} small rectangles: direct Latin enumeration equaled the raw graph count.")


if __name__ == '__main__':
    main()
