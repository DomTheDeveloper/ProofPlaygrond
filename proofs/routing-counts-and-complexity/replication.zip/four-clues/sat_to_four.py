"""Reduce the number of CNF models modulo a fixed odd integer to four-clue colorings."""
import argparse
import json
from fibonacci_colorings import compile_instance, filter_depth, weights


def read_dimacs(text):
    variables = expected = None
    literals = []
    clauses = []
    for line in text.splitlines():
        tok = line.split()
        if not tok or tok[0] == "c":
            continue
        if tok[0] == "p":
            if variables is not None or len(tok) != 4 or tok[1] != "cnf":
                raise ValueError("invalid DIMACS header")
            variables, expected = map(int, tok[2:])
            if variables < 0 or expected < 0:
                raise ValueError("negative DIMACS size")
            continue
        if variables is None:
            raise ValueError("missing DIMACS header")
        for word in tok:
            x = int(word)
            if not x:
                clauses.append(tuple(literals))
                literals = []
            elif abs(x) > variables:
                raise ValueError("literal out of range")
            else:
                literals.append(x)
    if variables is None or literals or len(clauses) != expected:
        raise ValueError("clause count, terminator or header is invalid")
    return variables, clauses


def blocker_source(n, clauses, modulus):
    k = filter_depth(modulus)
    # Vertex identifiers are local to each part. x and its negation are consecutive.
    sizes = [2*n, 2*n]
    edges = {(i,i) for i in range(2*n)}

    def path(neighbor_side, neighbors):
        side = 1 - neighbor_side
        vertex = sizes[side]
        sizes[side] += 1
        for u in set(neighbors):
            edges.add((u, vertex) if side == 1 else (vertex, u))
        for _ in range(k-2):
            next_vertex = sizes[1-side]
            sizes[1-side] += 1
            edges.add((vertex, next_vertex) if side == 0 else (next_vertex, vertex))
            side, vertex = 1-side, next_vertex

    for i in range(n):
        path(0, (2*i, 2*i+1))
        path(1, (2*i, 2*i+1))
    for clause in clauses:
        if any(x == 0 or abs(x) > n for x in clause):
            raise ValueError("literal outside formula variables")
        path(0, [2*(abs(x)-1) + int(x < 0) for x in clause])
    p, f = 0, 1
    for _ in range(k):
        p, f = f, (p + f) % modulus
    return sizes[0], sizes[1], sorted(edges), pow(p, 2*n+len(clauses), modulus)


def exact_modulus(variables):
    if variables < 0:
        raise ValueError("negative variable count")
    limit = 1 << variables
    previous, current = 0, 1
    while current <= limit or current < 3 or current % 2 == 0:
        previous, current = current, previous + current
    return current


def reduce_cnf(n, clauses, modulus, witness=None):
    left, right, edges, inner = blocker_source(n, clauses, modulus)
    target, q = compile_instance(left, right, edges, modulus, 4, witness=witness)
    a, _ = weights(filter_depth(modulus))
    factor = 2 * pow(a, q, modulus) * inner % modulus
    return target, factor


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("formula")
    parser.add_argument("graph")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--modulus", type=int, default=3)
    group.add_argument("--exact", action="store_true",
                       help="choose an odd Fibonacci modulus exceeding all possible model counts")
    parser.add_argument("--witness")
    args = parser.parse_args()
    with open(args.formula) as f:
        n, clauses = read_dimacs(f.read())
    if args.exact:
        args.modulus = exact_modulus(n)
    colors = [] if args.witness else None
    g, multiplier = reduce_cnf(n, clauses, args.modulus, colors)
    with open(args.graph, "w") as f:
        json.dump(g.data(), f, separators=(",", ":"))
        f.write("\n")
    if args.witness:
        with open(args.witness, "w") as f:
            json.dump(colors, f)
            f.write("\n")
    print(f"{len(g.side)} vertices. z = {multiplier} * #SAT mod {args.modulus}. "
          f"Multiply z by {pow(multiplier,-1,args.modulus)} modulo {args.modulus} to decode.")
    if args.exact:
        print("The decoded residue is the exact number of satisfying assignments.")
