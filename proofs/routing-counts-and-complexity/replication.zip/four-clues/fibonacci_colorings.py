"""Build simple cubic bipartite graphs whose coloring counts encode independent sets."""
from dataclasses import dataclass, field
from typing import NamedTuple
import argparse
import json
import math


class Ports(NamedTuple):
    left: tuple
    right: tuple


@dataclass
class Graph:
    side: list = field(default_factory=list)
    edges: list = field(default_factory=list)
    pins: dict = field(default_factory=dict)

    def vertex(self, side):
        index = len(self.side)
        self.side.append(side)
        return index

    def join(self, u, v):
        if self.side[u] == self.side[v]:
            raise ValueError("a connection must cross the bipartition")
        index = len(self.edges)
        self.edges.append((u, v) if self.side[u] == 0 else (v, u))
        return index

    def data(self):
        return {"sides": self.side, "edges": self.edges,
                "pins": {str(i): color for i, color in self.pins.items()}}


def dipole(g):
    left, right = g.vertex(0), g.vertex(1)
    g.join(left, right)
    return Ports((left, left), (right, right))


def square(g):
    left = (g.vertex(0), g.vertex(0))
    right = (g.vertex(1), g.vertex(1))
    for u in left:
        for v in right:
            g.join(u, v)
    return Ports(left, right)


def fibonacci_box(g, depth):
    ports = dipole(g)
    for _ in range(depth):
        lower = dipole(g)
        g.join(ports.left[1], lower.right[0])
        g.join(ports.right[1], lower.left[0])
        vertical = Ports((ports.left[0], lower.left[1]),
                         (ports.right[0], lower.right[1]))
        end = square(g)
        for i in range(2):
            g.join(vertical.right[i], end.left[i])
        ports = Ports(vertical.left, end.right)
    return ports


def weights(depth):
    equal, mixed = 0, 1
    for _ in range(depth):
        equal, mixed = 4 * mixed, equal + 2 * mixed
    return equal, mixed


def filter_depth(modulus):
    if modulus < 3 or modulus % 2 == 0:
        raise ValueError("the filter requires an odd modulus of at least three")
    previous, current = 0, 1
    for depth in range(modulus * modulus):
        if current == 0:
            assert math.gcd(previous, modulus) == 1
            return depth
        previous, current = current, (previous + current) % modulus
    raise AssertionError("invertibility guarantees a return to the initial pair")


def palette_graph(left, right, incidences):
    if min(left, right) < 0:
        raise ValueError("part sizes must be nonnegative")
    edges = [(0, 1), (1, 2), (2, 0)]
    edges.extend((2, 3 + i) for i in range(left))
    edges.extend((1, 3 + left + j) for j in range(right))
    incidences = list(map(tuple, incidences))
    if len(set(incidences)) != len(incidences):
        raise ValueError("duplicate input edge")
    for i, j in incidences:
        if not (0 <= i < left and 0 <= j < right):
            raise ValueError("input endpoints outside their parts")
        edges.append((3 + i, 3 + left + j))
    return 3 + left + right, edges


def cube_wire(graph, u, v, witness):
    """Replace one red wire by a cube with four disjoint, uniquely extending clues."""
    top = [graph.vertex(i % 2) for i in range(4)]
    bottom = [graph.vertex(1 - i % 2) for i in range(4)]
    for i in range(4):
        c = 0 if i < 2 else 1
        graph.pins[graph.join(top[i], bottom[i])] = c
        if witness is not None:
            witness.append(c)
    for row in (top, bottom):
        for i,c in enumerate((1, 2, 0, 2)):
            if row is bottom and i == 2:
                continue
            graph.join(row[i], row[(i+1) % 4])
            if witness is not None:
                witness.append(c)
    near, far = (bottom[3], bottom[2]) if graph.side[u] == 1 else (bottom[2], bottom[3])
    graph.join(u, near)
    graph.join(far, v)
    if witness is not None:
        witness.extend((0, 0))


def equal_box_witness(depth):
    from four_cut import color_shore
    local = Graph()
    ports = fibonacci_box(local, depth)
    internal = len(local.edges)
    pair = [local.join(ports.left[j], ports.right[j]) for j in range(2)]
    colors = color_shore(local.side, range(len(local.side)), local.edges, pair)
    if colors is None:
        raise AssertionError("positive-depth box must support four equal colors")
    return colors[:internal]


def compile_instance(left, right, incidences, modulus, pin_count=0, depth=None, witness=None):
    if pin_count not in (0, 1, 2, 4):
        raise ValueError("supported pin counts: 0, 1, 2, 4")
    depth = filter_depth(modulus) if depth is None else depth
    if depth < 1:
        raise ValueError("compiled closed graphs require positive depth")
    order, edges = palette_graph(left, right, incidences)
    graph = Graph()
    # This palette coloring represents the empty independent set.
    vertex_color = [0, 1, 2] + [1] * left + [2] * right
    if witness is not None:
        if witness:
            raise ValueError("supply an empty list for the optional witness")
        internal_witness = equal_box_witness(depth)
    rings = [[] for _ in range(order)]
    for u, v in edges:
        comparison_left, comparison_right = graph.vertex(0), graph.vertex(1)
        graph.join(comparison_left, comparison_right)
        if witness is not None:
            witness.append(3 - vertex_color[u] - vertex_color[v])
        for endpoint in (u, v):
            box = fibonacci_box(graph, depth)
            c = vertex_color[endpoint]
            if witness is not None:
                witness.extend((x + c) % 3 for x in internal_witness)
            graph.join(box.right[0], comparison_left)
            graph.join(box.left[0], comparison_right)
            if witness is not None:
                witness.extend((c, c))
            rings[endpoint].append(box)
    for i, ring in enumerate(rings):
        for j, box in enumerate(ring):
            u, v = box.right[1], ring[(j + 1) % len(ring)].left[1]
            if pin_count == 4 and (i, j) == (0, 0):
                cube_wire(graph, u, v, witness)
                continue
            wire = graph.join(u, v)
            if witness is not None:
                witness.append(vertex_color[i])
            if j == 0 and (i == 0 and pin_count in (1, 2) or i == 1 and pin_count == 2):
                graph.pins[wire] = i
    return graph, 2 * len(edges)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help='JSON with left, right and zero-indexed edges')
    parser.add_argument("output", help="JSON cubic bipartite graph")
    parser.add_argument("--modulus", type=int, default=5)
    parser.add_argument("--pins", type=int, choices=(0, 1, 2, 4), default=0)
    parser.add_argument("--witness", help="optional output path for a valid coloring")
    args = parser.parse_args()
    with open(args.input) as f:
        data = json.load(f)
    witness = [] if args.witness else None
    graph, q = compile_instance(data["left"], data["right"], data["edges"],
                                args.modulus, args.pins, witness=witness)
    if args.witness:
        with open(args.witness, "w") as f:
            json.dump(witness, f)
            f.write("\n")
    with open(args.output, "w") as f:
        json.dump(graph.data(), f, separators=(",", ":"))
        f.write("\n")
    a, _ = weights(filter_depth(args.modulus))
    multiplier = {0: 6, 1: 2, 2: 1, 4: 2}[args.pins] * pow(a, q, args.modulus)
    print(f"{len(graph.side)} vertices, {len(graph.edges)} edges, {q} boxes, "
          f"{len(graph.pins)} clues; multiplier = {multiplier % args.modulus} mod {args.modulus}")


if __name__ == "__main__":
    main()
