"""Convert a cubic bipartite graph to a Latin rectangle with three remaining rows."""
from collections import deque
import argparse
import json


def perfect_matching(allowed):
    n = len(allowed)
    by_row, by_column = [-1] * n, [-1] * n
    for root in range(n):
        queue = deque([root])
        seen_rows = {root}
        pred = {}
        free = -1
        while queue and free == -1:
            u = queue.popleft()
            for v in allowed[u]:
                if v in pred:
                    continue
                pred[v] = u
                w = by_column[v]
                if w == -1:
                    free = v
                    break
                if w not in seen_rows:
                    seen_rows.add(w)
                    queue.append(w)
        if free == -1:
            raise ValueError("remaining graph has no perfect matching")
        while free != -1:
            u = pred[free]
            old = by_row[u]
            by_row[u], by_column[free] = free, u
            free = old
    return by_row


def convert(graph, coloring=None):
    left = [v for v, side in enumerate(graph["sides"]) if side == 0]
    right = [v for v, side in enumerate(graph["sides"]) if side == 1]
    columns = {v: i for i, v in enumerate(left)}
    symbols = {v: i for i, v in enumerate(right)}
    n = len(columns)
    if len(symbols) != n:
        raise ValueError("unequal bipartition sizes")
    edges = [(columns[u], symbols[v]) for u,v in graph["edges"]]
    allowed = [set(range(n)) for _ in range(n)]
    for u,v in edges:
        allowed[u].remove(v)
    rows = []
    for _ in range(n-3):
        row = perfect_matching(allowed)
        rows.append(row)
        for u,v in enumerate(row):
            allowed[u].remove(v)
    if any(allowed):
        raise ValueError("expected a cubic graph")
    givens = []
    for edge, c in graph["pins"].items():
        col, symbol = edges[int(edge)]
        givens.append([n-3+c, col, symbol])
    out = {"order": n, "rows": rows, "givens_in_last_three_rows": givens}
    if coloring is not None:
        tail = [[None]*n for _ in range(3)]
        for (col, symbol), c in zip(edges, coloring, strict=True):
            tail[c][col] = symbol
        square = rows + tail
        alphabet = set(range(n))
        if (any(set(row) != alphabet for row in square)
            or any(set(col) != alphabet for col in zip(*square))
            or any(square[r][c] != v for r,c,v in givens)):
            raise ValueError("supplied coloring fails the Latin constraints")
        out["witness_last_three_rows"] = tail
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph")
    parser.add_argument("output")
    parser.add_argument("--witness")
    args = parser.parse_args()
    with open(args.graph) as f:
        graph = json.load(f)
    colors = None
    if args.witness:
        with open(args.witness) as f:
            colors = json.load(f)
    result = convert(graph, colors)
    with open(args.output, "w") as f:
        json.dump(result, f, separators=(",", ":"))
        f.write("\n")
    print(f"Order {result['order']}, {len(result['rows'])} complete rows, "
          f"{len(result['givens_in_last_three_rows'])} extra clues.")
