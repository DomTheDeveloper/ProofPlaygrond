"""Independent four-lane and sparse-witness checks. Run with python check_width.py."""
from collections import Counter
from itertools import permutations,product,combinations
from math import lcm
from random import Random
from four_lanes import count_four,segment_count,S3
from three_lane import trace,reflection

rng=Random(761231)
def simulate(gates,setting,width):
    p=list(range(width))
    for k,a,b in gates:
        if not k or bool(setting[abs(k)])==(k>0):
            p[a],p[b]=p[b],p[a]
    return tuple(p)
def one_cycle(p):
    seen=set()
    j=0
    while j not in seen:
        seen.add(j)
        j=p[j]
    return len(seen)==len(p)
def allsets(keys):
    for x in product((0,1),repeat=len(keys)):
        yield dict(zip(keys,x))

def checks_four():
    count=0
    for i in range(170):
        names=[1,1,2,2,3,3,0,0]
        rng.shuffle(names)
        limit=rng.randrange(0,9) if i<120 else rng.randrange(0,6)
        g=[(k*rng.choice((-1,1)),*rng.sample(range(4),2)) for k in names[:limit]]
        keys={abs(k) for k,_,_ in g if k}
        w=sum(one_cycle(simulate(g,x,4)) for x in allsets(keys))
        for b in range(1,(2 if i<120 else 3)+1):
            assert count_four(g,b)==w%(1<<b),(g,b,w)
            count+=1
    print(f"170 four-lane two-use programs, {count} binary residues passed (through modulus 8)")
    for _ in range(100):
        ks=[1,1,2,2,3,3,0,0]
        rng.shuffle(ks)
        g=[reflection(rng.randrange(3),k*rng.choice((-1,1))) for k in ks]
        i,j=sorted(rng.choices(range(len(g)+1),k=2))
        segs=(g[:i],g[i:j],g[j:])
        hist=Counter(tuple(trace(s,x) for s in segs) for x in allsets([1,2,3]))
        hit=rng.choice(list(hist))
        miss=tuple(rng.choice(S3) for _ in range(3))
        for target in (hit,miss):
            assert segment_count(segs,target,3)==hist[target]%8
    print("200 three-segment target counts tested independently, including shared controls")


def checks_conjugation():
    for _ in range(400):
        w=rng.randrange(2,13)
        g=[(rng.randint(-4,4),*rng.sample(range(w),2)) for _ in range(rng.randrange(2,30))]
        x={i:rng.randrange(2) for i in range(1,5)}
        flip={i for i in x if rng.randrange(2)}
        changed={k:v^(k in flip) for k,v in x.items()}
        prefix=list(range(w))
        word=[]
        for k,a,b in g:
            if abs(k) in flip:
                word.append((0,prefix[a],prefix[b]))
            if not k or bool(x[abs(k)])==(k>0):
                prefix[a],prefix[b]=prefix[b],prefix[a]
        toggles=simulate(word,{},w)
        assert tuple(toggles[i] for i in prefix)==simulate(g,changed,w)
    print("400 conjugation identities checked on widths 2 to 12")


def split_intervals(positions,keys,ranklo,rankhi):
    """Implement the interval thinning step in the sparse-witness proof."""
    if ranklo==rankhi:
        return keys
    by_end=sorted(keys,key=lambda k:positions[k][rankhi])
    disjoint=[]
    end=-1
    for k in by_end:
        if positions[k][ranklo]>end:
            disjoint.append(k)
            end=positions[k][rankhi]
    # Check all cuts between successive integer positions; only starts can increase a class.
    best=[]
    bestleft=0
    for cut in (positions[k][j]+0.5 for k in keys for j in range(ranklo,rankhi)):
        groups={}
        for k in keys:
            left=sum(t<cut for t in positions[k][ranklo:rankhi+1])
            if 0<left<rankhi-ranklo+1:
                groups.setdefault(left,[]).append(k)
        for left,group in groups.items():
            if len(group)>len(best):
                best=group
                bestleft=left
    if len(disjoint)>=len(best):
        return disjoint
    mid=ranklo+bestleft
    chosen=split_intervals(positions,best,ranklo,mid-1)
    return split_intervals(positions,chosen,mid,rankhi)


def checks_intervals():
    trials=0
    for r in (1,2,3):
        e=lcm(*range(1,r+2))
        n=3*e
        for splits in product((False,True),repeat=max(0,r-1)):
            blocks=[]
            start=0
            for i,flag in enumerate((*splits,True)):
                if flag:
                    blocks.append((start,i+1))
                    start=i+1
            for _ in range(4):
                word=[]
                for a,b in blocks:
                    keys=list(range(n))
                    rng.shuffle(keys)
                    word.extend((k,t) for k in keys for t in range(a,b))
                positions=[[] for _ in range(n)]
                for i,(v,_) in enumerate(word):
                    positions[v].append(i)
                kept=split_intervals(positions,list(range(n)),0,r-1)
                assert len(kept)>=e
                chosen=set(kept[:e])
                w=9
                types=[rng.sample(range(w),2) for _ in range(r)]
                gates=[(0,*types[t]) for k,t in word if k in chosen]
                assert simulate(gates,{},w)==tuple(range(w))
                trials+=1
    print(f"{trials} structured occurrence schedules checked for identity-preserving deletion")


if __name__=="__main__":
    checks_four()
    checks_conjugation()
    checks_intervals()
