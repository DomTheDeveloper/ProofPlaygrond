"""Compile the low t bits of #SAT into a three-lane program with at most three uses per bit."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from three_lane import reflection, rotation, optional_rotation, witness, wins


def dimacs(path):
    n=m=None
    clauses=[]
    row=[]
    for raw in Path(path).read_text().splitlines():
        s=raw.strip()
        if not s or s.startswith("c"):
            continue
        if s.startswith("p"):
            f=s.split()
            if len(f)!=4 or f[:2]!=["p","cnf"] or n is not None:
                raise ValueError("invalid header")
            n,m=map(int,f[2:])
            continue
        if n is None:
            raise ValueError("missing header")
        for x in map(int,s.split()):
            if x:
                row.append(x)
            else:
                clauses.append(row)
                row=[]
    if n is None or n<0 or len(clauses)!=m or row:
        raise ValueError("invalid DIMACS")
    return n,clauses


def small_clauses(n,clauses):
    out=[]
    size=n
    for row in clauses:
        if any(type(x)!=int or not 1<=abs(x)<=n for x in row):
            raise ValueError("unknown literal")
        c=list(dict.fromkeys(row))
        if any(-x in c for x in c):
            continue
        while len(c)>3:
            a,b=c[:2]
            size+=1
            u=size
            out.extend([[-a,u],[-b,u],[a,b,-u]])
            c=[u]+c[2:]
        out.append(c)
    return size,out


def controlled_clause(clauses_vars,row,y):
    """Fourier-synthesize y * OR(row) modulo three with only reflections and fixed rotations."""
    keys=sorted(clauses_vars)+[y]
    pos={k:i for i,k in enumerate(keys)}
    dim=1<<len(keys)
    values=[int((x>>pos[y])&1 and any(bool(x>>pos[abs(l)]&1)==(l>0) for l in row))
            for x in range(dim)]
    coeff=[dim*sum(v*(-1)**((x&mask).bit_count()&1) for x,v in enumerate(values))%3 for mask in range(dim)]
    gates=[]
    active=0
    for i in range(dim):
        mask=i^(i>>1)
        if not coeff[mask]:
            continue
        for j,k in enumerate(keys):
            if (mask^active)>>j&1:
                gates.append(reflection(0,k))
        gates.extend(rotation(coeff[mask]))
        active=mask
    for j,k in enumerate(keys):
        if active>>j&1:
            gates.append(reflection(0,k))
    return gates


def equality(p,q,aux):
    """Use each exposed key once. Pending keys in aux each occur twice."""
    t=len(aux)
    h=0
    turns=[]
    for z in aux:
        h=(h+1)%3
        turns.append(reflection(h,z))
    # U^{-1} R^{1+p+q} U R. For a mismatch the conjugate is the identity.
    return list(reversed(turns))+[reflection(0),reflection(0,p),reflection(0,q)]+turns+[reflection(0)]


def filter_vector(t):
    total=1<<t
    sign=(-1)**t
    v=[(total-sign)//3]*3
    v[t%3]+=sign
    return v


def convolution(a,b,mod):
    return [sum(a[i]*b[(j-i)%3] for i in range(3))%mod for j in range(3)]


def power(v,k,mod):
    r=[1,0,0]
    while k:
        if k&1:
            r=convolution(r,v,mod)
        v=convolution(v,v,mod)
        k>>=1
    return r


def compile_bits(n,clauses,t):
    if t<1:
        raise ValueError("positive precision required")
    base,cs=small_clauses(n,clauses)
    if type(n)!=int or n<0:
        raise ValueError("nonnegative variable count required")
    cs.append([base+1,base+2])
    base+=2
    nextkey=base+1
    gates=[]
    for row in cs:
        for _ in range(t):
            y=nextkey
            nextkey+=1
            gates+=controlled_clause({abs(l) for l in row},row,y)
    # Keep all source, Tseitin and selector bits even if their local phase was constant.
    used={abs(k) for k,_,_ in gates if k}
    for k in range(1,nextkey):
        if k not in used:
            gates.extend([reflection(0,k),reflection(0,k)])
    counts=Counter(k for k,a,b in gates if k)
    # At least one split makes the final sign balanced. Four cancelling gates on
    # an already-counted bit change no outputs when a split is otherwise absent.
    if max(counts.values(),default=0)<=3:
        gates.extend([reflection(0,base)]*4)
        counts[base]+=4
    chunk={}
    constraints=[]
    for k,c in counts.items():
        if c<=3:
            continue
        labels=[k]+list(range(nextkey,nextkey+c-3))
        nextkey+=c-3
        chunk[k]=iter([labels[0]]*2+labels[1:-1]+[labels[-1]]*2)
        constraints+=list(zip(labels,labels[1:]))
    result=[(next(chunk[k]) if k in chunk else k,a,b) for k,a,b in gates]
    for p,q in constraints:
        result+=equality(p,q,range(nextkey,nextkey+t))
        nextkey+=t
    mod=1<<t
    v=convolution(power([1,1,0],len(cs)*t,mod),power(filter_vector(t),len(constraints),mod),mod)
    # Choose a cyclic shift, and if necessary one extra optional rotation,
    # so that a satisfying assignment contributes the inverse of three.
    for flip in range(2):
        for shift in range(3):
            win=(sum(v)-v[(-shift)%3])%mod
            if (3*win)%mod==1:
                if flip:
                    result+=optional_rotation(nextkey)
                    nextkey+=1
                result+=rotation(shift)
                return {"width":3,"gates":result,"precision":t,"controls":nextkey-1,
                        "input_variables":n,"split_filters":len(constraints),"amplified_clauses":len(cs),
                        "calibration_rotation":shift,"calibration_bit":bool(flip),"normalized":True}
        v=convolution(v,[1,1,0],mod)
    raise ArithmeticError("the odd coefficient failed calibration")


def smooth(program,steps):
    """Preserve the advertised residue, making the winning fraction close to 1/3."""
    if steps<2 or steps%2:
        raise ValueError("mixing steps must be positive and even")
    gates=list(program["gates"])
    n=program["controls"]
    b=program["precision"]
    counts=Counter(abs(k) for k,_,_ in gates if k)
    if n<b or not any(v%2 for v in counts.values()):
        raise ValueError("requires a balanced final sign and at least b controls")
    for k in range(n+1,n+steps+1):
        gates.extend(optional_rotation(k))
    gates.extend(rotation(-2*steps))
    return {**program,"gates":gates,"controls":n+steps,"mixing_steps":steps,
            "original_controls":n,"original_gates":len(program["gates"])}


def pin_zero(program):
    """Reorient literal signs so the all-zero setting is an explicit winner."""
    gates=program["gates"]
    found=witness(gates)
    if found is None:
        raise ValueError("the program has no winning setting to pin")
    rebased=[(-key if key and found[abs(key)] else key,a,b) for key,a,b in gates]
    if not wins(rebased,{key:0 for key in found}):
        raise ArithmeticError("zero failed the trace")
    return {**program,"gates":rebased,"all_zero_wins":True}


def decision_formula(n,clauses):
    if n<1:
        raise ValueError("use a formula with at least one variable for the decision offset")
    y=n+1
    return y,[[-y,*c] for c in clauses]+[[y,*range(1,n+1)]]


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("formula")
    p.add_argument("output")
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--bits",type=int)
    g.add_argument("--decision",action="store_true")
    p.add_argument("--mix",type=int,default=0,help="even number of added rotations for a density close to one third")
    p.add_argument("--zero-witness",action="store_true",help="reorient literals so the all-zero setting wins")
    a=p.parse_args()
    n,cs=dimacs(a.formula)
    if a.decision:
        v,rows=decision_formula(n,cs)
        out=compile_bits(v,rows,n+1)
        out["decision_bit"]=n
    else:
        out=compile_bits(n,cs,a.bits)
    if a.mix:
        out=smooth(out,a.mix)
    if a.zero_witness:
        out=pin_zero(out)
    Path(a.output).write_text(json.dumps(out,separators=(",",":"))+"\n")
    print("lanes",3,"controls",out["controls"],"gates",len(out["gates"]),"precision",out["precision"])
