# SAT in the digits of a three-lane routing count

This is the companion code for the research manuscript, prepared for Dominic Dabish. Python 3.10 or newer and its standard library are sufficient. The manuscript source is `Three_Lane_Counting.tex`. A standard LaTeX installation with AMS fonts, TikZ, geometry, booktabs, fancyhdr and hyperref can compile it with two passes of `pdflatex`.

## Reproduce the one-bit examples

From this folder run

```sh
python sat_bits.py examples/satisfiable.cnf example_yes.json --bits 1
python sat_bits.py examples/unsatisfiable.cnf example_no.json --bits 1
python -c 'import json,sys; from checks import truth_count; print([truth_count(json.load(open(p))["gates"]) for p in sys.argv[1:]])' example_yes.json example_no.json
```

The result is `[343, 340]`. Each raw program has 56 gates and 10 bits. Both programs win when only bit 10 is true.

## Give every SAT instance a public winning setting

```sh
python sat_bits.py examples/even_yes.cnf yes_bit.json --decision --mix 40 --zero-witness
python sat_bits.py examples/even_no.cnf no_bit.json --decision --mix 40 --zero-witness
```

These commands generate the two guarded examples saved in the examples directory. Both source model counts are even. In the first case the routing count is 5 modulo 8 and in the second it is 3 modulo 8. Read bit index 2 to recover satisfiability. Both programs accept all zeros. Their winning fractions are within one part in approximately 3.3 trillion of one third in absolute probability. The construction generalizes to any even number of added rotations of at least two. The compiler emits the switch lists. Computing their designated digits for arbitrary formulas in polynomial time is the open step. The small examples are checked in the test scripts.

## Model and algorithms

A JSON program gives its width and an ordered list of gates `[key, lane_a, lane_b]`. Lanes are numbered from zero. Positive keys fire on true, negative keys on false, and zero denotes an unconditional swap. Occurrences with the same absolute key read the same setting. Count each assignment of the occurring keys once. DIMACS inputs retain unused declared variables in the model count. Gate order composes the transpositions on the right. Winning means that the resulting permutation is a single cycle.

| File | Output |
| --- | --- |
| `three_lane.py` | An exact existence decision and witness, a density lower bound, counts modulo powers of three, and an optional relative estimate |
| `two_uses.py` | Count modulo a requested power of two on three lanes, with at most two appearances per control |
| `four_lanes.py` | The corresponding fixed-binary-precision algorithm on four lanes |
| `sat_bits.py` | A three-lane, three-use program preserving a CNF model count modulo a power of two, or a guarded program encoding SAT in one specified bit |
| `exact_matching.py` | A two-use program encoding a connected graph's perfect-matching count in the exact number of winning settings, and its exact-count decoder |
| `checks.py` | Independent explicit traces, direct binary truth tables, local six-permutation filter enumeration, and exact dynamic programming on the emitted gates |
| `check_width.py` | Four-lane, multiple-segment, conjugation, and occurrence-schedule tests |

The fixed-precision algorithms are polynomial at each fixed precision. Their degree grows with precision. The Python implementations prioritize auditability, and the four-lane matching enumeration in particular grows rapidly at higher precision.

```sh
python three_lane.py examples/satisfiable_program.json --power-of-three 2
python three_lane.py examples/read_two.json --relative-error 0.35 --failure 0.02 --seed 6174
python two_uses.py examples/read_two.json --bits 4
python four_lanes.py examples/four_lanes.json --bits 3
python exact_matching.py examples/k33.json --encode k33_program.json
```

The first returns a witness and residue 1 modulo 9. On the two-use examples the binary commands both return 5. Calling the estimator without a seed uses system randomness. A supplied seed supports reproducibility. For a connected graph with an even positive number of vertices, use `--decode-count` with the exact integer count from its encoded program to recover the number of perfect matchings.

## Verification

```sh
python checks.py
python check_width.py
```

The expected output is in `CHECK_RESULTS.txt`. For SAT examples with too many controls for whole truth tables, the block checker enumerates every private setting of each emitted equality word, prunes zero distributions at the requested modulus, and simulates the remaining Boolean core. The exact graph checker forgets each variable after its last occurrence and maintains a histogram of reachable permutations. This permits direct exact checks on large gate lists with few simultaneously active controls. Finite tests complement the mathematical proofs. The results have not been peer reviewed or formalized in a proof assistant.
