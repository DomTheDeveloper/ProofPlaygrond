"""Independent checks using direct permutation traces, bit-parallel truth tables,
six-state convolution of measured filter words, and exact graph enumeration.
Run with python checks.py. The deterministic seed is 71031985.
"""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import product,permutations,combinations
from math import comb
from random import Random
from three_lane import *
from sat_bits import compile_bits, decision_formula, equality, smooth, pin_zero
from two_uses import count_mod_two_power, matching_residues
from exact_matching import encode,decode

rng=Random(71031985)
perms=list(permutations(range(3)))
id_perm=(0,1,2)
def compose(p,q):
    return tuple(p[v] for v in q)
def cyclic(p):
    return all(i!=j for i,j in enumerate(p))

def settings(keys):
    for values in product(range(2),repeat=len(keys)):
        yield dict(zip(keys,values))

def hist(g):
    keys=sorted({abs(k) for k,_,_ in g if k})
    return Counter(trace(g,x) for x in settings(keys))


def truth_count(g):
    keys=sorted({abs(k) for k,_,_ in g if k})
    n=len(keys)
    N=1<<n
    one=(1<<N)-1
    def periodic(i):
        if n<=3:
            return sum(((k>>i)&1)<<k for k in range(N))
        if i<3:
            return int.from_bytes(bytes([[170,204,240][i]])*(N//8),"little")
        run=1<<(i-3)
        return int.from_bytes((bytes(run)+b'\xff'*run)*(N//(16*run)),"little")
    masks={k:periodic(i) for i,k in enumerate(keys)}
    low=[0,one,0]
    high=[0,0,one]
    for key,a,b in g:
        toggle=one if not key else masks[abs(key)]
        if key<0:
            toggle^=one
        for field in (low,high):
            diff=(field[a]^field[b])&toggle
            field[a]^=diff
            field[b]^=diff
    accepted=(low[0]|high[0])&(~low[1]|high[1])&(low[2]|~high[2])&one
    return accepted.bit_count()


def mult(a,b,mod):
    out=Counter()
    for p,n in a.items():
        for q,m in b.items():
            out[compose(p,q)]+=n*m
    return {k:v%mod for k,v in out.items() if v%mod}


def contracted_count(program):
    """Parse actual gate records. Trace each private filter exhaustively. Prune only
    local assignments whose measured six-entry histogram is zero at this modulus.
    """
    g=program["gates"]
    t=program["precision"]
    mod=1<<t
    tail_len=2*int(program["calibration_bit"])+2*int(program["calibration_rotation"]!=0)
    end=len(g)-tail_len
    start=end-(2*t+4)*program["split_filters"]
    base=g[:start]
    tails=hist(g[end:])
    parents={}
    def root(x):
        while x in parents:
            x=parents[x]
        return x
    responses=[]
    for j in range(start,end,2*t+4):
        block=g[j:j+2*t+4]
        p=block[t+1][0]
        q=block[t+2][0]
        private=sorted({k for k,_,_ in block if k and k not in (p,q)})
        assert len(private)==t and p!=q
        table={}
        for u,v in product(range(2),repeat=2):
            table[u,v]=Counter(trace(block,{**z,p:u,q:v}) for z in settings(private))
        assert all(all(c%mod==0 for c in table[u,v].values()) for u,v in [(0,1),(1,0)])
        assert table[0,0]==table[1,1]
        responses.append(table[0,0])
        a,b=root(p),root(q)
        if a!=b:
            parents[b]=a
    original={abs(k) for k,_,_ in base if k}
    roots=sorted({root(k) for k in original})
    histogram=Counter()
    fast=[(root(abs(k)) if k else 0,a,b) for k,a,b in base]
    for assignment in settings(roots):
        histogram[trace(fast,assignment)]+=1
    for response in responses:
        histogram=mult(histogram,response,mod)
    histogram=mult(histogram,tails,mod)
    return sum(v for k,v in histogram.items() if cyclic(k))%mod


def sat_count(n,cs):
    return sum(all(any(bool(x>>(abs(l)-1)&1)==(l>0) for l in c) for c in cs)
               for x in range(1<<n))


def check_algorithms():
    cnt=0
    for i in range(700):
        n=rng.randrange(1,8)
        g=[reflection(rng.randrange(3),rng.randrange(-n,n+1)) for _ in range(rng.randrange(24))]
        v={abs(k) for k,_,_ in g if k}
        w=truth_count(g)
        if i<65:
            assert w==sum(v for p,v in hist(g).items() if cyclic(p))
        x=witness(g)
        assert (x is None)==(w==0)
        assert not x or wins(g,x)
        assert density_lower_bound(g)<=Fraction(w,1<<len(v))
        for t in range(1,6):
            assert count_mod_three_power(g,t)==w%3**t
            cnt+=1
    print("700 unrestricted programs, 3,500 ternary residues, witnesses and density bounds passed")
    for i in range(400):
        n=rng.randrange(1,5)
        ks=list(range(1,n+1))*2
        rng.shuffle(ks)
        ks=ks[:rng.randrange(len(ks)+1)]
        for _ in range(rng.randrange(4)):
            ks.insert(rng.randrange(len(ks)+1),0)
        g=[reflection(rng.randrange(3),k*rng.choice([-1,1])) for k in ks]
        w=truth_count(g)
        for j in range(1,5):
            assert count_mod_two_power(g,j)==w%(1<<j),(g,j,w)
    print("400 two-use programs, 1,600 binary residues passed (mod 2,4,8,16)")
    def brute_matching(n,edges):
        graph=defaultdict(list)
        for a,b,w in edges:
            graph[a].append((b,w))
            graph[b].append((a,w))
        def solve(unmatched):
            if not unmatched:
                return [1,0,0]
            i=min(unmatched)
            h=[0,0,0]
            for j,w in graph[i]:
                if j in unmatched:
                    for r,c in enumerate(solve(unmatched-{i,j})):
                        h[(r+w)%3]+=c
            return h
        return solve(set(range(n)))
    for _ in range(80):
        n=2*rng.randrange(1,5)
        edges=[(i,j,rng.randrange(3)) for i,j in combinations(range(n),2) if rng.random()<0.62]
        ref=brute_matching(n,edges)
        for j in (1,2,3,4):
            assert matching_residues(n,edges,j)==[v%(1<<j) for v in ref]
    print("80 independent weighted matching instances, 320 triples of residues passed")


def frontier_hist(g):
    """Independent exact dynamic programming on the raw gates. Retire each
    control at last use. Its complexity is exponential in the largest live set.
    """
    last={abs(k):i for i,(k,_,_) in enumerate(g) if k}
    permutations_index={p:i for i,p in enumerate(perms)}
    transitions={}
    for a,b in combinations(range(3),2):
        table=[]
        for p in perms:
            copy=list(p)
            copy[a],copy[b]=copy[b],copy[a]
            table.append(permutations_index[tuple(copy)])
        transitions[a,b]=table
    states={(0,permutations_index[id_perm]):1}
    seen=set()
    peak=1
    for i,(key,a,b) in enumerate(g):
        v=abs(key)
        bit=(1<<(v-1)) if v else 0
        table=transitions[tuple(sorted((a,b)))]
        new=defaultdict(int)
        for (mask,j),weight in states.items():
            values=(0,1) if v and v not in seen else (int(bool(mask&bit)),)
            for value in values:
                j2=table[j] if not key or bool(value)==(key>0) else j
                m=mask
                if v and last[v]==i:
                    m&=~bit
                elif value:
                    m|=bit
                new[m,j2]+=weight
        if v:
            seen.add(v)
        states=new
        peak=max(peak,len(states))
    return Counter({perms[j]:v for (_,j),v in states.items()}),peak


def check_reductions():
    small=[(0,[]),(0,[[]]),(1,[[1]]),(1,[[1],[1]]),(1,[[1],[-1]]),
           (1,[[-1]]),(2,[[1,2]]),(2,[[-1,2]]),(2,[[1,-1]]),(2,[[1,1]]),
           (2,[[1,2],[-1,-2]]),(3,[[-1,2,3]]),(3,[[1],[-2]]),(3,[]),
           (3,[[1,2],[-1,3]]),(4,[[1,-2,3,-4]])]
    suite=[]
    for n,cs in small:
        for t in range(1,5):
            # The long-clause conversion is also fully tested at t=1,2.
            if n==4 and t>2:
                continue
            suite.append((n,cs,t))
    for _ in range(55):
        n=rng.randrange(1,4)
        t=rng.randrange(1,4)
        cs=[[rng.choice((-1,1))*rng.randint(1,n) for _ in range(rng.randrange(4))]
            for _ in range(rng.randrange(4))]
        suite.append((n,cs,t))
    wholesale=0
    total_settings=0
    for n,cs,t in suite:
        ref=sat_count(n,cs)%(1<<t)
        prog=compile_bits(n,cs,t)
        g=prog['gates']
        uses=Counter(abs(k) for k,_,_ in g if k)
        assert max(uses.values())<=3 and len(uses)==prog['controls']
        assert contracted_count(prog)==ref,(n,cs,t)
        if len(uses)<=22:
            w=truth_count(g)
            assert w%(1<<t)==ref
            wholesale+=1
            total_settings+=1<<len(uses)
    print(f"{len(suite)} compiled SAT instances verified by raw-filter contraction, {wholesale} also by full truth tables ({total_settings:,} settings)")
    for f in ([[1],[1]],[[1],[-1]]):
        prog=compile_bits(1,f,1)
        h,peak=frontier_hist(prog['gates'])
        w=sum(v for p,v in h.items() if cyclic(p))
        assert w==truth_count(prog['gates'])
        print("source",f,"controls",prog['controls'],"gates",len(prog['gates']),"exact W",w,"of",1<<prog['controls'])
    count=0
    for n,cs in small:
        if not 1<=n<=2:
            continue
        v,phi=decision_formula(n,cs)
        prec=n+1
        prog=compile_bits(v,phi,prec)
        residue=contracted_count(prog)
        assert (residue>>n)==bool(sat_count(n,cs))
        count+=1
    print(f"{count} guarded input formulas recovered SAT from the designated bit")
    for t in range(1,11):
        g=equality(1,2,list(range(3,3+t)))
        for p,q in product(range(2),repeat=2):
            h=Counter(trace(g,{1:p,2:q,**z}) for z in settings(range(3,3+t)))
            if p!=q:
                assert len(h)==1 and list(h.values())==[1<<t] and not cyclic(next(iter(h)))
            else:
                vals=[h[tuple((v+j)%3 for v in range(3))] for j in range(3)]
                sign=(-1)**t
                expected=[((1<<t)-sign)//3]*3
                expected[t%3]+=sign
                assert vals==expected
    print("all four exposed-bit settings of each equality filter, precisions 1 through 10, passed")


def check_smoothing():
    checks=0
    for n,cs in [(0,[]),(0,[[]]),(1,[[1]]),(1,[[1],[1]]),(1,[[1],[-1]]),
                 (2,[[1,2]]),(2,[[1,2],[-1,-2]])]:
        raw=compile_bits(n,cs,1)
        g=raw["gates"]
        w=truth_count(g)
        size=raw["controls"]
        for steps in (2,4,8,40):
            clean=smooth(raw,steps)
            h,peak=frontier_hist(clean["gates"])
            value=sum(v for p,v in h.items() if cyclic(p))
            rebased=pin_zero(clean)
            pinned,unused=frontier_hist(rebased["gates"])
            assert pinned==h
            assert wins(rebased["gates"],dict.fromkeys(range(1,rebased["controls"]+1),0))
            assert sum(h.values())==1<<(size+steps)
            assert value==(((1<<steps)-1)//3)*(1<<size)+w
            assert abs(3*value-(1<<(size+steps)))<=1<<size
            assert value%2==sat_count(n,cs)%2
            if cs in ([[1],[1]],[[1],[-1]]) and steps in (2,40):
                print("smoothed",cs,"mix",steps,"exact W",value,"of",1<<(size+steps))
            checks+=1
    # For larger precisions count the core by its independently traced filter
    # blocks and the actual suffix on its own three-point state space.
    for n,cs in [(0,[]),(0,[[]]),(1,[[1]]),(2,[[1,2]])]:
        for t in (2,3,4):
            raw=compile_bits(n,cs,t)
            value=contracted_count(raw)
            mix=smooth(raw,6)
            mod=1<<t
            suffix=hist(mix["gates"][mix["original_gates"]:])
            d=[suffix[tuple((i+j)%3 for i in range(3))] for j in range(3)]
            assert d==[22,21,21]
            assert (2*d[1]*(1<<(raw["controls"]-1))+value)%mod==sat_count(n,cs)%mod
            checks+=1
    print(f"{checks} density-preserving constructions checked, including 40 mixing steps")


def check_published_examples():
    from sat_bits import dimacs
    examples=Path(__file__).resolve().parent/"examples"
    for stem in ("even_yes","even_no"):
        n,clauses=dimacs(examples/(stem+".cnf"))
        v,guard=decision_formula(n,clauses)
        raw=compile_bits(v,guard,n+1)
        residue=contracted_count(raw)
        result=pin_zero(smooth(raw,40))
        stored=json.loads((examples/(stem+"_decision.json")).read_text())
        assert [list(g) for g in result["gates"]]==stored["gates"]
        assert (residue>>stored["decision_bit"])==bool(sat_count(n,clauses))
        print(stem,"low three bits",format(residue,"03b"),"controls",stored["controls"],"gates",len(stored["gates"]),"zero wins",stored["all_zero_wins"])


def reference_matching(n,edges):
    result=0
    for subset in combinations(edges,n//2):
        if len({v for e in subset for v in e})==n:
            result+=1
    return result


def check_exact():
    graphs=[(2,[(0,1)]),(2,[(0,1)]*3),(4,[(0,1),(1,2),(2,3)]),
            (4,[(0,1),(1,2),(2,3),(3,0)]),(4,[(0,1),(0,2),(0,3)]),
            (4,list(combinations(range(4),2))),(6,[(i,3+j) for i in range(3) for j in range(3)]),
            (6,[(i,(i+1)%6) for i in range(6)]),(6,[(0,i) for i in range(1,6)])]
    for _ in range(15):
        n=rng.choice([2,4,6])
        edges=[(i,rng.randrange(i)) for i in range(1,n)]
        edges+= [(i,j) for i,j in combinations(range(n),2) if (j,i) not in edges and rng.random()<0.27]
        graphs.append((n,edges))
    longest=0
    max_states=0
    for n,edges in graphs:
        prog=encode(n,edges)
        g=prog['gates']
        assert max(Counter(k for k,_,_ in g if k).values())<=2
        h,peak=frontier_hist(g)
        assert sum(h.values())==1<<prog['controls']
        w=sum(v for p,v in h.items() if cyclic(p))
        assert decode(n,len(edges),w)==reference_matching(n,edges)
        longest=max(longest,len(g))
        max_states=max(max_states,peak)
    print(f"{len(graphs)} exact two-use reductions checked from raw gates, longest {longest:,} gates, peak {max_states} reachable states")


if __name__=="__main__":
    check_algorithms()
    check_reductions()
    check_exact()
    check_smoothing()
    check_published_examples()
