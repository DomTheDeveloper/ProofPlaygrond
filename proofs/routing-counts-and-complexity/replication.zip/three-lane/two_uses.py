"""Count winning settings modulo any fixed power of two on three lanes, at most
two appearances per control. Uses a parity subgraph and a Pfaffian expansion.
"""
import argparse
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
from three_lane import validate


def block_prefix_graph(blocks):
    """Each segment has prescribed final sign and its own translation coordinate.
    Return the graph coset plus the constant offsets of these translations.
    """
    groups=defaultdict(list)
    equations=[]
    labels=[]
    offset=[]
    for block,(gates,final_sign) in enumerate(blocks):
        validate(gates)
        h=[(a+b)%3 for _,a,b in gates]
        if not gates and final_sign:
            return None
        offset.append(h[-1]*final_sign%3 if h else 0)
        start=len(labels)
        labels.extend((block,(a-b)%3) for a,b in zip(h,h[1:]))
        for i,(key,_,_) in enumerate(gates):
            indices=[]
            if i>0:
                indices.append(start+i-1)
            if i+1<len(gates):
                indices.append(start+i)
            constant=final_sign if i+1==len(gates) else 0
            if key:
                groups[abs(key)].append((indices,constant^(key<0)))
            else:
                equations.append((indices,constant^1))
    for appearances in groups.values():
        if len(appearances)>2:
            raise ValueError("a control occurs more than twice")
        if len(appearances)==2:
            (a,p),(b,q)=appearances
            equations.append((a+b,p^q))
    ends=[set() for _ in labels]
    synd=[]
    for row,(indices,value) in enumerate(equations):
        synd.append(int(value))
        for col in indices:
            ends[col].symmetric_difference_update([row])
    dummy=len(synd)
    synd.append(sum(synd)%2)
    free=[]
    edges=[]
    for rows,w in zip(ends,labels):
        if not rows:
            free.append(w)
            continue
        vertices=list(rows)
        if len(vertices)==1:
            vertices.append(dummy)
        u,v=vertices
        edges.append((u,v,w))
    return synd,edges,free,offset


def prefix_graph(gates):
    synd,edges,free,_=block_prefix_graph([(gates,0)])
    return synd,[(u,v,w) for u,v,(_,w) in edges],[w for _,w in free]


def parity_matching(synd,original):
    """Reduce edge-selection parities to perfect matchings with unique completions."""
    synd=synd.copy()
    edges=list(original)
    adj=[[] for _ in synd]
    for i,(u,v,w) in enumerate(edges):
        adj[u].append(i)
        adj[v].append(i)
    for v in range(len(synd)):
        while len(adj[v])>3:
            a,b=adj[v].pop(),adj[v].pop()
            u=len(synd)
            synd.append(0)
            for i in (a,b):
                left,right,w=edges[i]
                edges[i]=(u if left==v else left,u if right==v else right,w)
            j=len(edges)
            edges.append((u,v,0))
            adj.append([a,b,j])
            adj[v].append(j)
    n=0
    ports={}
    matched=[]
    for v,(demand,inc) in enumerate(zip(synd,adj)):
        ports_v=list(range(n,n+len(inc)))
        n+=len(inc)
        for i,k in zip(inc,ports_v):
            ports[v,i]=k
        d=len(inc)
        def internal(a,b):
            matched.append((min(a,b),max(a,b),0))
        if d==0 and demand:
            return None
        if d==1 and not demand:
            internal(ports_v[0],n)
            n+=1
        if d==2:
            a,b=ports_v
            if not demand:
                internal(a,b)
            else:
                internal(a,n)
                internal(b,n)
                n+=1
        if d==3:
            a,b,c=ports_v
            internal(a,b)
            if demand:
                internal(a,c)
                internal(b,c)
            else:
                internal(a,n)
                internal(b,n)
                internal(c,n)
                n+=1
    for i,(u,v,w) in enumerate(edges):
        a,b=sorted((ports[u,i],ports[v,i]))
        matched.append((a,b,w))
    return n,matched


def pfaffian(matrix):
    """Fraction-free skew elimination over the integers."""
    n=len(matrix)
    if n%2:
        return 0
    if not n:
        return 1
    a=[row[:] for row in matrix]
    sign=previous=1
    for i in range(0,n-2,2):
        p=next((j for j in range(i+1,n) if a[i][j]),None)
        if p is None:
            return 0
        if p!=i+1:
            a[p],a[i+1]=a[i+1],a[p]
            for row in a:
                row[p],row[i+1]=row[i+1],row[p]
            sign=-sign
        pivot=a[i][i+1]
        for j in range(i+2,n):
            for k in range(j+1,n):
                val=(pivot*a[j][k]-a[i][j]*a[i+1][k]+a[i][k]*a[i+1][j])//previous
                a[j][k]=val
                a[k][j]=-val
        previous=pivot
    return sign*a[-2][-1]


def matching_residues(n,edges,precision):
    mod=1<<precision
    if n%2:
        return [0,0,0]
    # A signed coefficient has magnitude at most the number of pairings, < base/2.
    base=1<<(n*max(1,(n+1).bit_length())+3)
    a=[[0]*n for _ in range(n)]
    for i,j,w in edges:
        a[i][j]=base**w
        a[j][i]=-a[i][j]
    full=(1<<n)-1
    @lru_cache(maxsize=10000)
    def minor(mask):
        vertices=[i for i in range(n) if mask>>i&1]
        value=pfaffian([[a[i][j] for j in vertices] for i in vertices])
        out=[0,0,0]
        for degree in range(len(vertices)+1):
            value,rem=divmod(value,base)
            if rem>base//2:
                rem-=base
                value+=1
            out[degree%3]+=rem
            if not value:
                break
        if value:
            raise ArithmeticError("polynomial degree exceeded")
        return tuple(c%mod for c in out)
    crossings=[]
    if precision>1:
        for i,e in enumerate(edges):
            for j in range(i):
                f=edges[j]
                if e[0]<f[0]<e[1]<f[1] or f[0]<e[0]<f[1]<e[1]:
                    crossings.append((j,i))
    result=list(minor(full))
    for k in range(1,min(precision-1,len(crossings))+1):
        prefactor=(-2)**k
        for selected in combinations(crossings,k):
            mask=full
            sign=1
            degree=0
            force=sorted(set(edge for pair in selected for edge in pair))
            for i in force:
                u,v,w=edges[i]
                endpoints=(1<<u)|(1<<v)
                if mask&endpoints!=endpoints:
                    break
                between=((1<<v)-(1<<(u+1)))&mask
                if between.bit_count()%2:
                    sign=-sign
                mask^=endpoints
                degree+=w
            else:
                for j,val in enumerate(minor(mask)):
                    result[(j+degree)%3]+=prefactor*sign*val
    return [v%mod for v in result]


def count_mod_two_power(gates,precision):
    if precision<1:
        raise ValueError("positive precision required")
    synd,edges,free=prefix_graph(gates)
    graph=parity_matching(synd,edges)
    if graph is None:
        return 0
    h=matching_residues(*graph,precision)
    mod=1<<precision
    for shift in free:
        h=[(h[i]+h[(i-shift)%3])%mod for i in range(3)]
    return (h[1]+h[2])%mod


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("program")
    p.add_argument("--bits",type=int,required=True)
    args=p.parse_args()
    g=json.loads(Path(args.program).read_text())
    if g.get("width")!=3:
        p.error("input must specify three lanes")
    print(count_mod_two_power(g["gates"],args.bits))
