"""Exact algebra for three-lane switch programs. A gate (v,a,b) swaps lanes a,b
unconditionally for v=0, on a true bit for v>0, and on a false bit for v<0.
Every named variable occurring in the program is counted. Gate order is unchanged.
"""
import argparse
from collections import defaultdict
from fractions import Fraction
from math import ceil, comb, log
from random import Random, SystemRandom
import json
from pathlib import Path


def reflection(index, key=0):
    a,b=((1,2),(0,1),(0,2))[index%3]
    return (key,a,b)


def rotation(power):
    power%=3
    return [] if not power else [reflection(power),reflection(0)]


def optional_rotation(key):
    return [reflection(1,key),reflection(0,key)]


def validate(gates):
    for gate in gates:
        if len(gate)!=3 or any(type(v)!=int for v in gate):
            raise ValueError("each gate needs three integers")
        _,a,b=gate
        if a==b or a not in range(3) or b not in range(3):
            raise ValueError("choose two different lanes in 0,1,2")


def trace(gates, setting):
    """Direct three-token simulation, independent of the sparse algebra."""
    lanes=[0,1,2]
    for key,a,b in gates:
        if key==0 or bool(setting[abs(key)])==(key>0):
            lanes[a],lanes[b]=lanes[b],lanes[a]
    return tuple(lanes)


def wins(gates,setting):
    return all(i!=v for i,v in enumerate(trace(gates,setting)))


def data(gates):
    """Integer character sum for twice the translation, restricted to even sign.
    Return (coefficients, free keys, eliminated key, reconstruction mask, constant).
    Return None if no even output exists.
    """
    validate(gates)
    keys=sorted({abs(k) for k,_,_ in gates if k})
    idx={k:i for i,k in enumerate(keys)}
    mask=const=0
    coeff=defaultdict(int)
    for key,a,b in gates:
        h=(a+b)%3
        coeff[mask]+=h*(-1 if const else 1)
        if key:
            mask^=1<<idx[abs(key)]
        if key<=0:
            const^=1
        coeff[mask]-=h*(-1 if const else 1)
    if not mask:
        if const:
            return None
        return dict(coeff),keys,None,0,0
    bit=mask&-mask
    pos=bit.bit_length()-1
    def drop(x):
        return (x&(bit-1))|((x>>(pos+1))<<pos)
    replacement=drop(mask^bit)
    restricted=defaultdict(int)
    for m,c in coeff.items():
        h=drop(m)
        if m&bit:
            h^=replacement
            if const:
                c=-c
        restricted[h]+=c
    return dict(restricted),keys[:pos]+keys[pos+1:],keys[pos],replacement,const


def reduce3(coeff):
    return {m:c%3 for m,c in coeff.items() if c%3}


def specialize(coeff,bit,value):
    out=defaultdict(int)
    for mask,c in coeff.items():
        out[mask&~bit]+= -c if value and mask&bit else c
    return reduce3(out)


def witness(gates):
    d=data(gates)
    if d is None:
        return None
    coeff,keys,pivot,repl,const=d
    active=reduce3(coeff)
    if not active:
        return None
    bits=0
    # Preserve a nonzero restricted character sum at every step.
    for i in range(len(keys)):
        zero=specialize(active,1<<i,0)
        if zero:
            active=zero
        else:
            bits|=1<<i
            active=specialize(active,1<<i,1)
    ans={k:(bits>>i)&1 for i,k in enumerate(keys)}
    if pivot is not None:
        ans[pivot]=((bits&repl).bit_count()&1)^const
    if not wins(gates,ans):
        raise ArithmeticError("routing witness failed direct tracing")
    return ans


def density_lower_bound(gates):
    d=data(gates)
    if d is None:
        return Fraction(0)
    s=len(reduce3(d[0]))
    return Fraction(1,(2 if d[2] is not None else 1)*s) if s else Fraction(0)


def estimate(gates, epsilon, failure=0.05, seed=None):
    """Multiplicative Chernoff estimator. A supplied seed serves reproducible runs."""
    if not 0<epsilon<1 or not 0<failure<1:
        raise ValueError("relative error and failure probability must lie between zero and one")
    lower=density_lower_bound(gates)
    if not lower:
        return Fraction(0),0
    keys=sorted({abs(k) for k,_,_ in gates if k})
    samples=ceil(3*lower.denominator*log(2/failure)/(epsilon**2))
    rng=SystemRandom() if seed is None else Random(seed)
    hits=0
    for _ in range(samples):
        x=rng.getrandbits(len(keys))
        hits+=wins(gates,{k:(x>>i)&1 for i,k in enumerate(keys)})
    return Fraction(hits*(1<<len(keys)),samples),samples


def cube_product(f,g,mod):
    h=defaultdict(int)
    for mask,c in f.items():
        for other,d in g.items():
            h[mask^other]+=c*d
    return {m:c%mod for m,c in h.items() if c%mod}


def count_mod_three_power(gates,precision):
    """Exact answer mod 3**precision, deterministic L**O(precision) arithmetic."""
    if precision<1:
        raise ValueError("positive precision required")
    d=data(gates)
    if d is None:
        return 0
    coeff,keys,*_=d
    mod=3**precision
    f={m:c%mod for m,c in coeff.items() if c%mod}
    y=cube_product(f,f,mod)
    # B(y) is a binomial tail; threshold u suffices since 3|x implies 9|x*x.
    u=(precision+1)//2
    degree=u+precision-1
    constants=[0]*(degree+1)
    for j in range(u,degree+1):
        for k in range(degree-j+1):
            constants[j+k]+=comb(degree,j)*comb(degree-j,k)*(-1)**k
    power={0:1}
    coeff0=0
    for j,c in enumerate(constants):
        coeff0+=c*power.get(0,0)
        if j<degree:
            power=cube_product(power,y,mod)
    return coeff0*pow(2,len(keys),mod)%mod


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("program")
    p.add_argument("--power-of-three",type=int,default=1)
    p.add_argument("--relative-error",type=float)
    p.add_argument("--failure",type=float,default=0.05)
    p.add_argument("--seed",type=int,help="optional reproducible pseudorandom run")
    a=p.parse_args()
    src=json.loads(Path(a.program).read_text())
    if src.get("width")!=3:
        p.error("input must specify three lanes")
    g=src["gates"]
    out={"witness":witness(g),"minimum_winning_fraction":str(density_lower_bound(g)),
         "modulus":3**a.power_of_three,"winning_residue":count_mod_three_power(g,a.power_of_three)}
    if a.relative_error is not None:
        value,samples=estimate(g,a.relative_error,a.failure,a.seed)
        out.update(estimated_count=str(value),samples=samples)
    print(json.dumps(out,sort_keys=True))
