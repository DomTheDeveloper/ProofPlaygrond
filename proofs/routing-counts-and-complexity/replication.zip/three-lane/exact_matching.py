"""Encode a connected graph's perfect-matching count in an exact three-lane
two-use routing count. Vertices are integers 0,...,n-1. Graphs may have parallel
edges; loops are excluded. Supplying an oracle count is a separate operation.
"""
import argparse
from math import comb
from pathlib import Path
import json
from three_lane import reflection, rotation


def encode(n,edges,multiplicity=None):
    if n<=0 or n%2:
        raise ValueError("positive even vertex count required")
    m=len(edges)
    ell=12*(m+1) if multiplicity is None else multiplicity
    if ell<=0 or ell%2:
        raise ValueError("positive even multiplicity required")
    adj=[[] for _ in range(n)]
    for j,(a,b) in enumerate(edges):
        if not(0<=a<n and 0<=b<n) or a==b:
            raise ValueError("bad edge")
        for k in range(ell):
            serial=j*ell+k
            adj[a].append((serial,b))
            adj[b].append((serial,a))
    stack=[0]
    used=set()
    tour=[]
    while stack:
        v=stack[-1]
        while adj[v] and adj[v][-1][0] in used:
            adj[v].pop()
        if adj[v]:
            edge,w=adj[v].pop()
            used.add(edge)
            stack.append(w)
        else:
            tour.append(stack.pop())
    tour.reverse()
    if len(tour)!=m*ell+1 or len(set(tour))!=n:
        raise ValueError("connected graph required")
    visits=[[] for _ in range(n)]
    for j,v in enumerate(tour):
        visits[v].append(j)
    layers=[[] for _ in tour]
    nextkey=1
    # The first and last time slots are distinct visits to the root.
    for times in visits:
        layers[times[0]].append(reflection(0))
        for i,j in zip(times,times[1:]):
            gate=reflection(0,nextkey)
            nextkey+=1
            layers[i].append(gate)
            layers[j].append(gate)
    gates=[]
    for i,layer in enumerate(layers):
        gates+=layer
        if i+1<len(layers):
            gates+=rotation(1)
    gates+=rotation(-m*ell)
    return {"width":3,"gates":gates,"controls":nextkey-1,"multiplicity":ell,"vertices":n,"edges":m}


def decode(n,m,winners):
    ell=12*(m+1)
    base=3**(ell//2)
    total=1<<(m*ell-n+1)
    if winners%2:
        raise ValueError("unexpected odd count")
    value=(1<<m)*(total-3*winners//2)
    coeff=[]
    for _ in range(m+1):
        value,d=divmod(value,base)
        if d>base//2:
            d-=base
            value+=1
        coeff.append(d)
    if value:
        raise ValueError("unexpected coefficient length")
    j=n//2
    if j>m:
        return 0
    numerator=0
    for i,c in enumerate(coeff):
        target=sum((-1)**k*comb(i,k)*comb(m-i,j-k)
                   for k in range(max(0,j-m+i),min(i,j)+1))
        numerator+=c*target
    if numerator%(1<<m):
        raise ValueError("nonintegral coefficient")
    return numerator>>m


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("graph")
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--encode")
    g.add_argument("--decode-count",type=int)
    a=p.parse_args()
    source=json.loads(Path(a.graph).read_text())
    n=source["vertices"]
    edges=source["edges"]
    if a.encode:
        out=encode(n,edges)
        Path(a.encode).write_text(json.dumps(out,separators=(",",":"))+"\n")
        print("gates",len(out["gates"]),"controls",out["controls"])
    else:
        print(decode(n,len(edges),a.decode_count))
