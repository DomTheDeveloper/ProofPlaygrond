"""Fixed binary precision on four lanes with at most two uses per control.
The algorithm first expands a parity in Z/2^b, then counts a bounded number of
three-lane prefix constraints. The high-degree polynomial is intended for audit.
"""
from collections import Counter
from itertools import product,permutations,combinations
from functools import lru_cache
import argparse
from pathlib import Path
import json
from two_uses import block_prefix_graph,parity_matching,matching_residues

S3=tuple(permutations(range(3)))
ID=(0,1,2)
ODD=tuple(p for p in S3 if sum(i==j for i,j in enumerate(p))==1)
def inverse(p):
    return tuple(p.index(i) for i in range(3))
def compose(p,q):
    return tuple(p[j] for j in q)
def linear(p,v):
    return p[v-1]+1 if v else 0


def decompose(a,b):
    p=list(range(4))
    p[a],p[b]=p[b],p[a]
    d=p[0]
    q=tuple((p[i]^d)-1 for i in (1,2,3))
    return tuple(i for i in range(3) if i!=q[i]),d


def segment_count(segments,targets,bits):
    signs=[int(p in ODD) for p in targets]
    data=block_prefix_graph(zip(segments,signs))
    if data is None:
        return 0
    synd,edges,free,offset=data
    target=[(p[0]-o)%3 for p,o in zip(targets,offset)]
    dim=len(target)
    mod=1<<bits
    @lru_cache(maxsize=None)
    def projection(direction):
        def w(pair):
            return direction[pair[0]]*pair[1]%3
        graph=parity_matching(synd,[(u,v,w(a)) for u,v,a in edges])
        if graph is None:
            return (0,0,0)
        h=matching_residues(*graph,bits)
        for x in free:
            step=w(x)
            h=[(h[i]+h[(i-step)%3])%mod for i in range(3)]
        return h
    total=sum(projection((0,)*dim))%mod
    acc=total
    for direction in product(range(3),repeat=dim):
        if next((j for j in direction if j),0)!=1:
            continue
        desired=sum(a*b for a,b in zip(direction,target))%3
        acc+=3*projection(direction)[desired]-total
    return acc*pow(3**dim,-1,mod)%mod


def count_four(gates,bits):
    if bits<1:
        raise ValueError("positive precision required")
    used=Counter()
    projected=[]
    translations=[]
    for k,a,b in gates:
        if a==b or a not in range(4) or b not in range(4):
            raise ValueError("bad transposition")
        if k:
            used[abs(k)]+=1
        ab,d=decompose(a,b)
        projected.append((k,*ab))
        translations.append(d)
    if max(used.values(),default=0)>2:
        raise ValueError("more than two uses")
    active=[i for i,d in enumerate(translations) if d]
    mod=1<<bits
    answer=0
    for k in range(1,min(bits,len(active))+1):
        for marked in combinations(active,k):
            forced={}
            for i in marked:
                key=projected[i][0]
                if key:
                    value=int(key>0)
                    if abs(key) in forced and forced[abs(key)]!=value:
                        break
                    forced[abs(key)]=value
            else:
                ends=(*marked,len(gates))
                start=0
                segments=[]
                for end in ends:
                    segment=[]
                    for key,a,b in projected[start:end]:
                        if abs(key) in forced:
                            if forced[abs(key)]==int(key>0):
                                segment.append((0,a,b))
                        else:
                            segment.append((key,a,b))
                    segments.append(segment)
                    start=end
                for final in ODD:
                    candidates=[]
                    for i in marked:
                        options=(ID,) if i==0 else S3
                        candidates.append([p for p in options if linear(final,linear(p,translations[i]))!=linear(p,translations[i])])
                    for prefixes in product(*candidates):
                        before=(ID,*prefixes)
                        after=(*prefixes,final)
                        targets=tuple(compose(inverse(p),q) for p,q in zip(before,after))
                        if any(not segment and target!=ID for segment,target in zip(segments,targets)):
                            continue
                        answer+=(-2)**(k-1)*segment_count(segments,targets,bits-k+1)
    return answer%mod


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("program")
    p.add_argument("--bits",type=int,required=True)
    a=p.parse_args()
    g=json.loads(Path(a.program).read_text())
    if g.get("width")!=4:
        p.error("input must specify four lanes")
    print(count_four(g["gates"],a.bits))
