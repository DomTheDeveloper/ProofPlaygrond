"""Exact cover and generalized Sudoku as one-cycle switch programs."""
from collections import Counter
from itertools import permutations, product
from math import isqrt
import argparse
import json
from pathlib import Path
from routing import route


def cover(groups):
    """A row lists distinct candidate IDs that may cover one required element."""
    if not groups or any(not row for row in groups):
        return (1 if not groups else 2),[]
    gates=[]
    anchors=[]
    w=0
    for row in groups:
        if len(set(row))!=len(row) or min(row)<1:
            raise ValueError("each incidence row needs distinct positive candidate IDs")
        d=len(row)
        a=list(range(w,w+d)); b=list(range(w+d,w+2*d));w+=2*d
        gates.extend((key,i,j) for key,i,j in zip(row,a,b))
        gates.extend((0,a[0],j) for j in a[1:])
        gates.extend((0,b[0],j) for j in b[:0:-1])
        anchors.append(a[0])
    gates.extend((0,anchors[0],j) for j in anchors[1:])
    return w,gates


def sudoku(board):
    n=len(board); box=isqrt(n)
    if not n or box*box!=n or any(len(row)!=n for row in board):
        raise ValueError("expected an N by N board with square boxes")
    if any(not isinstance(v,int) or not 0<=v<=n for row in board for v in row):
        raise ValueError("clues must be digits 1 through N, or 0 for empty")
    rows=[[] for _ in range(4*n*n)]
    ids={}
    for i,j in product(range(n),repeat=2):
        for k in range(n):
            if board[i][j] not in (0,k+1): continue
            a=2*len(ids)+1;b=a+1;ids[i,j,k+1]=(a,b)
            box_id=(i//box)*box+j//box
            for ix,key in [(i*n+j,a),(n*n+i*n+k,a),
                           (2*n*n+j*n+k,b),(3*n*n+box_id*n+k,b)]:
                rows[ix].append(key)
    width,gates=cover(rows)
    if any(not row for row in rows): return width,gates,{}
    for a,b in ids.values():
        gates.extend([(a,0,width),(b,0,width),(0,0,width)])
        width+=1
    return width,gates,ids


def test():
    checks=0
    for n in range(1,8):
        w,g=cover([list(range(1,n+1))])
        for x in range(1<<n):
            assert len(route(w,g,x))==(x.bit_count() or 2)
            checks+=1
    # Every bipartite graph on 3+3 vertices with no isolated vertex.
    grid=[(i,j) for i,j in product(range(3),repeat=2)]
    matches=0
    for mask in range(1<<9):
        es=[e for k,e in enumerate(grid) if mask>>k&1]
        rows=[[] for _ in range(6)]
        for label,(i,j) in enumerate(es,1):
            rows[i].append(label);rows[3+j].append(label)
        if any(not ns for ns in rows): continue
        w,g=cover(rows)
        expected=sum(all((i,p[i]) in es for i in range(3)) for p in permutations(range(3)))
        actual=sum(len(route(w,g,x))==1 for x in range(1<<len(es)))
        assert actual==expected;matches+=1
    def audit_sudoku(n):
        board=[[0]*n for _ in range(n)]
        w,g,ids=sudoku(board)
        assert set(Counter(abs(k) for k,_,_ in g if k).values())=={3}
        root=isqrt(n)
        solution=[[(i*root+i//root+j)%n+1 for j in range(n)] for i in range(n)]
        def scan(a):
            bits=sum(1<<(k-1) for i,j in product(range(n),repeat=2) for k in ids[i,j,a[i][j]])
            assert len(route(w,g,bits))==1
            assert len(route(w,g,bits^(1<<(ids[0,0,a[0][0]][0]-1))))>1
        scan(solution)
        if n==4:
            allrows=list(permutations(range(1,5)));total=0
            for a,b in product(allrows,repeat=2):
                if len({a[0],a[1],b[0],b[1]})<4 or len({a[2],a[3],b[2],b[3]})<4: continue
                for c in allrows:
                    if any(len({a[j],b[j],c[j]})!=3 for j in range(4)):continue
                    d=tuple(10-a[j]-b[j]-c[j] for j in range(4))
                    if (len(set(d))<4 or len({c[0],c[1],d[0],d[1]})<4
                            or len({c[2],c[3],d[2],d[3]})<4): continue
                    scan((a,b,c,d));total+=1
            assert total==288
            print("All 288 completed 4x4 boards and one corrupted copy per board verified")
        print("Empty Sudoku side",n,"lanes",w,"control bits",2*len(ids),"controlled swaps",sum(bool(k) for k,_,_ in g))
    print("Opposite ring assignments",checks,"bipartite perfect-matching counts",matches)
    audit_sudoku(4);audit_sudoku(9)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--sudoku",help="JSON square array, entries 0 through N")
    p.add_argument("--output",help="output routing JSON")
    a=p.parse_args()
    if a.sudoku:
        if not a.output: p.error("--output is required with --sudoku")
        w,g,ids=sudoku(json.loads(Path(a.sudoku).read_text()))
        Path(a.output).write_text(json.dumps({"width":w,"gates":g,"cells":[[*k,*v] for k,v in ids.items()]})+"\n")
    else: test()
