"""Check circuit nullity, the parity identity and the three-use reduction independently."""
from itertools import product
from collections import Counter
from fractions import Fraction
import random
from routing import (compile_three, cycles, one_use_count, nonsingular, reference, route, sampled_exists,
                     split_three, winning_parity, solve, two_use_witness)


def rank_on(rows, inds):
    work=[rows[i] for i in inds]
    row=0
    for col in inds:
        j=next((j for j in range(row,len(work)) if work[j]>>col&1),None)
        if j is None: continue
        work[row],work[j]=work[j],work[row]
        for j in range(row+1,len(work)):
            if work[j]>>col&1: work[j]^=work[row]
        row+=1
    return row


def check_two(w,g,rng,c):
    raw=sorted({abs(k) for k,_,_ in g if k})
    r=reference(w,g)
    yes=0
    for bv in product((0,1),repeat=len(raw)):
        bits=sum(v<<(k-1) for k,v in zip(raw,bv))
        num=len(route(w,g,bits))
        if r is not None:
            chosen=[j for j,(k,rj) in enumerate(zip(r.labels,r.offset)) if (bits>>(k-1)&1)^rj]
            assert num==1+len(chosen)-rank_on(r.interlace,chosen)
        yes+=(num==1);c["two-use assignments"]+=1
    ans=two_use_witness(r)
    assert (ans is not None)==bool(yes)
    if ans is not None:
        assert len(route(w,g,sum(v<<(k-1) for k,v in ans.items())))==1
    assert winning_parity(r)==yes%2
    assert sampled_exists(r,6,rng)==bool(yes)
    c["two-use instances"]+=1
    c["feasible"]+=bool(yes)
    c["feasible with even count"]+=yes>0 and yes%2==0


def test_split(w,g):
    width,new,groups=split_three(w,g)
    counts=Counter(abs(k) for k,_,_ in new if k); assert max(counts.values(),default=0)<=3
    fresh=max(counts,default=0)
    total=0
    for bits in range(1<<fresh):
        bad=sum(((bits>>(i-1))^(bits>>(j-1)))&1 for group in groups.values()
                for i,j in zip(group,group[1:]))
        active=[(k,a,b) for k,a,b in new[:len(g)]]
        assert len(route(width,new,bits))==len(route(w,active,bits))+bad
        if len(route(width,new,bits))==1: total+=1
    labels=sorted(groups)
    before=sum(len(route(w,g,sum(b<<(k-1) for b,k in zip(word,labels))))==1
               for word in product((0,1),repeat=len(labels)))
    assert before==total
    result=solve(w,g)
    assert (result is not None)==bool(total)
    if result is not None:
        assert len(route(w,g,sum(v<<(k-1) for k,v in result.items())))==1
    return 1<<fresh


def cnf_cases(rng):
    sels=0
    for n,cs in [(1,[(1,)]),(1,[(1,),(-1,)]),(2,[]),(2,[()]),(3,[(1,2),(-2,3)])]:
        w,g,groups=compile_three(n,cs)
        assert max(Counter(abs(k) for k,_,_ in g if k).values())<=3
        for x in range(1<<n):
            bits=sum(1<<(v-1) for k,vs in groups.items() for v in vs if x>>(k-1)&1)
            val=all(any(bool(x>>(abs(l)-1)&1)==(l>0) for l in clause) for clause in cs)
            assert (len(route(w,g,bits))==1)==val
            for _ in range(4):
                copies=rng.choice([v for v in groups.values() if len(v)>1])
                changed=bits^(1<<(rng.choice(copies)-1))
                assert len(route(w,g,changed))>1
                sels+=1
            sels+=1
    return sels


def cofactor(perm_mats):
    n=len(perm_mats[0])
    m=[[Fraction(int(i==j))-Fraction(sum(int(p[i]==j) for p in perm_mats),len(perm_mats))
        for j in range(n-1)] for i in range(n-1)]
    d=Fraction(1)
    for i in range(n-1):
        j=next((j for j in range(i,n-1) if m[j][i]),None)
        if j is None: return Fraction(0)
        if i!=j: m[i],m[j]=m[j],m[i];d=-d
        p=m[i][i];d*=p
        for j in range(i+1,n-1):
            a=m[j][i]/p
            for k in range(i,n-1): m[j][k]-=a*m[i][k]
    return d


def main():
    rng=random.Random(20261121);c=Counter()
    for w in range(1,7):
        check_two(w,[],rng,c)
    for _ in range(500):
        w=rng.randrange(2,8); n=rng.randrange(1,7)
        keys=[i for i in range(1,n+1) for _ in range(rng.randrange(1,3))]
        keys+=[0]*rng.randrange(3);rng.shuffle(keys)
        g=[(k*rng.choice((-1,1)),*rng.sample(range(w),2)) for k in keys]
        check_two(w,g,rng,c)
    for _ in range(150):
        w=rng.randrange(2,7); n=rng.randrange(1,4)
        g=[(rng.randrange(-n,n+1),*rng.sample(range(w),2)) for _ in range(rng.randrange(1,9))]
        c["split-copy assignments"]+=test_split(w,g);c["split-copy programs"]+=1
    for _ in range(250):
        w=rng.randrange(2,9)
        keys=list(range(1,rng.randrange(2,9)))+[0]*rng.randrange(4)
        rng.shuffle(keys)
        g=[(k*rng.choice((-1,1)),*rng.sample(range(w),2)) for k in keys]
        count=sum(len(route(w,g,x))==1 for x in range(1<<max(keys)))
        assert count==one_use_count(w,g)
        c["one-use exact counts"]+=1
    for _ in range(200):
        w=rng.randrange(2,7)
        keys=[1,2,3]+[k for k in (4,5,6) for _ in range(rng.choice((1,2)))]+[0]
        rng.shuffle(keys)
        g=[(k*rng.choice((-1,1)),*rng.sample(range(w),2)) for k in keys]
        rel={x&7 for x in range(64) if len(route(w,g,x))==1}
        for x in rel:
            for y in rel:
                dif=[1<<i for i in range(3) if (x^y)>>i&1]
                for i in dif:
                    assert any(x^(i|j) in rel for j in dif)
        assert rel!={0,7}
        c["projected exchange checks"]+=1
    print(dict(c))
    print("Direct CNF routing checks (consistent and corrupted copies):",cnf_cases(rng))
    p=[1,0,3,2];q=[3,2,1,0]
    assert cofactor([p])==cofactor([q])==0 and cofactor([p,q])==Fraction(1,2)
    print("Correlated-switch cofactor:",cofactor([p]),cofactor([q]),cofactor([p,q]))

if __name__=="__main__": main()
