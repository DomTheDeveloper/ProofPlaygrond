"""One-cycle permutation programs. Gate (v,a,b) swaps lanes a,b if v is true.
v=0 swaps unconditionally; negative v negates a control. Lane indices start at 0.
The two-use solver is deterministic and returns an explicit assignment. A finite-field
identity test is also provided for independent checks.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product
from random import SystemRandom
import argparse
import json
from pathlib import Path
from cnf_to_source import normalize, program, read_dimacs
from delta_parity import two_use_witness


def cycles(perm):
    unused=set(range(len(perm)))
    out=[]
    while unused:
        x=next(iter(unused))
        block=[]
        while x in unused:
            unused.remove(x)
            block.append(x)
            x=perm[x]
        out.append(block)
    return out


def route(width, gates, bits):
    tokens=list(range(width))
    for key,a,b in gates:
        if key==0 or bool(bits>>(abs(key)-1)&1)==(key>0):
            tokens[a],tokens[b]=tokens[b],tokens[a]
    return cycles(tokens)


def bareiss(matrix):
    """Fraction-free determinant with row pivots. The empty determinant is one."""
    a=[row[:] for row in matrix]
    if not a: return 1
    denom=sign=1
    for i in range(len(a)-1):
        j=next((j for j in range(i,len(a)) if a[j][i]),None)
        if j is None: return 0
        if i!=j:
            a[i],a[j]=a[j],a[i];sign=-sign
        pivot=a[i][i]
        for r in range(i+1,len(a)):
            for c in range(i+1,len(a)):
                a[r][c]=(a[r][c]*pivot-a[r][i]*a[i][c])//denom
        denom=pivot
    return sign*a[-1][-1]


def one_use_count(width,gates):
    if width<1: raise ValueError("at least one lane required")
    q=[[int(i==j) for j in range(width)] for i in range(width)]
    labels=set()
    for key,a,b in gates:
        if not 0<=a<width or not 0<=b<width or a==b:
            raise ValueError("a switch needs two different valid lanes")
        if not key: q[a],q[b]=q[b],q[a]; continue
        if abs(key) in labels: raise ValueError("a control occurs twice")
        labels.add(abs(key))
        total=[i+j for i,j in zip(q[a],q[b])]
        q=[total[:] if i in (a,b) else [2*x for x in row] for i,row in enumerate(q)]
    scale=1<<len(labels)
    minor=[[scale*int(i==j)-q[i][j] for j in range(width-1)] for i in range(width-1)]
    return scale*bareiss(minor)//(scale**(width-1))


def split_three(width, gates):
    groups=defaultdict(list)
    out=[]
    next_key=1
    for key,a,b in gates:
        if not key:
            out.append((0,a,b))
            continue
        groups[abs(key)].append(next_key)
        out.append((next_key if key>0 else -next_key,a,b))
        next_key+=1
    for labels in groups.values():
        for p,q in zip(labels,labels[1:]):
            fresh=width
            width+=1
            out.extend([(p,0,fresh),(q,0,fresh),(0,0,fresh)])
    return width,out,dict(groups)


def compile_three(n,clauses):
    lanes,steps=program(normalize(n,clauses))
    ids={lane:i for i,lane in enumerate(lanes)}
    gates=[(s.literal,ids[a],ids[b]) for s in steps for a,b in s.pairs]
    return split_three(len(lanes),gates)


@dataclass
class Reference:
    interlace: list
    offset: list
    labels: list


def reference(width, gates):
    """Euler circuit with independent choices, or None when no such circuit exists."""
    if width<1: raise ValueError("at least one lane required")
    count=sum(bool(k) for k,_,_ in gates)
    next_port=[None]*(2*count+width)
    last=list(range(2*count,2*count+width))
    keys=[]
    for key,a,b in gates:
        if not 0<=a<width or not 0<=b<width or a==b:
            raise ValueError("a switch needs two different valid lanes")
        if not key:
            last[a],last[b]=last[b],last[a]
            continue
        for d,lane in enumerate((a,b)):
            target=2*len(keys)+d
            next_port[last[lane]]=target
            last[lane]=target
        keys.append(key)
    for i,v in enumerate(last):
        next_port[v]=2*count+i
    parts=cycles(next_port)
    if any(all(x>=2*count for x in comp) for comp in parts):
        return Reference([],[],[]) if len(parts)==1 else None
    component={x:j for j,comp in enumerate(parts) for x in comp}
    parents=list(range(len(parts)))
    def root(a):
        while parents[a]!=a:
            parents[a]=parents[parents[a]]
            a=parents[a]
        return a
    ref=[]
    for j in range(count):
        a,b=root(component[2*j]),root(component[2*j+1])
        ref.append(int(a!=b))
        if a!=b: parents[a]=b
    if len({root(j) for j in range(len(parts))})!=1: return None
    seq=[]
    p=0
    for _ in next_port:
        if p<2*count:
            j=p//2
            seq.append(j)
            p^=ref[j]
        p=next_port[p]
    assert p==0 and len(seq)==2*count
    pos=[[] for _ in keys]
    for i,j in enumerate(seq): pos[j].append(i)
    rows=[0]*count
    for i,(a,b) in enumerate(pos):
        for j in range(i):
            c,d=pos[j]
            if (a<c<b) != (a<d<b):
                rows[i]|=1<<j
                rows[j]|=1<<i
    return Reference(rows,[r^(k<0) for r,k in zip(ref,keys)],[abs(k) for k in keys])


def extensions(r):
    """List formal skew-matrix edges. The original interlace block is retained."""
    m=len(r.labels)
    groups=defaultdict(list)
    for i,k in enumerate(r.labels): groups[k].append(i)
    extra, singles, n=[],[],m
    for loc in groups.values():
        if len(loc)==1:
            singles+=loc
        elif len(loc)==2:
            i,j=loc
            if r.offset[i]==r.offset[j]:
                extra.append((i,j))
            else:
                extra.extend([(n,i),(n,j)])
                n+=1
        else:
            raise ValueError("the two-use method requires at most two switches per control")
    if n%2:
        singles.append(n)
        n+=1
    extra.extend((i,j) for k,i in enumerate(singles) for j in singles[:k])
    return n,extra


def nonsingular(rows, subset=None):
    cols=range(len(rows)) if subset is None else subset
    work=[rows[i] for i in cols]
    for k,i in enumerate(cols):
        pivot=next((j for j in range(k,len(work)) if work[j]>>i&1),None)
        if pivot is None: return False
        work[k],work[pivot]=work[pivot],work[k]
        for j in range(k+1,len(work)):
            if work[j]>>i&1: work[j]^=work[k]
    return True


def winning_parity(r):
    if r is None: return 0
    n,extra=extensions(r)
    rows=r.interlace+[0]*(n-len(r.interlace))
    for i,j in extra:
        rows[i]^=1<<j
        rows[j]^=1<<i
    return int(nonsingular(rows))


def poly_mod(a,b):
    while a.bit_length()>=b.bit_length():
        a^=b<<(a.bit_length()-b.bit_length())
    return a


def gf_mul(a,b,mod):
    value=0
    while b:
        if b&1: value^=a
        b>>=1
        a<<=1
        if a.bit_length()==mod.bit_length(): a^=mod
    return value


def irreducible(mod):
    d=mod.bit_length()-1
    x=2
    for i in range(1,d//2+1):
        x=gf_mul(x,x,mod)
        a,b=mod,x^2
        while b: a,b=b,poly_mod(a,b)
        if a!=1: return False
    return True


def field_for(n):
    degree=max(8,(2*n+1).bit_length())
    mod=next(p for p in range((1<<degree)+1,1<<(degree+1),2) if irreducible(p))
    return 1<<degree,mod


def inverse(a,size,mod):
    res=1
    exp=size-2
    while exp:
        if exp&1: res=gf_mul(res,a,mod)
        a=gf_mul(a,a,mod); exp>>=1
    return res


def sampled_exists(r, trials=4, rng=None):
    """One-sided error at most (1/4)^trials; a positive answer is conclusive."""
    if trials<1: raise ValueError("at least one trial required")
    if r is None: return False
    n,extra=extensions(r)
    if not n: return True
    rng=SystemRandom() if rng is None else rng
    size,mod=field_for(n)
    for _ in range(trials):
        mat=[[0]*n for _ in range(n)]
        for i,row in enumerate(r.interlace):
            for j in range(len(r.labels)):
                mat[i][j]=(row>>j)&1
        for i,j in extra:
            z=rng.randrange(size)
            mat[i][j]^=z; mat[j][i]^=z
        for i in range(n):
            pivot=next((j for j in range(i,n) if mat[j][i]),None)
            if pivot is None: break
            mat[i],mat[pivot]=mat[pivot],mat[i]
            scale=inverse(mat[i][i],size,mod)
            for j in range(i+1,n):
                a=gf_mul(mat[j][i],scale,mod)
                if a:
                    for k in range(i,n): mat[j][k]^=gf_mul(a,mat[i][k],mod)
        else:
            return True
    return False


def solve(width,gates):
    """Exact search in 2**k polynomial time; k counts controls used at least three times."""
    counts=Counter(abs(k) for k,_,_ in gates if k)
    heavy=[k for k,n in counts.items() if n>=3]
    for word in product((0,1),repeat=len(heavy)):
        fixed=dict(zip(heavy,word))
        residual=[]
        for k,a,b in gates:
            if abs(k) not in fixed:
                residual.append((k,a,b))
            elif fixed[abs(k)]==(k>0):
                residual.append((0,a,b))
        small=two_use_witness(reference(width,residual))
        if small is not None:
            witness={**fixed,**small}
            tokens=list(range(width))
            for k,a,b in gates:
                if not k or witness[abs(k)]==(k>0):
                    tokens[a],tokens[b]=tokens[b],tokens[a]
            if len(cycles(tokens))!=1:
                raise ArithmeticError("returned setting failed its tour check")
            return witness
    return None


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode",choices=["compile3","one","two","solve"])
    p.add_argument("input")
    p.add_argument("--output",help="required for compile3; writes a JSON routing instance")
    p.add_argument("--trials",type=int,default=0,help="also run this many independent finite-field trials")
    a=p.parse_args()
    if a.mode=="compile3":
        if not a.output: p.error("--output is required for compile3")
        w,g,groups=compile_three(*read_dimacs(a.input))
        Path(a.output).write_text(json.dumps({"width":w,"gates":g,"variable_copies":groups})+"\n")
    else:
        g=json.loads(Path(a.input).read_text())
        if a.mode=="one":
            print("Exact winning assignments:",one_use_count(g["width"],g["gates"]))
            raise SystemExit(0)
        if a.mode=="solve":
            setting=solve(g["width"],g["gates"])
            print("Unsatisfiable" if setting is None else json.dumps({"winning_setting":setting},sort_keys=True))
            raise SystemExit(0)
        counts=Counter(abs(k) for k,_,_ in g["gates"] if k)
        if max(counts.values(),default=0)>2: p.error("a control occurs more than twice")
        r=reference(g["width"],g["gates"])
        print("Exact parity of winning assignments:",winning_parity(r))
        answer=two_use_witness(r)
        print("Existence:", "no" if answer is None else "yes")
        if answer is not None: print("Winning setting:",json.dumps(answer,sort_keys=True))
        if a.trials:
            print("Independent randomized check:", "yes" if sampled_exists(r,a.trials) else "no witness detected")
