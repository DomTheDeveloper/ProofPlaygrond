"""Single unweighted cubic bipartite graph with an exact power-of-two count factor."""
import argparse
import json
from pathlib import Path
from cycle_bits import adjacency, parts, zero_graph


def backbone(g):
    adj=adjacency(g); sides=parts(adj); ed=g["edges"]; n=g["vertices"]
    if any(len(ns)>3 for ns in adj): raise ValueError("maximum degree three required")
    if sides is None or not adj or any(len(ns)<2 for ns in adj) or 2*sum(sides.values())!=n: return None
    probe=next((ns[0][1] for ns in adj if len(ns)==2),None)
    if probe is None: raise ValueError("a source vertex of degree two is required")
    if parts(adj,probe) is None: return None
    u,v=ed[probe]
    # Subdivide the forced edge four times; reopen it at a new interior edge.
    h=[pair for i,pair in enumerate(ed) if i!=probe]+[(u,n),(n,n+1),(n+2,n+3),(n+3,v)]
    a,b=n+1,n+2
    sides.update({n:1-sides[u],n+1:sides[u],n+2:1-sides[u],n+3:sides[u]})
    low=[i for i,x in enumerate(adj) if len(x)==2]+list(range(n,n+4))
    low0=[i for i in low if sides[i]==0];low1=[i for i in low if sides[i]==1]
    assert len(low0)==len(low1)
    order=[v for pair in zip(low0,low1) for v in pair]
    ref={v:n+4+j for j,v in enumerate(order)}
    ed=h+[(v,ref[v]) for v in order]
    ring=list(zip(order,order[1:]+order[:1]))
    cut=next((v,w) for v,w in ring if a not in (v,w) and b not in (v,w))
    marked=[]
    for v,w in ring:
        if (v,w)!=cut:
            marked.append(len(ed));ed.append((ref[v],ref[w]))
    same={sides[v]:ref[v] for v in cut}
    for x in (a,b):
        marked.append(len(ed));ed.append((x,same[sides[x]]))
    return {"vertices":n+4+len(order),"edges":ed},marked


def fragment_edges():
    es=[(t+i,t+j) for t in (0,6) for i in range(3) for j in (3,4,5) if (i,j)!=(0,3)]
    es.extend([(0,9),(6,3)])
    return [(a,b) for a,b in es if a and b]


def force(g, marked):
    edges=[list(e) for e in g["edges"]]; adj=[{e for _,e in row} for row in adjacency(g)]
    inside=fragment_edges()
    for target in marked:
        old=edges[target][0]
        other=sorted(adj[old]-{target})
        links=[target,*other]
        assert len(links)==3
        fresh=len(adj)
        labels={1:old,**{v:fresh+v-2 for v in range(2,12)}}
        adj[old].clear()
        adj.extend(set() for _ in range(10))
        for eid,port in zip(links,[9,4,5]):
            k=edges[eid].index(old)
            edges[eid][k]=labels[port]
            adj[labels[port]].add(eid)
        for v,w in inside:
            u,y=labels[v],labels[w]
            adj[u].add(len(edges));adj[y].add(len(edges));edges.append([u,y])
    return {"vertices":len(adj),"edges":edges,"shift":3*len(marked)}


def convert(g):
    b=backbone(g)
    return zero_graph() if b is None else force(*b)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("source");p.add_argument("output");a=p.parse_args()
    Path(a.output).write_text(json.dumps(convert(json.loads(Path(a.source).read_text())))+"\n")
