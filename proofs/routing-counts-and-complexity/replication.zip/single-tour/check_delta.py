"""Compare the deterministic augmenting-path solver to enumeration, also off routing inputs."""
from itertools import combinations
import random
from delta_parity import complete_pairs, positions
from routing import nonsingular


def check(a,f,unions):
    ans=complete_pairs(a,f)
    possible=any(nonsingular(a,list(positions(f^s))) for s in unions)
    assert possible==(ans is not None)
    if ans is not None:
        assert ans in unions and nonsingular(a,list(positions(f^ans)))


def paired_subsets(n):
    return [sum(3<<(2*j) for j in positions(t)) for t in range(1<<(n//2))]


if __name__=="__main__":
    count=0
    for n in (2,4):
        edges=list(combinations(range(n),2))
        unions=paired_subsets(n)
        for mask in range(1<<len(edges)):
            a=[0]*n
            for j,(x,y) in enumerate(edges):
                if mask>>j&1: a[x]|=1<<y;a[y]|=1<<x
            for f in range(1<<n):
                check(a,f,unions);count+=1
    print("Exhaustive matrix/twist checks through order four:",count)
    rng=random.Random(923131); count=0
    for n in (6,8,10,12,14,16,18):
        unions=paired_subsets(n)
        for j in range(450):
            a=[0]*n;density=rng.choice((.09,.22,.45,.74))
            for x,y in combinations(range(n),2):
                if rng.random()<density: a[x]|=1<<y;a[y]|=1<<x
            check(a,rng.randrange(1<<n),unions);count+=1
    print("Independent matrix/twist comparisons through order eighteen:",count)
