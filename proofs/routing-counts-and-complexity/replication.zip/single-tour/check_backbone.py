from itertools import combinations
from check_bits import eligible, masks, num_paths, raw_hc, validate
from regularize_any import backbone, convert, fragment_edges, zero_graph


def count_marked(g,chosen):
    n=g["vertices"];ed=g["edges"]; req={tuple(sorted(ed[i])) for i in chosen}
    aa=masks(g);total=0
    # Enumerate raw cycles and inspect the full marked edge set independently.
    def walk(seq,seen):
        nonlocal total
        x=seq[-1]
        if len(seq)==n:
            if (aa[x]&1) and seq[1]<x:
                pairs={tuple(sorted((i,j))) for i,j in zip(seq,seq[1:]+[0])}
                total+=req<=pairs
            return
        opts=aa[x]&~seen
        while opts:
            b=opts&-opts;opts^=b
            walk(seq+[b.bit_length()-1],seen|b)
    walk([0],1)
    return total


if __name__=="__main__":
    f={"vertices":11,"edges":[(i-1,j-1) for i,j in fragment_edges()]}
    m=masks(f);ports=[8,3,4]
    vals=[num_paths(m,i,j,(1<<11)-1^(1<<i)) for i,j in combinations(ports,2)]
    assert vals==[8,8,0]
    z=zero_graph();validate(z);assert raw_hc(z)==0
    pool=[(i,3+j) for i in range(3) for j in range(3)]
    n=0
    for sel in range(512):
        src={"vertices":6,"edges":[e for i,e in enumerate(pool) if sel>>i&1]}
        if not eligible(src): continue
        b=backbone(src)
        if b:
            g,forced=b;validate(g);validate(convert(src))
            assert count_marked(g,forced)==raw_hc(src)
            n+=1
    print("Three-port counts",vals,"scaffold/source comparisons",n,"explicit zero graph tours",raw_hc(z))
