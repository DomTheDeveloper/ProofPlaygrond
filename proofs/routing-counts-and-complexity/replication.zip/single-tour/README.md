# Single-tour routing and Hamiltonian count bits

The manuscript `Single_Tour_Routing.tex` gives the proofs. The scripts use Python 3.10 or later and its standard library.

## Reproduce the results

Run the following from this directory.

```sh
python3 run_checks.py
```

The saved output is in `CHECK_RESULTS.txt`. Whole-graph exhaustive counting is used for small examples. Large CNF outputs are checked for their structure and their supplied Hamiltonian tour. The mathematical proofs justify the reductions for arbitrary inputs.

## Routing and Sudoku

A gate is a triple `[v,a,b]`. The two zero-based lane numbers are `a,b`. Positive `v` swaps the lanes when control `v` is on, negative `v` swaps when it is off, and zero always swaps. Each occurring control represents one independent bit. Output lanes connect to inputs with the same index. An accepting assignment makes the resulting permutation a single cycle.

```sh
python3 routing.py one examples/one-use.json
python3 routing.py two examples/two-use.json
python3 routing.py solve examples/two-use.json
python3 routing.py compile3 examples/sample.cnf --output three.json
python3 exact_cover.py --sudoku examples/sudoku.json --output sudoku-routing.json
```

The one-use command computes the exact count by an integer determinant. The two-use command computes parity exactly and uses deterministic binary linear delta-matroid parity for existence. It returns a winning control assignment or a definitive no answer. The solver in `delta_parity.py` follows the augmenting-path argument of Geelen, Iwata and Murota (2003). `--trials 8` adds an independent finite-field identity test with one-sided error below 1/65,536 for eight trials. The general solve command branches on bits used three times or more and uses the two-use solver on each residual program. It checks each returned witness by tracing the actual permutation.

The exact-cover construction works directly on incidence lists. A source procedure in `cnf_to_source.py` constructs a permutation program for a DIMACS CNF. The `compile3` command then limits each new control to three occurrences. The `variable_copies` field identifies the copies of each source variable. The independent hard-side proof in the manuscript uses Exact Cover by 3-Sets.

## Cubic bipartite graphs

```sh
python3 cycle_bits.py parity examples/sample.cnf parity-graph.json --witness
python3 cycle_bits.py exact examples/sample.cnf exact-graph.json
python3 cycle_bits.py decision examples/sample.cnf decision-graph.json
python3 regularize_any.py examples/square.json regularized-square.json
```

A graph JSON gives an integer `vertices` and an `edges` list of pairs of zero-based vertex IDs. An optional `hamiltonian_cycle` lists edge indices. Count each undirected cycle once. The `parity` graph has cycle count congruent to twice the model parity modulo four. Using `--witness` plants two known models and preserves parity. In `exact` mode, shifting the cycle count right by `shift` gives the number of models. In `decision` mode, bit `decision_bit` equals one precisely when the input is satisfiable. Its graph comes with a tour. Constructing these graphs takes polynomial time. Reading arbitrary target count bits remains computationally hard.

The specialized regularizer in `cycle_bits.py` handles the paired degree-two vertices of the bundled source compiler. The independent `regularize_any.py` implements the scaffold proof for bipartite sources of maximum degree three with a degree-two vertex, including easy zero cases. The generic command outputs the count shift. The diagram, definitions, algebra and reduction details are in the manuscript.
