"""Repeat every reported verification with Python 3.10+ and no third-party dependencies."""
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parent
for test in ("check_routing.py","check_delta.py","exact_cover.py","check_bits.py","check_backbone.py"):
    print(test,flush=True)
    subprocess.run([sys.executable,str(root/test)],cwd=root,check=True)
