"""Undirected graphs. A Hamiltonian cycle is counted once as a set of edges."""
import argparse
import json
from pathlib import Path
from cnf_to_source import compile_cnf, read_dimacs, two_planted_models


def adjacency(g):
    n = g["vertices"]
    adj = [[] for _ in range(n)]
    seen = set()
    for e, (u, v) in enumerate(g["edges"]):
        pair = tuple(sorted((u, v)))
        if min(pair) < 0 or max(pair) >= n or u == v or pair in seen:
            raise ValueError("expected a simple graph on the declared vertex set")
        seen.add(pair)
        adj[u].append((v, e))
        adj[v].append((u, e))
    return adj


def parts(adj, skip=-1):
    sides = {}
    for root in range(len(adj)):
        if root in sides:
            continue
        if sides:
            return None
        sides[root] = 0
        queue = [root]
        for x in queue:
            for y, e in adj[x]:
                if e == skip:
                    continue
                if y not in sides:
                    sides[y] = 1 - sides[x]
                    queue.append(y)
                elif sides[y] == sides[x]:
                    raise ValueError("expected a bipartite graph")
    return sides


def zero_graph():
    ed=[]
    for k in range(3):
        t=6*k
        ed.extend((t+i,t+j) for i in range(3) for j in range(3,6) if (i,j)!=(0,3))
        ed.extend([(18,t),(19,t+3)])
    return {"vertices":20,"edges":ed,"shift":0}


def prism(k):
    return {"vertices": 2*k, "edges": [(i+t, (i+1)%k+t) for t in (0,k) for i in range(k)]
            + [(i, i+k) for i in range(k)]}


def fragment(g, e):
    """Four terminals in order s0,t0,s1,t1. Take u to be the degree-two endpoint."""
    n, ed = g["vertices"], g["edges"]
    adj = adjacency(g)
    u,v = ed[e]
    if len(adj[u]) != 2:
        u,v = v,u
    if len(adj[u]) != 2 or any(len(a) not in (2,3) for a in adj):
        raise ValueError("expected a forced edge at a degree-two vertex")
    retained = [(a,b) for j,(a,b) in enumerate(ed) if j != e]
    retained.append((v,n))
    size = n+1
    edges = retained + [(a+size,b+size) for a,b in retained]
    # The two leaves and every ordinary degree-two vertex have one rung.
    edges.extend((x,x+size) for x in range(size) if x==n or len(adj[x])==2)
    return {"vertices":2*size, "edges":edges}, [u,n,u+size,n+size], retained


def surround(b, ports):
    """Replace (L0,R0) and (L1,R1) of K3,3 by identically labeled fragments."""
    size = b["vertices"]
    ed = list(b["edges"])
    ed += [(u+size,v+size) for u,v in b["edges"]]
    # At Li, label the outside edge to R(1-i) by 0 and to R2 by 1.
    # At Ri use label 2 for the outside edge to L(1-i), and 3 for the edge to L2.
    left, right = 2*size, 2*size+1
    outside = [
        (ports[0],size+ports[2]), (size+ports[0],ports[2]),
        (ports[1],right), (size+ports[1],right),
        (left,ports[3]), (left,size+ports[3]), (left,right)]
    return {"vertices": 2*size+2, "edges":ed+outside}


def second_bit(g, probe=None):
    adj = adjacency(g)
    sides = parts(adj)
    if any(len(a)>3 for a in adj):
        raise ValueError("maximum degree three required")
    available = [e for a in adj if len(a)==2 for _,e in a]
    if not adj or sides is None or any(len(a)<2 for a in adj):
        return prism(6)
    if not available:
        raise ValueError("source must have a degree-two vertex")
    e = available[0] if probe is None else probe
    if e not in available:
        raise ValueError("the probe must touch a degree-two vertex")
    if parts(adj,e) is None:
        return prism(6)
    b, ports, retained = fragment(g,e)
    result = surround(b,ports)
    if "hamiltonian_cycle" in g:
        selected = set(g["hamiltonian_cycle"])
        if e not in selected:
            raise ValueError("source witness omits its forced edge")
        path = [j-(j>e) for j in sorted(selected) if j!=e]
        path.append(len(retained)-1)
        m = len(b["edges"])
        result["hamiltonian_cycle"] = [block*m + sheet*len(retained)+j
            for block in (0,1) for sheet in (0,1) for j in path] + list(range(2*m,2*m+6))
    return result


def pad_decision(n, clauses):
    """Output has (2**n-1)+#F models. Bit n tests satisfiability."""
    sel=n+1
    return sel, [(-sel,*c) for c in clauses] + [(sel,*range(1,n+1))]


def exact_regularize(source):
    """Replace each disjoint pair of degree-two wire vertices by K3,3 minus one edge."""
    ed = source["edges"]
    adj = adjacency(source)
    if parts(adj) is None:
        return zero_graph()
    low = {v for v,a in enumerate(adj) if len(a)==2}
    high = {v for v,a in enumerate(adj) if len(a)==3}
    if len(low)+len(high)!=len(adj) or not high:
        raise ValueError("expected a nonempty degree-three switch core")
    names={v:i for i,v in enumerate(sorted(high))}
    pairs=[]
    for u in sorted(low):
        neighbors=[v for v,_ in adj[u] if v in low]
        if len(neighbors)!=1:
            raise ValueError("degree-two vertices must form an induced matching")
        if u<neighbors[0]:
            pairs.append((u,neighbors[0]))
    selected = set(source.get("hamiltonian_cycle",[]))
    edges, lifted = [], []
    def add(u,v,chosen):
        if chosen:
            lifted.append(len(edges))
        edges.append((u,v))
    for j,(u,v) in enumerate(ed):
        if u in high and v in high:
            add(names[u],names[v],j in selected)
    # The path 0,4,1,5,2,3 traverses K3,3 minus (0,3).
    tour={tuple(sorted(pair)) for pair in zip([0,4,1,5,2],[4,1,5,2,3])}
    for k,(u,v) in enumerate(pairs):
        x=next(y for y,_ in adj[u] if y in high)
        y=next(z for z,_ in adj[v] if z in high)
        base=len(high)+6*k
        add(names[x],base,bool(selected))
        add(base+3,names[y],bool(selected))
        for i in range(3):
            for j in range(3,6):
                if (i,j)!=(0,3):
                    add(base+i,base+j,bool(selected) and (i,j) in tour)
    g={"vertices":len(high)+6*len(pairs),"edges":edges,"shift":2*len(pairs)}
    if selected:
        g["hamiltonian_cycle"]=lifted
    return g


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=["parity","exact","decision"])
    parser.add_argument("formula",help="DIMACS CNF with at least one variable")
    parser.add_argument("output",help="output graph JSON")
    parser.add_argument("--witness",action="store_true",help="in parity mode plant two known models")
    args=parser.parse_args()
    n, clauses=read_dimacs(args.formula)
    if args.witness and args.mode!="parity":
        parser.error("--witness is only needed in parity mode")
    if args.mode=="decision":
        v,c=pad_decision(n,clauses)
        g=exact_regularize(compile_cnf(v,c,witness_bits=1))
        g["decision_bit"]=g["shift"]+n
    elif args.mode=="exact":
        g=exact_regularize(compile_cnf(n,clauses))
    else:
        if args.witness:
            n,clauses=two_planted_models(n,clauses)
        g=second_bit(compile_cnf(n,clauses,witness_bits=0 if args.witness else None))
    Path(args.output).write_text(json.dumps(g,separators=(",",":"))+"\n")

if __name__=="__main__":
    main()
