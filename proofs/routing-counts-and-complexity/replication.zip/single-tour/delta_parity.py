"""Deterministic linear delta-matroid parity over GF(2).

Direct implementation of Geelen, Iwata & Murota (2003), Section 5.
Vertices 2i,2i+1 form a pair. Matrices are alternating rows as bitsets.
The search explicitly stores augmenting paths and maximal blossoms for clarity.
"""
from collections import defaultdict, deque


def positions(mask):
    while mask:
        bit=mask&-mask
        yield bit.bit_length()-1
        mask^=bit


def principal_pivot(rows, flip):
    n=len(rows)
    universe=(1<<n)-1
    keep=universe^flip
    # Swap columns of [I | A] indexed by flip with their corresponding mates.
    # Gaussian reduction of the left block gives the new fundamental matrix.
    joined=[]
    for i,row in enumerate(rows):
        unit=1<<i
        left=(unit&keep)|(row&flip)
        right=(unit&flip)|(row&keep)
        joined.append(left|(right<<n))
    for i in range(n):
        piv=next((j for j in range(i,n) if (joined[j]>>i)&1),None)
        if piv is None: raise ArithmeticError("augmenting set has singular principal block")
        joined[i],joined[piv]=joined[piv],joined[i]
        for j in range(n):
            if j!=i and (joined[j]>>i)&1: joined[j]^=joined[i]
    return [r>>n for r in joined]


def augmenting_set(original, feasible):
    n=len(original)
    a=original[:]
    flat=list(range(n))
    path={}
    owner={}
    discovery={}
    queue=deque()
    scanned=[]
    for i in range(0,n,2):
        if ((feasible>>i)&3) in (1,2):
            pair=frozenset((i,i+1))
            for x in pair:
                owner[x]=pair
                path[x]=(x,)
                queue.append(x)

    def transform(p,q,b):
        if not ((a[p]>>b)&1 and (a[q]>>b)&1):
            raise ArithmeticError("a transform must have two nonzero bud entries")
        t=len(a)
        row=a[p]^a[q]
        for i in positions(row): a[i]|=1<<t
        a.append(row)
        flat.append(flat[p])
        return t

    def set_owner(members):
        blob=frozenset(members)
        for x in blob: owner[x]=blob

    def tail(seq,x):
        return seq[seq.index(x)+1:]

    def shrink(v,u):
        pv,pu=path[v],path[u]
        b=next(x for x in reversed(pv) if any(y in owner[x] for y in pu))
        d=next(x for x in reversed(pu) if x in owner[b])
        tv,tu=tail(pv,b),tail(pu,d)
        tips=set()
        if d==b:
            p,q=tv[0],tu[0]
            tips={p,q}
            t=transform(p,q,b)
            members={t}
        else:
            members=set(owner[b])
        involved=(set(tv)|set(tu))-tips
        for x in involved:
            if x in path: members.update(owner[x])
        hidden=sorted((x for x in involved if x not in path),
                      key=lambda x:(-discovery.get(x,-1),x))
        for x in hidden:
            if x in tu:
                path[x]=pv+tuple(reversed(tail(pu,x)))+(x,)
            else:
                path[x]=pu+tuple(reversed(tail(pv,x)))+(x,)
            queue.append(x)
        if d==b:
            path[t]=pu+tuple(reversed(tail(pv,p)))+(t,)
            queue.append(t)
        set_owner(members)

    while queue:
        v=queue.popleft()
        for u in scanned:
            if (a[v]>>u)&1 and u not in owner[v]:
                if path[v][0]//2!=path[u][0]//2:
                    chain=path[v]+tuple(reversed(path[u]))
                    indices=[flat[x] for x in chain]
                    if len(indices)!=len(set(indices)):
                        raise ArithmeticError("an augmenting path repeats an original index")
                    return sum(1<<x for x in indices)
                shrink(v,u)
        # Every transform already has a label. Only original vertices can be fresh.
        for u in positions(a[v]&((1<<n)-1)):
            if u in owner: continue
            mate=u^1
            discovery[u]=len(scanned)
            if (a[v]>>mate)&1:
                t=transform(mate,u,v)
                path[t]=path[v]+(u,t)
                set_owner((u,mate,t))
                queue.append(t)
            else:
                path[mate]=path[v]+(u,mate)
                set_owner((u,mate))
                queue.append(mate)
        scanned.append(v)
    return 0


def complete_pairs(rows, feasible):
    """Return a feasible union of whole pairs, or None if none exists."""
    n=len(rows)
    a=list(rows)
    while True:
        broken=sum(((feasible>>i)&3) in (1,2) for i in range(0,n,2))
        if not broken: return feasible
        if broken&1: return None
        step=augmenting_set(a,feasible)
        if not step: return None
        a=principal_pivot(a,step)
        feasible^=step
        if sum(((feasible>>i)&3) in (1,2) for i in range(0,n,2))!=broken-2:
            raise ArithmeticError("augmenting did not repair two broken pairs")


def two_use_witness(r):
    """Return actual control values of one single-tour setting, or None."""
    if r is None: return None
    m=len(r.labels)
    groups=defaultdict(list)
    for i,k in enumerate(r.labels): groups[k].append(i)
    b=[0]*m
    twist=0
    singletons=[]
    for loc in groups.values():
        if len(loc)==1: singletons+=loc;continue
        if len(loc)!=2: raise ValueError("a control occurs more than twice")
        i,j=loc
        b[i]=1<<j; b[j]=1<<i
        if r.offset[i]!=r.offset[j]: twist|=1<<j
    if twist.bit_count()%2:
        if not singletons: return None
        twist^=1<<singletons[0]
    active=sum(1<<i for i in singletons)
    for i in singletons: b[i]=active^(1<<i)
    rows=[0]*(2*m)
    for i in range(m):
        rows[2*i]=sum(1<<(2*j) for j in positions(r.interlace[i]))
        rows[2*i+1]=sum(1<<(2*j+1) for j in positions(b[i]))
    initial=sum(1<<(2*j+1) for j in positions(twist))
    full=complete_pairs(rows,initial)
    if full is None: return None
    return {k:((full>>(2*loc[0]))&1)^r.offset[loc[0]] for k,loc in groups.items()}
