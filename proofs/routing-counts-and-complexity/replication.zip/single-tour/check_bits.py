"""Independent small undirected path/edge-set enumerations. Standard Python only."""
from collections import Counter
from itertools import combinations, product
import random
from cycle_bits import (adjacency, exact_regularize, fragment, pad_decision, parts, prism,
                        second_bit, surround)
from cnf_to_source import compile_cnf, two_planted_models


def masks(g):
    return [sum(1<<v for v,_ in ns) for ns in adjacency(g)]


def num_paths(adj, u, target, remaining):
    if u==target:
        return int(not remaining)
    count=0
    opts=adj[u]&remaining
    while opts:
        bit=opts&-opts
        opts^=bit
        count+=num_paths(adj,bit.bit_length()-1,target,remaining^bit)
    return count


def raw_hc(g):
    adj=masks(g)
    if len(adj)<3:
        return 0
    full=(1<<len(adj))-1
    # Fix two root edges in unordered order. After deleting the root count endpoint paths.
    neighbors=[i for i in range(1,len(adj)) if adj[0]>>i&1]
    return sum(num_paths(adj,i,j,full^1^(1<<i)) for i,j in combinations(neighbors,2))


STATES = [((i,j),) for i in (0,1) for j in (2,3)] + [
    ((0,2),(1,3)), ((0,3),(1,2)), ((0,1),(2,3))]


def signature(g,ts):
    adj=masks(g)
    full=(1<<len(adj))-1
    def disjoint(u,v,blocked,x,y,remaining):
        if u==v:
            return num_paths(adj,x,y,remaining^(1<<x))
        choices=adj[u]&remaining&~blocked
        count=0
        while choices:
            bit=choices&-choices
            choices^=bit
            count+=disjoint(bit.bit_length()-1,v,blocked,x,y,remaining^bit)
        return count
    out=[]
    for s in STATES:
        u,v=map(ts.__getitem__,s[0])
        if len(s)==1:
            out.append(num_paths(adj,u,v,full^(1<<u)))
        else:
            x,y=map(ts.__getitem__,s[1])
            out.append(disjoint(u,v,(1<<x)|(1<<y),x,y,full^(1<<u)))
    return out


def is_cycle(n, edges):
    if not n:
        return False
    adj=[[] for _ in range(n)]
    for u,v in edges:
        adj[u].append(v)
        adj[v].append(u)
    if any(len(a)!=2 for a in adj):
        return False
    seen={0}
    stack=[0]
    while stack:
        for v in adj[stack.pop()]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen)==n


def skeleton_coefficient(one,two):
    # Collapse every local path to a new edge between its chosen ports.
    # Unused ports disappear; remaining L2 and R2 must both have degree two.
    outer=[(0,6),(4,2),(1,9),(5,9),(8,3),(8,7),(8,9)]
    intern=list(one)+[(u+4,v+4) for u,v in two]
    ports={j for e in intern for j in e}
    vs=sorted(ports|{8,9})
    names={v:i for i,v in enumerate(vs)}
    total=0
    for mask in range(1<<len(outer)):
        ed=intern+[e for i,e in enumerate(outer) if mask>>i&1]
        if all(v in names for e in ed for v in e):
            total+=is_cycle(len(vs),[(names[u],names[v]) for u,v in ed])
    return total


MATRIX=[[skeleton_coefficient(a,b) for b in STATES] for a in STATES]
DIPOLE=[1,1,1,1,0,0,1]


def form(v):
    return sum(x*y*m for x,row in zip(v,MATRIX) for y,m in zip(v,row))


def caps(b,t):
    n=b["vertices"]
    ed=b["edges"]
    dip={"vertices":n+2,"edges":ed+[(s,n+int(i>=2)) for i,s in enumerate(t)]+[(n,n+1)]}
    square={"vertices":n+4,"edges":ed+[(s,n+i) for i,s in enumerate(t)]
            +[(n+i,n+j) for i in (0,1) for j in (2,3)]}
    return dip,square


def validate(g, witness=False):
    adj=adjacency(g)
    assert parts(adj) is not None and all(len(a)==3 for a in adj)
    if witness:
        ed=[g["edges"][i] for i in g["hamiltonian_cycle"]]
        assert len(set(g["hamiltonian_cycle"]))==len(ed) and is_cycle(g["vertices"],ed)


def test_graph(g, probes, stats, raw_limit, verbose=False):
    h=raw_hc(g)
    for e in probes:
        if parts(adjacency(g),e) is None:
            q=second_bit(g,e)
            assert raw_hc(q)==8 and h==0
            stats["bridge fallback"]+=1
            continue
        b,t,_=fragment(g,e)
        sig=signature(b,t)
        assert [x%2 for x in sig]==[h%2*x for x in DIPOLE]
        q=second_bit(g,e)
        validate(q)
        predicted=form(sig)
        assert predicted%4==2*(h%2)
        if q["vertices"]<=raw_limit:
            actual=raw_hc(q)
            assert actual==predicted
            stats["whole target counts"]+=1
        if b["vertices"]<=24:
            d,s=caps(b,t)
            assert raw_hc(s)-raw_hc(d)==2*sig[-1]
            stats["cap identity counts"]+=1
        stats["boundary checks"]+=1
        stats["odd source" if h%2 else "even source"]+=1
        if verbose:
            print("source cycles",h,"signature",sig,"target",q["vertices"],"cycles",predicted)
            break


def eligible(g):
    a=adjacency(g)
    if any(len(x) not in (2,3) for x in a) or parts(a) is None:
        return []
    return [e for e,(u,v) in enumerate(g["edges"]) if min(len(a[u]),len(a[v]))==2]


def test_exact():
    pool=[(i,j) for i in range(3) for j in range(3,6)]
    stats=Counter()
    for width in (1,2,3):
        for wires in combinations(range(9),width):
            ed=[e for i,e in enumerate(pool) if i not in wires]
            for k,i in enumerate(wires):
                u,v=pool[i]; a=6+2*k
                ed.extend([(u,a),(a,a+1),(a+1,v)])
            src={"vertices":6+2*width,"edges":ed}
            reg=exact_regularize(src); validate(reg)
            assert raw_hc(reg)==(1<<reg["shift"])*raw_hc(src)
            stats["whole exact-regularization checks"]+=1
    assert raw_hc(prism(4))==6 and raw_hc(prism(6))==8
    return stats


def test_formula():
    stats=Counter()
    tests=[(1,[(1,)]),(1,[(1,),(-1,)]),(2,[]),(2,[()]),(3,[(1,2),(-2,3)])]
    rng=random.Random(241121)
    tests += [(3,[tuple(rng.choice((-3,-2,-1,1,2,3)) for _ in range(3)) for _ in range(k)])
              for k in range(1,11)]
    def models(n,cs):
        return sum(all(any(bool(x>>(abs(l)-1)&1)==(l>0) for l in c) for c in cs)
                   for x in range(1<<n))
    for n,cs in tests:
        h=models(n,cs)
        p,clauses=pad_decision(n,cs)
        assert models(p,clauses)==(1<<n)-1+h
        src=compile_cnf(p,clauses,witness_bits=1)
        g=exact_regularize(src);validate(g,True)
        k=g["shift"]+n
        assert ((models(p,clauses)<<g["shift"])>>k)&1==bool(h)
        p,clauses=two_planted_models(n,cs)
        src=compile_cnf(p,clauses,witness_bits=0)
        target=second_bit(src);validate(target,True)
        assert target["vertices"]==4*src["vertices"]+6
        stats["CNF construction/witness checks"]+=1
        stats["largest witnessed graph order"]=max(stats["largest witnessed graph order"],target["vertices"],g["vertices"])
    return stats


if __name__=="__main__":
    assert MATRIX==[list(c) for c in zip(*MATRIX)] and form(DIPOLE)==6
    print("K3,3 gluing matrix (four paths, P, Q, D)")
    for row in MATRIX: print(*row)
    pool=[(i,j) for i in range(3) for j in range(3,6)]
    stats=Counter()
    for mask in range(1<<len(pool)):
        g={"vertices":6,"edges":[e for j,e in enumerate(pool) if mask>>j&1]}
        es=eligible(g)
        if es: test_graph(g,es,stats,30)
    for cycle in (4,6,8,10):
        g={"vertices":cycle,"edges":[(i,(i+1)%cycle) for i in range(cycle)]}
        test_graph(g,[0],stats,46,True)
    rng=random.Random(231121)
    for k in (4,5,6):
        for _ in range(16):
            ed={(i,k+i) for i in range(k)}|{(i,k+((i+1)%k)) for i in range(k)}
            p=list(range(k));rng.shuffle(p)
            for i,v in enumerate(p):
                if rng.random()<0.8: ed.add((i,k+v))
            g={"vertices":2*k,"edges":sorted(ed)}
            es=eligible(g)
            if es: test_graph(g,[es[0]],stats,30)
    # Three internally disjoint even paths, and two squares joined by a bridge.
    for ed in [[(i,j) for i in (0,1) for j in (2,3,4)],
               [(0,1),(1,2),(2,3),(3,0),(3,4),(4,5),(5,6),(6,7),(7,4)]]:
        g={"vertices":max(max(e) for e in ed)+1,"edges":ed}
        test_graph(g,eligible(g),stats,32)
    print(dict(stats),flush=True)
    print(dict(test_exact()),flush=True)
    print(dict(test_formula()),flush=True)
