"""Construct a bipartite graph of degrees 2/3 with one Hamilton cycle per CNF model.

The primary proof uses published grid Hamiltonicity hardness. This optional
standalone CNF compiler implements the separate construction in Appendix A.
"""
import argparse
from dataclasses import dataclass
import json
from pathlib import Path


def read_dimacs(path):
    variables = count = None
    clauses, current = [], []
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("c"):
            continue
        if line.startswith("p"):
            fields = line.split()
            if len(fields) != 4 or fields[:2] != ["p", "cnf"] or variables is not None:
                raise ValueError("expected one 'p cnf VARIABLES CLAUSES' header")
            variables, count = map(int, fields[2:])
            continue
        if variables is None:
            raise ValueError("missing DIMACS header before clauses")
        for literal in map(int, line.split()):
            if literal:
                current.append(literal)
            else:
                clauses.append(tuple(current))
                current = []
    if variables is None or variables < 1 or current or count != len(clauses):
        raise ValueError("invalid header, clause count, or unterminated clause")
    return variables, clauses


def normalize(variables, clauses):
    if variables < 1:
        raise ValueError("the construction assumes at least one variable")
    normalized = []
    for clause in clauses:
        if any(not isinstance(lit, int) or not 1 <= abs(lit) <= variables for lit in clause):
            raise ValueError("literal outside the declared variable range")
        if clause:
            normalized.append(tuple(clause))
        else:
            normalized.extend(((1,), (-1,)))
    used = {abs(lit) for clause in normalized for lit in clause}
    normalized.extend((i, -i) for i in range(1, variables + 1) if i not in used)
    return normalized


@dataclass(frozen=True)
class Step:
    # literal = 0 denotes a fixed permutation. Every permutation is an involution.
    literal: int
    pairs: tuple


def program(clauses):
    """Build a permutation with one cycle on a model and three on a nonmodel."""
    forward = []
    for index, clause in enumerate(clauses, 1):
        guards = []
        for position, literal in enumerate(clause, 1):
            swaps = tuple(((group, 0, rail), (group, position, rail))
                          for group in (0, index) for rail in (0, 1))
            guards.append(Step(literal, swaps))
        middle = Step(0, tuple(((0, 0, rail), (index, 0, rail)) for rail in (0, 1)))
        forward.extend([*guards, middle, *reversed(guards)])
    widths = [max(map(len, clauses)), *map(len, clauses)]
    lanes = [(g, r, b) for g, width in enumerate(widths)
             for r in range(width + 1) for b in (0, 1)]
    h0, h1 = (0, 0, 0), (0, 0, 1)
    # T fixes h1 and cycles through every other lane. A final swap merges
    # the two conjugate cycles on a model and splits one on a nonmodel.
    circle = [lane for lane in lanes if lane != h1]
    central = [Step(0, ((circle[0], lane),)) for lane in circle[1:]]
    return lanes, [*forward, *central, *reversed(forward), Step(0, ((h0, h1),))]


def wire_program(variables, lanes, steps):
    """Splice unchanged lanes. Assign an input and output port to each touched lane."""
    # Before its first gate a lane carries its own symbolic boundary source.
    last = {lane: lane for lane in lanes}
    first_inputs = {}
    connections = []
    groups = [[] for _ in range(variables)]
    next_port = 0
    for step in steps:
        # A negative-literal involution is its fixed swap followed by the
        # same swap controlled on the positive variable.
        if step.literal <= 0:
            for a, b in step.pairs:
                last[a], last[b] = last[b], last[a]
        if step.literal == 0:
            continue
        transpositions = []
        for lane_a, lane_b in step.pairs:
            ports = []
            for lane in (lane_a, lane_b):
                port = next_port
                next_port += 1
                previous = last[lane]
                if isinstance(previous, tuple):
                    if previous in first_inputs:
                        raise ValueError("boundary source encountered twice")
                    first_inputs[previous] = port
                else:
                    connections.append((previous, port, None))
                last[lane] = port
                ports.append(port)
            transpositions.append(tuple(ports))
        groups[abs(step.literal) - 1].extend(transpositions)
    for lane in lanes:
        if lane not in first_inputs or not isinstance(last[lane], int):
            raise ValueError("a logical lane missed every controlled step")
        connections.append((last[lane], first_inputs[lane], lane))
    return groups, connections


def two_planted_models(variables, clauses):
    # selector zero fixes all original bits to zero and leaves 'free' arbitrary.
    # selector one activates F and fixes 'free' to zero.
    clean = normalize(variables, clauses)
    selector, free = variables+1, variables+2
    result = [(-selector, *c) for c in clean]
    result.extend((selector, -i) for i in range(1,variables+1))
    result.append((-selector, -free))
    return variables+2, result


def compile_cnf(variables, clauses, witness_bits=None):
    clean = normalize(variables, clauses)
    if witness_bits is not None:
        if not 0 <= witness_bits < (1 << variables) or not all(
                any(bool(witness_bits & (1 << (abs(lit)-1))) == (lit > 0) for lit in clause)
                for clause in clean):
            raise ValueError("requested assignment is not a model")
    lanes, steps = program(clean)
    groups, connections = wire_program(variables, lanes, steps)
    edges, wires, decoders = [], [], []
    inputs, outputs = {}, {}
    next_vertex = 0
    chosen = []
    for variable, swaps in enumerate(groups):
        order = []
        for i in range(0, len(swaps), 2):
            (a, b), (c, d) = swaps[i:i+2]
            order.extend((a, c, b, d))
        q = len(order)
        z = 2*q
        left = [next_vertex + 2*j for j in range(z+1)]
        right = [u+1 for u in left]
        next_vertex += 2*(z+1)
        # The straight edge at position zero is absent from the 2-factor for bit one.
        decoders.append(len(edges))
        straight = list(range(z+1))
        straight[0], straight[z] = z, 0
        for j in range(z+1):
            if witness_bits is not None:
                chosen.append(len(edges) + ((witness_bits >> variable) & 1))
            edges.append((left[j], right[straight[j]]))
            edges.append((left[j], right[z if j == z else (j+1) % z]))
        feedback = []
        for i, port in enumerate(order):
            inputs[port], outputs[port] = left[2*i], right[2*i]
            partner = 4*(i//4) + (i+2) % 4
            target = (partner-1) % q
            feedback.append((right[2*i+1], left[2*target+1]))
        # Exactly one of these two wires lies on a private cycle in each mode.
        # Interchange their destinations to insert that cycle into an external path.
        first_out, first_in = feedback[0]
        feedback[0] = (first_out, left[z])
        feedback.append((right[z], first_in))
        wires.extend(feedback)
    wires.extend((outputs[a], inputs[b]) for a, b, _ in connections)
    for a, b in wires:
        u, v = next_vertex, next_vertex+1
        next_vertex += 2
        if witness_bits is not None:
            chosen.extend(range(len(edges),len(edges)+3))
        edges.extend(((a, u), (u, v), (v, b)))
    result = {"vertices": next_vertex, "edges": edges, "variable_decoders": decoders}
    if witness_bits is not None:
        result["hamiltonian_cycle"] = chosen
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("formula", help="DIMACS CNF, at least one declared variable")
    p.add_argument("output", help="JSON input to reflection.py")
    p.add_argument("--plant", action="store_true",
                   help="add exactly two known models to preserve parity and emit a known Hamiltonian cycle")
    args = p.parse_args()
    n, cs = read_dimacs(args.formula)
    if args.plant:
        n, cs = two_planted_models(n, cs)
    result = compile_cnf(n, cs, witness_bits=0 if args.plant else None)
    Path(args.output).write_text(json.dumps(result, separators=(",", ":"))+"\n")


