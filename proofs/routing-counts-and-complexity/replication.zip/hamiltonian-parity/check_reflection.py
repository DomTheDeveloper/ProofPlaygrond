"""Compare the reductions with independent full enumeration on small raw graphs."""
from collections import Counter
from itertools import combinations
import random
from enumerate_graphs import edge_colorings, hamilton_cycles, reflected_fixed_cycles
from reflection import (bipartition, components, construct, even_example, grid, incidence,
                        prepare_grid_reduction, valid_coloring, witnesses)
from separating import separating_four


def check_one(h, probe, counts):
    n, ed = h["vertices"], h["edges"]
    g, k, q = construct(n, ed, probe)
    true_h = sum(1 for _ in hamilton_cycles(h))
    kh = list(hamilton_cycles(k))
    fixed = reflected_fixed_cycles(k, n, kh)
    two_z = sum(1 for _ in edge_colorings(g))
    four_z = sum(1 for _ in edge_colorings(q))
    kunlabeled = sum(1 for _ in edge_colorings(k, normalize=True))
    mask = sum(1 << e for e in g["pins"])
    gv = [s for s in hamilton_cycles(g)]
    through = sum(s & mask == mask for s in gv)
    assert fixed == true_h
    assert len(kh) % 2 == two_z % 2 == through % 2 == true_h % 2
    assert two_z == four_z == kunlabeled and len(gv) % 2 == 0
    a = incidence(n, ed)
    w = witnesses(g, k, q)
    assert bool(w) == bool(two_z)
    if len(components(a, [probe])[0]) == 1:
        assert w
        q_a = incidence(q["vertices"], q["edges"])
        assert len(components(q_a, q["pins"])[0]) == 2
        assert len({v for e in q["pins"] for v in q["edges"][e]}) == 8
        assert separating_four(q)[0] == "yes"
    for graph in (g,k,q):
        a = incidence(graph["vertices"], graph["edges"])
        assert all(len(b) == 3 for b in a) and len(components(a)[0]) == 1
    assert bipartition(incidence(2*n, [p for p in k["edges"] if max(p) < 2*n]))
    counts["graph/probe pairs"] += 1
    counts["odd"] += true_h % 2
    counts["even"] += 1 - true_h % 2
    counts["symmetric cycles"] += fixed
    counts["all capped cycles"] += len(kh)
    counts["separate source sheets after cutting probe"] += len(components(incidence(n, ed), [probe])[0]) > 1
    counts["max capped vertices"] = max(counts["max capped vertices"], k["vertices"])
    return true_h, len(kh), two_z, four_z, through


def check_family(h, totals):
    adj = incidence(h["vertices"], h["edges"])
    if (not adj or any(len(a) not in (2, 3) for a in adj) or
            len(components(adj)[0]) != 1 or all(len(a) == 3 for a in adj)):
        return
    totals["source graphs"] += 1
    for e, (u, v) in enumerate(h["edges"]):
        if min(len(adj[u]), len(adj[v])) == 2:
            check_one(h, e, totals)


def check_separators():
    def cubic(n, pairs):
        return {"vertices": 2*n, "edges": [(u,v+n) for u,v in pairs]}
    def k33_blocks(t):
        ed = [(3*k+i,3*k+j) for k in range(t) for i in range(3) for j in range(3) if i or j]
        ed.extend((3*k,3*((k+1)%t)) for k in range(t))
        return cubic(3*t, ed)
    graphs = [cubic(3, [(i,j) for i in range(3) for j in range(3)]),
              cubic(4, [(i,j) for i in range(4) for j in range(4) if i!=j]),
              k33_blocks(2), k33_blocks(3)]
    ans = Counter()
    for g in graphs:
        edges = g["edges"]
        adj = incidence(g["vertices"], edges)
        support = [[0,0,0] for _ in edges]
        for j, colors in enumerate(edge_colorings(g)):
            for i, c in enumerate(colors):
                support[i][c] |= (1 << j)
        for four in combinations(range(len(edges)), 4):
            blocks, labels = components(adj, four)
            if len(blocks) == 1:
                continue
            bond = (len(blocks) == 2 and all(labels[edges[e][0]] != labels[edges[e][1]] for e in four))
            disjoint = len({v for e in four for v in edges[e]}) == 8
            for red in combinations(four,2):
                pins = {e: int(e not in red) for e in four}
                expected = support[four[0]][pins[four[0]]]
                for e in four[1:]:
                    expected &= support[e][pins[e]]
                case = dict(g, pins=pins)
                status, witness = separating_four(case)
                assert (status == "yes") == bool(expected)
                if witness is not None:
                    assert valid_coloring(case,witness)
                ans["placements"] += 1
                ans[status] += 1
                ans["outside four-bonds"] += not bond
                ans["disjoint"] += disjoint
                ans["disjoint outside four-bonds"] += (disjoint and not bond)
                ans["three-plus components"] += len(blocks) >= 3
    return ans


def main():
    totals = Counter()
    points = [(x,y) for x in range(4) for y in range(4)]
    for mask in range(1, 1 << 16):
        if mask.bit_count() >= 4:
            check_family(grid([p for i,p in enumerate(points) if (mask >> i)&1]), totals)
    print("All eligible connected induced subgraphs of the 4 by 4 grid:", dict(totals), flush=True)
    other = Counter()
    pool = [(u, v+3) for u in range(3) for v in range(3)]
    for mask in range(1 << 9):
        check_family({"vertices": 6, "edges": [a for i,a in enumerate(pool) if mask >> i & 1]}, other)
    rng = random.Random(226041)
    for k in (4,5,6):
        for _ in range(8):
            # Start from an even cycle, then insert a deterministic-seed random matching.
            ed = {(i,k+i) for i in range(k)} | {(i,k+((i+1)%k)) for i in range(k)}
            p = list(range(k))
            rng.shuffle(p)
            for i,j in enumerate(p):
                if rng.random() < .8:
                    ed.add((i,k+j))
            check_family({"vertices": 2*k, "edges": sorted(ed)},other)
    print("Labeled 3 by 3 bipartite sources and seeded additional sources:", dict(other), flush=True)
    print("Separating-clue solver versus complete coloring enumeration:", dict(check_separators()), flush=True)
    examples = [("square", grid([(0,0),(0,1),(1,0),(1,1)])),
                ("two-square ladder", grid([(i,j) for i in range(3) for j in range(2)])),
                ("K3,3 minus one edge", {"vertices":6, "edges":pool[1:]}),
                ("three even paths", even_example())]
    for label, h in examples:
        a = incidence(h["vertices"],h["edges"])
        e = next(z[0][1] for z in a if len(z)==2)
        print(label, check_one(h,e,Counter()))
    for h in [grid([]), grid([(0,0),(1,0)]), grid([(0,0),(0,1),(1,0),(1,1),(5,0)])]:
        gs, used = prepare_grid_reduction(h)
        assert used and witnesses(*gs) is not None
        assert sum(1 for _ in hamilton_cycles(gs[1])) % 2 == 0


if __name__ == "__main__":
    main()
