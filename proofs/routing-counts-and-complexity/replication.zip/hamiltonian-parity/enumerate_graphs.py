"""Small-instance reference enumerators. They use only the graph and given colors."""
from reflection import incidence


def hamilton_cycles(graph):
    """Yield each undirected Hamiltonian cycle once as an edge bitmask."""
    n, edges = graph["vertices"], graph["edges"]
    if n < 3:
        return
    adj = incidence(n, edges)
    root = min(range(n), key=lambda u: len(adj[u]))
    all_used = (1 << n)-1

    def walk(u, seen, mask, first):
        if seen == all_used:
            if first < u:
                for v, e in adj[u]:
                    if v == root:
                        yield mask | (1 << e)
            return
        for v, e in adj[u]:
            if not (seen >> v) & 1:
                yield from walk(v, seen | (1 << v), mask | (1 << e), first)
    for first, e in adj[root]:
        yield from walk(first, (1 << root) | (1 << first), 1 << e, first)


def edge_colorings(graph, normalize=False):
    edges = graph["edges"]
    adj = incidence(graph["vertices"], edges)
    fixed = {int(e): c for e, c in graph.get("pins", {}).items()}
    if normalize:
        if fixed or len(adj[0]) != 3:
            raise ValueError("palette normalization requires an unpinned cubic vertex")
        fixed = {e: c for c, (_, e) in enumerate(adj[0])}
    colors = [-1] * len(edges)
    occupied = [0] * len(adj)
    for e, c in fixed.items():
        u, v = edges[e]
        bit = 1 << c
        if (occupied[u] | occupied[v]) & bit:
            return
        colors[e] = c
        occupied[u] |= bit
        occupied[v] |= bit

    def visit():
        chosen, opts = -1, 0
        for e, (u, v) in enumerate(edges):
            if colors[e] < 0:
                mask = 7 ^ (occupied[u] | occupied[v])
                if not mask:
                    return
                if chosen == -1 or mask.bit_count() < opts.bit_count():
                    chosen, opts = e, mask
                    if mask.bit_count() == 1:
                        break
        if chosen == -1:
            yield tuple(colors)
            return
        u, v = edges[chosen]
        while opts:
            bit = opts & -opts
            opts ^= bit
            colors[chosen] = bit.bit_length()-1
            occupied[u] ^= bit
            occupied[v] ^= bit
            yield from visit()
            occupied[u] ^= bit
            occupied[v] ^= bit
            colors[chosen] = -1
    yield from visit()


def reflected_fixed_cycles(graph, sheet_size, cycles):
    edges = graph["edges"]
    index = {tuple(sorted(edge)): i for i, edge in enumerate(edges)}
    def reflect(v):
        if v < sheet_size:
            return v + sheet_size
        if v < 2 * sheet_size:
            return v - sheet_size
        return v
    image = [index[tuple(sorted((reflect(u), reflect(v))))] for u, v in edges]
    fixed = 0
    for mask in cycles:
        redrawn = 0
        bits = mask
        while bits:
            low = bits & -bits
            redrawn |= 1 << image[low.bit_length()-1]
            bits ^= low
        fixed += redrawn == mask
    return fixed
