"""Run the optional unbounded cycle-index checks against the native Z3 library."""
import ctypes
import ctypes.util
from pathlib import Path

name = ctypes.util.find_library("z3")
if not name:
    raise SystemExit("Install libz3, or run z3 reflection_lemma.smt2 directly.")
lib = ctypes.CDLL(name)
pointer, string = ctypes.c_void_p, ctypes.c_char_p
for key, args, ret in (("Z3_mk_config", [], pointer), ("Z3_mk_context", [pointer], pointer),
                       ("Z3_del_config", [pointer], None), ("Z3_del_context", [pointer], None),
                       ("Z3_eval_smtlib2_string", [pointer, string], string)):
    fn = getattr(lib, key)
    fn.argtypes, fn.restype = args, ret
config = lib.Z3_mk_config()
ctx = lib.Z3_mk_context(config)
lib.Z3_del_config(config)
try:
    source = Path(__file__).with_name("reflection_lemma.smt2").read_bytes()
    out = lib.Z3_eval_smtlib2_string(ctx, source).decode().split()
finally:
    lib.Z3_del_context(ctx)
if out != ["unsat", "unsat"]:
    raise SystemExit("Unexpected solver output: " + str(out))
print("Reflection fixes exactly indices 0 and k:", out[0], "for the negation.")
print("No undirected edge is fixed setwise:", out[1], "for the negation.")
