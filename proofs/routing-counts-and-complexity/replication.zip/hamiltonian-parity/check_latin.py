"""Independently enumerate Latin squares row by row on small converted examples."""
from enumerate_graphs import edge_colorings
from latin import convert
from reflection import construct, even_example, grid, witnesses


def count_latin(puzzle):
    n = puzzle["order"]
    rows = puzzle["rows"]
    full = (1 << n)-1
    used = [sum(1 << r[j] for r in rows) for j in range(n)]
    clues = {(r,c): v for r,c,v in puzzle["givens_in_last_three_rows"]}

    def visit(r, j, row):
        if r == n:
            return 1
        if j == n:
            return visit(r+1, 0, 0)
        allowed = full & ~(used[j] | row)
        if (r,j) in clues:
            allowed &= 1 << clues[r,j]
        ways = 0
        while allowed:
            x = allowed & -allowed
            allowed ^= x
            used[j] ^= x
            ways += visit(r, j+1, row | x)
            used[j] ^= x
        return ways
    return visit(len(rows), 0, 0)


if __name__ == "__main__":
    tests = [grid([(x,y) for x in range(k) for y in range(2)]) for k in (2,3,4)]
    tests.extend([{"vertices": 6, "edges": [(i,3+j) for i in range(3) for j in range(3) if i or j]},
                  even_example()])
    for h in tests:
        g, k, q = construct(h["vertices"], h["edges"])
        cg, _, cq = witnesses(g,k,q)
        for case, colors in ((g,cg),(q,cq)):
            latin = convert(case,colors)
            z = count_latin(latin)
            assert z == sum(1 for _ in edge_colorings(case))
            print("Order",latin["order"],"extra givens",len(case["pins"]),"completions",z)
