"""Check the optional direct compiler by rebuilding every small input's spanning 2-factors."""
from collections import Counter
from itertools import combinations, product
import random

from cnf_to_source import compile_cnf, normalize, two_planted_models
from reflection import (bipartition, components, incidence, lift_cycle, prepare_grid_reduction,
                        valid_cycle, witnesses)


def factor_family(graph):
    n, edges = graph["vertices"], graph["edges"]
    adj = incidence(n, edges)
    bipartition(adj)
    forced = {e for a in adj if len(a) == 2 for _, e in a}
    optional = {e for e in range(len(edges)) if e not in forced}
    for a in adj:
        flags = [e in forced for _, e in a]
        if not ((len(a) == 2 and all(flags)) or (len(a) == 3 and sum(flags) == 1)):
            raise AssertionError("unexpected degree or forced-wire coverage")
    choices = []
    while optional:
        e = min(optional)
        start = edges[e][0]
        u, ring = start, []
        while e in optional:
            optional.remove(e)
            ring.append(e)
            a, b = edges[e]
            u = b if a == u else a
            possible = [f for _, f in adj[u] if f in optional]
            if not possible:
                break
            e = possible[0]
        assert u == start and len(ring) % 2 == 0
        choices.append((ring[::2], ring[1::2]))
    return forced, choices, adj


def check(n, clauses, stats, masks=None):
    graph = compile_cnf(n, clauses)
    forced, choices, adj = factor_family(graph)
    expected_n = 256 * sum(map(len, normalize(n, clauses))) + 4*n
    assert graph["vertices"] == expected_n and len(choices) == n
    assert all(sum(d in half for blocks in choices for half in blocks) == 1
               for d in graph["variable_decoders"])
    all_edges = set(range(len(graph["edges"])))
    lookup = {d: (i, side) for i, blocks in enumerate(choices) for side, half in enumerate(blocks)
              for d in half if d in graph["variable_decoders"]}
    if masks is None:
        masks = range(1 << n)
    for bits in masks:
        selected = set(forced)
        for j, d in enumerate(graph["variable_decoders"]):
            i, side = lookup[d]
            selected.update(choices[i][side ^ ((bits >> j) & 1)])
        assert all(sum(e in selected for _, e in a) == 2 for a in adj)
        count = len(components(adj, all_edges - selected)[0])
        satisfies = all(any(bool(bits & (1 << (abs(lit)-1))) == (lit > 0)
                            for lit in clause) for clause in clauses)
        assert count == (1 if satisfies else 3), (n, clauses, bits, count)
        stats["selections"] += 1
        stats["one cycle"] += satisfies
        stats["three cycles"] += not satisfies
    stats["formulas"] += 1
    stats["largest source"] = max(stats["largest source"], graph["vertices"])


def main():
    stats = Counter()
    clauses = [tuple((1 if b else -1)*(i+1) for i, b in enumerate(signs))
               for signs in product((0,1), repeat=3)]
    for k in range(9):
        for subset in combinations(clauses, k):
            check(3, list(subset), stats)
    for clause in product((-2, -1, 1, 2), repeat=3):
        check(2, [clause], stats)
    for n, cs in [(1, [(1,)]), (2, []), (2, [()]), (1, [(1,), (-1,)]),
                  (4, [(1,2,-1,3), (-1,4), (-2,)])]:
        check(n, cs, stats)
    rng = random.Random(22117)
    for _ in range(30):
        n = rng.randint(1,5)
        cs = [tuple(rng.choice((-1,1))*rng.randint(1,n) for _ in range(rng.randint(1,5)))
              for _ in range(rng.randint(1,5))]
        check(n, cs, stats)
    print("Exhaustive assignment checks on each tested formula:", dict(stats))
    n = 32
    cs = [(i,) for i in range(1,n+1)]
    large = Counter()
    check(n, cs, large, [0, (1 << n)-1, *((1 << n)-1 ^ (1 << j) for j in range(n))])
    print("Selected assignments on a larger formula:", dict(large))
    for n, cs in [(1, [(1,)]), (1, [(1,), (-1,)]), (2, [(1,-2)])]:
        g = compile_cnf(n, cs)
        graphs, fallback = prepare_grid_reduction(g)
        assert witnesses(*graphs) is not None
        print("Full graph/witness construction:", n, cs,
              [h["vertices"] for h in graphs], "easy zero replaced", fallback)
    def num_models(n, cs):
        return sum(all(any(bool(bits & (1 << (abs(l)-1))) == (l > 0) for l in clause)
                       for clause in cs) for bits in range(1 << n))
    for n, cs in [(1,[(1,)]), (1,[(1,),(-1,)]), (2,[]), (2,[()]), (3,[(1,-2)])]:
        m, padded = two_planted_models(n,cs)
        assert num_models(m,padded) == 2 + num_models(n,cs)
        for assignment in (0, 1 << (m-1)):
            h = compile_cnf(m,padded,witness_bits=assignment)
            gs, replaced = prepare_grid_reduction(h)
            assert not replaced and valid_cycle(h["vertices"],h["edges"],h["hamiltonian_cycle"])
            k = gs[1]
            lifted = lift_cycle(h,gs[0],k)
            assert valid_cycle(k["vertices"],k["edges"],lifted)
    print("Both planted models and their invariant Hamiltonian cycles verified on five formulas.")


if __name__ == "__main__":
    main()
