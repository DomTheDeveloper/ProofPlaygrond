"""Verify the nonlinear witness encoding and construct adversarial inputs for linear tests."""
from itertools import combinations
from math import comb
import random
from low_bits import subset_formula


def model_count(n, clauses):
    """Exact DPLL with unit propagation and free-variable multiplicities."""
    def solve(free, cs):
        while cs:
            if any(not c for c in cs):
                return 0
            lit = next((c[0] for c in cs if len(c) == 1), None)
            if lit is None:
                v = min(abs(x) for c in cs for x in c)
                return solve(free, cs+[(v,)]) + solve(free, cs+[(-v,)])
            free = free - {abs(lit)}
            cs = [tuple(x for x in c if x != -lit) for c in cs if lit not in c]
        return 1 << len(free)
    return solve(set(range(1,n+1)), list(clauses))


def prefix_formula(n, values):
    """Exactly the specified nonempty Boolean set, with no auxiliary variables."""
    strings = [format(a, f"0{n}b") for a in values]
    prefixes = {s[:i] for s in strings for i in range(n+1)}
    cs = []
    for s in sorted(prefixes):
        if len(s) == n:
            continue
        for bit in "01":
            child = s + bit
            if child not in prefixes:
                cs.append(tuple((i+1) if b == "0" else -(i+1) for i,b in enumerate(child)))
    return cs


def invisible_set(n, masks):
    # A linear dependence among the first t+1 columns tracks its exact support.
    t = len(masks)
    if t >= 1 << n:
        raise ValueError("the lower bound requires fewer tests than assignments")
    basis = {}
    for x in range(t+1):
        column = sum(((m>>x)&1) << i for i,m in enumerate(masks))
        support = 1 << x
        while column:
            top = column.bit_length()-1
            if top not in basis:
                basis[top] = column,support
                break
            a,b = basis[top]
            column ^= a
            support ^= b
        if not column:
            return {x for x in range(t+1) if (support>>x) & 1}
    raise AssertionError("missing a linear dependence")


def main():
    cases = 0
    for n in (1,2,3):
        for k in range((1 << n)+1):
            cs = [()] if not k else prefix_formula(n, range(k))
            for b in (1,2,3):
                m, enc = subset_formula(n,cs,b)
                ways = model_count(m,enc)
                assert ways == sum(comb(k,j) for j in range(1,min(k, (1 << b)-1)+1))
                assert bool(ways % 2) == bool(k % (1 << b))
                cases += 1
    rng = random.Random(36513)
    gaps = 0
    for n in range(1,7):
        for t in sorted({0,1,min(5,(1<<n)-1),(1<<n)-1}):
            for _ in range(5):
                masks = [rng.getrandbits(1<<n) for _ in range(t)]
                vals = invisible_set(n,masks)
                assert vals and len(vals) <= t+1
                assert all(sum((m>>x)&1 for x in vals)%2 == 0 for m in masks)
                cs = prefix_formula(n,vals)
                assert model_count(n,cs) == len(vals)
                for x in range(1 << n):
                    bits = format(x, f"0{n}b")
                    sat = all(any((bits[abs(l)-1] == "1") == (l>0) for l in c) for c in cs)
                    assert sat == (x in vals)
                gaps += 1
    print("Exact subset-formula counts and nondivisibility equivalences:", cases)
    print("Nonempty CNFs invisible to every chosen linear test:", gaps)
    families = 0
    for n, b in ((1,1),(2,1),(2,2),(2,3),(3,2),(3,3)):
        N, modulus = (1 << n), (1 << b)
        bound = (N+modulus-2)//(modulus-1)
        zero = []
        for mask in range(1 << N):
            invisible = sum(1 << s for s in range(1,1 << N)
                            if (mask & s).bit_count() % modulus == 0)
            zero.append(invisible)
        for t in range(bound):
            for tests in combinations(range(1 << N),t):
                survivors = zero[0]
                for test in tests:
                    survivors &= zero[test]
                assert survivors
                families += 1
        blocks = [sum(1 << j for j in range(i,min(i+modulus-1,N)))
                  for i in range(0,N,modulus-1)]
        assert len(blocks) == bound
        assert all(any((s & mask).bit_count() % modulus for mask in blocks) for s in range(1,1 << N))
    print("Subthreshold residue-test families with an invisible nonempty set:", families)
    print("Optimal block partitions verified at six (variable count, modulus) settings.")


if __name__ == "__main__":
    main()
