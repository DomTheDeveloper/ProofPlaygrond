; Index the vertices of an even Hamilton cycle by 0,...,2k-1, with a fixed
; vertex at zero. A nonidentity cycle automorphism fixing zero reverses the
; two directions. This checks the remaining index arithmetic for every k>=2.
(set-logic QF_LIA)
(declare-const k Int)
(declare-const i Int)
(assert (>= k 2))
(assert (and (<= 0 i) (< i (* 2 k))))
(define-fun refl ((x Int)) Int (ite (= x 0) 0 (- (* 2 k) x)))
(define-fun succ ((x Int)) Int (ite (= (+ x 1) (* 2 k)) 0 (+ x 1)))
(push)
(assert (not (= (= (refl i) i) (or (= i 0) (= i k)))))
(check-sat)
(pop)
(push)
(assert (or (and (= (refl i) i) (= (refl (succ i)) (succ i)))
            (and (= (refl i) (succ i)) (= (refl (succ i)) i))))
(check-sat)
(pop)
