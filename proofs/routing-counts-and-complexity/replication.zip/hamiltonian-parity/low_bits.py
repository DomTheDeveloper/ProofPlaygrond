"""Encode nondivisibility of a CNF model count by 2^b in one odd/even query."""
import argparse
from pathlib import Path
from cnf_to_source import read_dimacs


def subset_formula(n, clauses, b):
    if n < 1 or b < 1:
        raise ValueError("use at least one variable and one binary digit")
    if any(not 1 <= abs(lit) <= n for c in clauses for lit in c):
        raise ValueError("literal outside the declared variables")
    slots = (1 << b)-1
    active = list(range(1,slots+1))
    rows = [[slots+1+i*n+j for j in range(n)] for i in range(slots)]
    size = slots*(n+1)
    out = [(active[0],)]
    for i, row in enumerate(rows):
        a = active[i]
        if i:
            out.append((-a,active[i-1]))
        for bit in row:
            out.append((a,-bit))
        for clause in clauses:
            out.append(tuple([-a] + [row[abs(t)-1] if t>0 else -row[-t-1] for t in clause]))
        if not i:
            continue
        prev_equal = None
        for x, y in zip(rows[i-1], row):
            # If all earlier bits agree, forbid (1,0) in two active neighbors.
            guard = [] if prev_equal is None else [-prev_equal]
            out.append(tuple([-a, *guard, -x, y]))
            size += 1
            equal = size
            out.extend(((-equal,-x,y), (-equal,x,-y), (equal,x,y), (equal,-x,-y)))
            if prev_equal is None:
                prev_equal = equal
            else:
                size += 1
                prefix = size
                out.extend(((-prefix,prev_equal),(-prefix,equal),(prefix,-prev_equal,-equal)))
                prev_equal = prefix
        out.append((-a,-prev_equal))
    return size,out


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("formula")
    p.add_argument("bits",type=int)
    p.add_argument("output")
    a = p.parse_args()
    n,cs = read_dimacs(a.formula)
    m,out = subset_formula(n,cs,a.bits)
    body = [f"p cnf {m} {len(out)}",*[" ".join(map(str,(*c,0))) for c in out]]
    Path(a.output).write_text("\n".join(body)+"\n")
