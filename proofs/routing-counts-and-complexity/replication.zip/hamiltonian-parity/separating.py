"""Construct a three-edge-coloring with two clues of each color when deletion disconnects."""
from reflection import alternate, bipartition, components, find_matching, incidence, valid_coloring


def separating_four(graph):
    """Return ('yes', colors), ('no', None), or ('connected remainder', None)."""
    n, edges = graph["vertices"], graph["edges"]
    pins = {int(e): c for e, c in graph["pins"].items()}
    if sorted(pins.values()) != [0, 0, 1, 1] or not all(0 <= e < len(edges) for e in pins):
        raise ValueError("expected four clues, two for each of colors 0 and 1")
    adj = incidence(n, edges)
    sides = bipartition(adj)
    if any(len(a) != 3 for a in adj) or len(components(adj)[0]) != 1:
        raise ValueError("expected a connected cubic graph")
    blocks, labels = components(adj, pins)
    if len(blocks) == 1:
        return "connected remainder", None
    stubs = [[] for _ in blocks]
    for e, c in pins.items():
        for v in edges[e]:
            stubs[labels[v]].append((v, c))
    colors = [pins.get(e) for e in range(len(edges))]
    for vs, ends in zip(blocks, stubs):
        if len(set(ends)) != len(ends):
            return "no", None
        for c in (0, 1):
            if sum((1 if sides[v] == 0 else -1) for v, k in ends if c == k):
                return "no", None
        majority = 0 if sum(c == 0 for _, c in ends) * 2 >= len(ends) else 1
        minority = 1-majority
        covered = {v for v, c in ends if c == majority}
        other = [v for v, c in ends if c == minority]
        if len(other) not in (0, 2):
            raise AssertionError("unexpected number of minority endpoints")
        match = find_matching(adj, sides, vs, covered, pins)
        if match is None:
            return "no", None
        internal = {e for u in vs for _, e in adj[u] if e not in pins}
        for e in match:
            colors[e] = majority
        rest = internal.difference(match)
        seeds = [(e, 2) for v in other for _, e in adj[v] if e in rest]
        alternate(adj, edges, colors, rest, minority, 2, seeds)
    if not valid_coloring(graph, colors):
        raise AssertionError("constructed coloring failed validation")
    return "yes", colors


if __name__ == "__main__":
    import argparse
    import json
    from pathlib import Path
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("graph")
    args = p.parse_args()
    status, coloring = separating_four(json.loads(Path(args.graph).read_text()))
    print(json.dumps({"status": status, "coloring": coloring}))
