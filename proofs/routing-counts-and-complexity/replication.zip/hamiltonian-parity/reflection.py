"""Linear-size graph reductions for Hamilton-cycle and edge-coloring parity.

An input JSON has 'vertices' (an integer) and 'edges' (unordered endpoint pairs).
The core construction takes a connected simple bipartite graph of degrees 2/3
and an edge at a degree-two vertex. Edge colors in outputs are 0, 1, 2.
"""
import argparse
from collections import deque
import json
from pathlib import Path


def incidence(n, edges):
    adj = [[] for _ in range(n)]
    seen = set()
    for i, (u, v) in enumerate(edges):
        pair = (min(u, v), max(u, v))
        if not (0 <= u < n and 0 <= v < n) or u == v or pair in seen:
            raise ValueError("expected a simple graph on the declared vertices")
        seen.add(pair)
        adj[u].append((v, i))
        adj[v].append((u, i))
    return adj


def components(adj, skip=()):
    skip = set(skip)
    labels = [-1] * len(adj)
    blocks = []
    for start in range(len(adj)):
        if labels[start] != -1:
            continue
        block = [start]
        labels[start] = len(blocks)
        for u in block:
            for v, e in adj[u]:
                if e not in skip and labels[v] == -1:
                    labels[v] = labels[u]
                    block.append(v)
        blocks.append(block)
    return blocks, labels


def bipartition(adj):
    sides = [-1] * len(adj)
    for start in range(len(adj)):
        if sides[start] >= 0:
            continue
        sides[start] = 0
        queue = [start]
        for u in queue:
            for v, _ in adj[u]:
                if sides[v] == -1:
                    sides[v] = sides[u] ^ 1
                    queue.append(v)
                elif sides[v] == sides[u]:
                    raise ValueError("graph is not bipartite")
    return sides


def find_matching(adj, sides, vertices, covered=(), forbidden=()):
    """Perfect matching on an induced vertex set after supplied endpoints are covered."""
    active = set(vertices).difference(covered)
    left = [u for u in sorted(active) if sides[u] == 0]
    if 2 * len(left) != len(active):
        return None
    forbidden = set(forbidden)
    partner, chosen = {}, {}
    for root in left:
        queue = deque([root])
        prev, free = {}, None
        while queue and free is None:
            u = queue.popleft()
            for v, edge in adj[u]:
                if v not in active or edge in forbidden or v in prev:
                    continue
                prev[v] = u, edge
                if v not in partner:
                    free = v
                    break
                queue.append(partner[v])
        if free is None:
            return None
        while free is not None:
            u, edge = prev[free]
            old = partner.get(u)
            partner[u], partner[free], chosen[u] = free, u, edge
            free = old
    return set(chosen.values())


def alternate(adj, edges, colors, remaining, first, second, starts=()):
    """Alternate first/second along paths or even cycles; starts lists fixed incident values."""
    remaining = set(remaining)
    def propagate(queue):
        while queue:
            e, c = queue.popleft()
            if colors[e] is not None:
                if colors[e] != c:
                    raise ValueError("inconsistent path phases")
                continue
            colors[e] = c
            for u in edges[e]:
                for _, f in adj[u]:
                    if f in remaining and f != e:
                        queue.append((f, first + second - c))
    propagate(deque(starts))
    for seed in sorted(remaining):
        if colors[seed] is None:
            propagate(deque([(seed, first)]))
    return colors


def two_clue_witness(graph):
    n, edges = graph["vertices"], graph["edges"]
    adj = incidence(n, edges)
    (e, c0), (f, c1) = sorted((int(k), v) for k, v in graph["pins"].items())
    if c0 == c1 or c0 not in range(3) or c1 not in range(3):
        raise ValueError("expected two distinct prescribed colors")
    match = find_matching(adj, graph["sides"], range(n), edges[e], [f])
    if match is None:
        return None
    match.add(e)
    colors = [c0 if i in match else None for i in range(len(edges))]
    rest = set(range(len(edges))).difference(match)
    return alternate(adj, edges, colors, rest, c1, 3-c0-c1, [(f, c1)])


def construct(n, edges, probe=None):
    adj = incidence(n, edges)
    sides = bipartition(adj)
    if not n or len(components(adj)[0]) != 1 or any(len(a) not in (2, 3) for a in adj):
        raise ValueError("input must be connected with every degree two or three")
    if probe is None:
        probe = next((a[0][1] for a in adj if len(a) == 2), None)
    if probe is None or not 0 <= probe < len(edges):
        raise ValueError("provide an edge incident with a degree-two vertex")
    u, v = edges[probe]
    if min(len(adj[u]), len(adj[v])) != 2:
        raise ValueError("the selected edge must be incident with a degree-two vertex")
    base_edges = []
    for shift in (0, n):
        base_edges.extend((a + shift, b + shift) for a, b in edges)
    base_edges.extend((w, n + w) for w in range(n) if len(adj[w]) == 2)
    e, f = probe, probe + len(edges)
    two = {"vertices": 2*n, "edges": base_edges, "pins": {e: 0, f: 1},
           "sides": sides + [1-s for s in sides]}
    host = [pair for i, pair in enumerate(base_edges) if i not in (e, f)]
    x, y = 2*n, 2*n+1
    capped = {"vertices": 2*n+2, "edges": host + [(u, x), (u+n, x), (v, y),
              (v+n, y), (x, y)], "bipartite_after_deleting": [x, y]}
    ends = (u, v, u+n, v+n)
    square = list(range(2*n, 2*n+4))
    square_sides = [1-two["sides"][a] for a in ends]
    spokes = list(zip(ends, square))
    inner = [(p, q) for j, p in enumerate(square) for k, q in enumerate(square)
             if square_sides[j] == 0 and square_sides[k] == 1]
    four = {"vertices": 2*n+4, "edges": host + spokes + inner,
            "pins": {len(host)+j: j//2 for j in range(4)},
            "sides": two["sides"] + square_sides}
    return two, capped, four


def valid_coloring(graph, colors):
    if colors is None or len(colors) != len(graph["edges"]):
        return False
    adj = incidence(graph["vertices"], graph["edges"])
    return (all({colors[e] for _, e in a} == {0, 1, 2} for a in adj) and
            all(colors[int(e)] == c for e, c in graph.get("pins", {}).items()))


def witnesses(two, capped, four):
    c = two_clue_witness(two)
    if c is None:
        return None
    ids = {int(e) for e in two["pins"]}
    common = [z for i, z in enumerate(c) if i not in ids]
    k = common + [0, 1, 0, 1, 2]
    spokes = [0, 0, 1, 1]
    q = common + spokes
    n = two["vertices"]
    for a, b in four["edges"][-4:]:
        i, j = spokes[a-n], spokes[b-n]
        q.append(2 if i != j else 1-i)
    if not all(valid_coloring(g, cs) for g, cs in ((two, c), (capped, k), (four, q))):
        raise AssertionError("witness transport failed")
    return c, k, q


def valid_cycle(n, edges, selected):
    if len(selected) != n or len(set(selected)) != n or any(not 0 <= e < len(edges) for e in selected):
        return False
    adj = incidence(n, [edges[e] for e in selected])
    return all(len(a) == 2 for a in adj) and len(components(adj)[0]) == 1


def lift_cycle(source, two, capped):
    n, edges = source["vertices"], source["edges"]
    original = source["hamiltonian_cycle"]
    e = min(map(int,two["pins"]))
    if not valid_cycle(n,edges,original) or e not in original:
        raise ValueError("invalid source Hamiltonian cycle")
    index = {tuple(sorted(pair)): j for j,pair in enumerate(capped["edges"])}
    selected = []
    for j in original:
        if j != e:
            u,v = edges[j]
            for delta in (0,n):
                selected.append(index[tuple(sorted((u+delta,v+delta)))])
    m = len(capped["edges"])
    selected.extend(range(m-5,m-1))
    if not valid_cycle(capped["vertices"],capped["edges"],selected):
        raise AssertionError("transported Hamiltonian cycle is invalid")
    return sorted(selected)


def grid(points):
    pts = sorted(set(map(tuple, points)))
    index = {p: i for i, p in enumerate(pts)}
    edges = []
    for i, (x, y) in enumerate(pts):
        for q in ((x+1, y), (x, y+1)):
            if q in index:
                edges.append((i, index[q]))
    return {"vertices": len(pts), "edges": edges}


def even_example():
    # Three internally disjoint even paths between the two degree-three vertices.
    return grid([(x,y) for x in range(5) for y in (0,2)] + [(x,1) for x in (0,2,4)])


def prepare_grid_reduction(graph):
    """Map the easy zero cases to a colorable even example, preserving the witness promise."""
    n, edges = graph["vertices"], graph["edges"]
    adj = incidence(n, edges)
    bipartition(adj)
    if any(len(a) > 3 for a in adj):
        raise ValueError("expected maximum degree three")
    probe = next((a[0][1] for a in adj if len(a) == 2), None)
    if (not n or any(len(a) < 2 for a in adj) or len(components(adj)[0]) != 1
            or (probe is not None and len(components(adj, [probe])[0]) != 1)):
        fixed = even_example()
        return construct(fixed["vertices"], fixed["edges"]), True
    return construct(n, edges, probe), False


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("input", help="subcubic grid graph JSON with edges/vertices or points")
    p.add_argument("output", help="JSON containing all three graphs and full coloring witnesses")
    args = p.parse_args()
    source = json.loads(Path(args.input).read_text())
    if "points" in source:
        source = grid(source["points"])
    graphs, fallback = prepare_grid_reduction(source)
    cs = witnesses(*graphs)
    if cs is None:
        raise AssertionError("preprocessing failed to ensure a compatible coloring")
    out = dict(zip(("two_clues", "cubic", "four_clues"), graphs))
    if "hamiltonian_cycle" in source:
        if fallback:
            raise ValueError("source claimed a Hamiltonian cycle on an easy zero case")
        out["cubic"]["hamiltonian_cycle"] = lift_cycle(source, graphs[0], graphs[1])
    out["colorings"] = dict(zip(("two_clues", "cubic", "four_clues"), cs))
    out["trivial_zero_replaced"] = fallback
    Path(args.output).write_text(json.dumps(out, separators=(",", ":"))+"\n")


if __name__ == "__main__":
    main()
