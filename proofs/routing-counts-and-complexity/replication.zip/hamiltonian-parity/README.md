# Hamiltonian parity via reflection

This package accompanies the working manuscript *Hamiltonian parity in cubic graphs via reflection*. It contains two routes to the reduction. The short proof starts with the published parsimonious theorem for square-grid Hamiltonicity. The optional compiler starts with a Boolean CNF formula and constructs a bipartite source graph directly. The Python programs use the standard library and run on Python 3.10 or newer.

## Run a small example

```sh
python3 reflection.py examples/square.json square_result.json
```

This writes three graphs and a proper three-edge-coloring for each one. The input square has one Hamiltonian cycle. The unmarked cubic graph has ten vertices and three Hamiltonian cycles. One cycle is invariant under interchanging its two sheets. The two-clue graph and the four-clue graph each have exactly one compatible labeled coloring.

The file `examples/three_paths.json` gives a complementary example. Its source has zero Hamiltonian cycles. The unmarked cubic graph has fourteen cycles and the four-clue graph has twelve compatible colorings.

## Compile a formula and give a known Hamiltonian cycle

```sh
python3 cnf_to_source.py --plant examples/one_model.cnf source.json
python3 reflection.py source.json result.json
```

The optional switch `--plant` first adds exactly two known models. Parity is preserved, and the output includes a Hamiltonian cycle on the unmarked cubic graph even when the original formula is unsatisfiable. Omit the switch to preserve the exact number of source cycles. The input is DIMACS CNF with at least one declared variable.

For the raw source on a normalized formula with n variables and L occurrences, the graph has 256L + 4n vertices. Every assignment produces a spanning 2-factor with one cycle if true and three if false. When the source is connected and its selected edge is a nonbridge, the unmarked cubic output has two copies of the source vertices plus two connectors. The original grid starting theorem and the direct Boolean compiler are independent routes to hardness.

## Data format

The source may provide integer grid points under `points`, or a vertex count under `vertices` and pairs of vertex indices under `edges`. Vertices, edge indices, colors and Latin-square entries are zero-based. The source for the core construction is simple, connected, bipartite, has degrees two or three, and has at least one vertex of degree two. The command handles the trivial zero cases of subcubic grid Hamiltonicity by producing the fixed even example. The flag `trivial_zero_replaced` records this choice.

The output keys are `two_clues`, `cubic`, `four_clues`, `colorings` and `trivial_zero_replaced`. Bipartite graphs also include `sides`. Keys of `pins` refer to edge indices. The two witnesses under `bipartite_after_deleting` are vertices. An optional `hamiltonian_cycle` is a list of edge indices. For a source with n vertices, vertices 0 through n−1 in the doubled graph belong to sheet zero, the next n to sheet one, and the two final vertices of the unmarked graph are fixed by its reflection.

The function `separating_four` in `separating.py` takes four clues in two named colors and returns a decision and a coloring when deleting the four edges disconnects the graph. It reports “connected remainder” for the remaining case. The function `convert` in `latin.py` generates the Latin square instance with three incomplete rows and optionally transports a witness. The complete square example is in `examples/square_latin.json`.

## Query a low binary digit range

`low_bits.py` takes a formula, a positive integer b, and an output path. It writes a new CNF whose model count is odd exactly when the original count is nonzero modulo 2^b. It uses 2^b−1 model slots, so the size grows exponentially in b. To follow the full graph pipeline with a small choice of b, run the following commands.

```sh
python3 low_bits.py examples/one_model.cnf 2 test.cnf
python3 cnf_to_source.py test.cnf source.json
python3 reflection.py source.json result.json
```

`check_low_bits.py` uses independent exact DPLL counting to verify the encoding. It also builds small nonempty formulas invisible to fixed parity tests and verifies the sharp size threshold for subset-count queries modulo powers of two on small universes.

## Reproduce the checks

```sh
python3 check_reflection.py
python3 check_cnf.py
python3 check_latin.py
python3 check_low_bits.py
python3 check_arithmetic.py
```

The last command uses an optional installation of the native Z3 library. Alternatively run `z3 reflection_lemma.smt2` and expect two `unsat` responses. These are unbounded integer checks for the cyclic index calculation used in the proof. The mathematical reduction is presented in the manuscript. A full proof-assistant formalization and independent peer review remain outstanding.

`check_reflection.py` enumerates Hamiltonian cycles and edge-colorings directly from raw adjacency on small graphs. It also compares the separating-clue solver with all coloring completions on four test graphs. `check_cnf.py` reconstructs the spanning 2-factors from source edges, decodes assignments independently of gate execution, and validates planted cycles. `check_latin.py` solves the small Latin instances by independent row search. Exact output from the runs is in `CHECK_RESULTS.txt`. The PDF source is `Hamiltonian_Parity_via_Reflection.tex` and can be built with two passes of pdfLaTeX on a standard TeX Live installation.

