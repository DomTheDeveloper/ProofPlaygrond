"""Compile CNF-SAT to cubic bipartite edge precoloring with exactly two blue clues.

Python 3.10+, no dependencies. Input is DIMACS CNF with at least one variable.
The output is a JSON graph. Each edge is [endpoint, endpoint, precolor] with
0 = uncolored, 1 = red, 2 = blue. Decoder entries are edge indices: bit x is
one exactly when the corresponding edge is red in the completed coloring.
"""

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


def read_dimacs(path):
    variables = count = None
    clauses, current = [], []
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("c"):
            continue
        if line.startswith("p"):
            fields = line.split()
            if len(fields) != 4 or fields[:2] != ["p", "cnf"] or variables is not None:
                raise ValueError("expected one 'p cnf VARIABLES CLAUSES' header")
            variables, count = map(int, fields[2:])
            continue
        if variables is None:
            raise ValueError("missing DIMACS header before clauses")
        for literal in map(int, line.split()):
            if literal:
                current.append(literal)
            else:
                clauses.append(tuple(current))
                current = []
    if variables is None or variables < 1 or current or count != len(clauses):
        raise ValueError("invalid header, clause count, or unterminated clause")
    return variables, clauses


def normalize(variables, clauses):
    if variables < 1:
        raise ValueError("the construction assumes at least one variable")
    normalized = []
    for clause in clauses:
        if any(not isinstance(lit, int) or not 1 <= abs(lit) <= variables for lit in clause):
            raise ValueError("literal outside the declared variable range")
        if clause:
            normalized.append(tuple(clause))
        else:
            normalized.extend(((1,), (-1,)))
    used = {abs(lit) for clause in normalized for lit in clause}
    normalized.extend((i, -i) for i in range(1, variables + 1) if i not in used)
    return normalized


@dataclass(frozen=True)
class Step:
    # literal = 0 denotes a fixed permutation. Every permutation is an involution.
    literal: int
    pairs: tuple


def program(clauses):
    """Return the touched lanes and the sparse reversible sequence S, T, inverse(S)."""
    forward = []
    for index, clause in enumerate(clauses, 1):
        guards = []
        for position, literal in enumerate(clause, 1):
            swaps = tuple(((group, 0, rail), (group, position, rail))
                          for group in (0, index) for rail in (0, 1))
            guards.append(Step(literal, swaps))
        middle = Step(0, tuple(((0, 0, rail), (index, 0, rail)) for rail in (0, 1)))
        forward.extend([*guards, middle, *reversed(guards)])
    toggle = Step(0, tuple(((i, 0, 0), (i, 0, 1)) for i in range(1, len(clauses) + 1)))
    widths = [max(map(len, clauses)), *map(len, clauses)]
    lanes = [(g, r, b) for g, width in enumerate(widths)
             for r in range(width + 1) for b in (0, 1)]
    return lanes, [*forward, toggle, *reversed(forward)]


def wire_program(variables, lanes, steps):
    """Splice unchanged lanes. Assign an input and output port to each touched lane."""
    # Before its first gate a lane carries its own symbolic boundary source.
    last = {lane: lane for lane in lanes}
    first_inputs = {}
    connections = []
    groups = [[] for _ in range(variables)]
    next_port = 0
    for step in steps:
        # A negative-literal involution is its fixed swap followed by the
        # same swap controlled on the positive variable.
        if step.literal <= 0:
            for a, b in step.pairs:
                last[a], last[b] = last[b], last[a]
        if step.literal == 0:
            continue
        transpositions = []
        for lane_a, lane_b in step.pairs:
            ports = []
            for lane in (lane_a, lane_b):
                port = next_port
                next_port += 1
                previous = last[lane]
                if isinstance(previous, tuple):
                    if previous in first_inputs:
                        raise ValueError("boundary source encountered twice")
                    first_inputs[previous] = port
                else:
                    connections.append((previous, port, None))
                last[lane] = port
                ports.append(port)
            transpositions.append(tuple(ports))
        groups[abs(step.literal) - 1].extend(transpositions)
    for lane in lanes:
        if lane not in first_inputs or not isinstance(last[lane], int):
            raise ValueError("a logical lane missed every controlled step")
        connections.append((last[lane], first_inputs[lane], lane))
    return groups, connections


def compile_cnf(variables, clauses, lock_kempe=False):
    clauses = normalize(variables, clauses)
    if lock_kempe:
        clauses.extend((i, -i) for i in range(1, variables + 1))
    lanes, steps = program(clauses)
    groups, logic_wires = wire_program(variables, lanes, steps)
    next_vertex = 0
    edges, wires, decoders = [], [], []
    inputs, outputs = {}, {}
    for pairs in groups:
        size = 2 * len(pairs)
        ring = []
        # Two consecutive swaps get interlaced endpoint order a,c,b,d.
        for i in range(0, len(pairs), 2):
            (a, b), (c, d) = pairs[i:i + 2]
            ring.extend((a, c, b, d))
        positions = 2 * size + 1
        reserve = positions - 1
        left = [next_vertex + 2 * i for i in range(positions)]
        right = [v + 1 for v in left]
        next_vertex += 2 * positions
        # The edge L_0--R_z belongs to the straight residual matching, so
        # it is red precisely in shifted state x=1.
        decoders.append(len(edges))
        straight = list(range(positions))
        straight[0], straight[reserve] = straight[reserve], straight[0]
        for i in range(positions):
            shifted = reserve if i == reserve else (i + 1) % reserve
            edges.append([left[i], right[straight[i]], 0])
            edges.append([left[i], right[shifted], 0])
        for i, external in enumerate(ring):
            inputs[external], outputs[external] = left[2 * i], right[2 * i]
            partner = 4 * (i // 4) + (i + 2) % 4
            target = (partner - 1) % size
            wires.append((right[2 * i + 1], left[2 * target + 1], None))
        wires.append((right[reserve], left[reserve], None))
    wires.extend((outputs[a], inputs[b], boundary) for a, b, boundary in logic_wires)
    relay_start = next_vertex
    next_vertex = relay_start + 2 * len(wires)
    for i, (source, target, boundary) in enumerate(wires):
        u, v = relay_start + 2 * i, relay_start + 2 * i + 1
        successor_v = relay_start + 2 * ((i + 1) % len(wires)) + 1
        edges.extend(([source, u, 0], [v, target, 0], [u, successor_v, 1]))
        if boundary not in ((0, 0, 0), (0, 0, 1)):
            edges.append([u, v, 0])
            continue
        # Isolate the blue clue from every red clue. The unpinned chords are
        # forced red. Probe position 3 reads the wire, position 4 its opposite.
        probe = 3 if boundary[-1] == 0 else 4
        inside = list(range(next_vertex, next_vertex + 8))
        next_vertex += 8
        path = [u, *inside, v]
        for j, (a, b) in enumerate(zip(path, path[1:])):
            edges.append([a, b, 2 if j == probe else 0])
        for a, b in ((1, 4), (3, 6), (5, 8), (7, 2)):
            touches_probe = a in (probe, probe + 1) or b in (probe, probe + 1)
            edges.append([path[a], path[b], 0 if touches_probe else 1])
    exponent = variables + len(lanes) - len(clauses) - 2
    return {"vertices": next_vertex, "edges": edges,
            "variable_red_edges": decoders, "extension_exponent": exponent}


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("formula", help="DIMACS CNF")
    parser.add_argument("output", help="new graph JSON")
    parser.add_argument("--lock-kempe", action="store_true",
                        help="insert tautologies so each solution is a separate Kempe class")
    args = parser.parse_args()
    graph = compile_cnf(*read_dimacs(args.formula), lock_kempe=args.lock_kempe)
    Path(args.output).write_text(json.dumps(graph, separators=(",", ":")) + "\n")
    print(f"{graph['vertices']} vertices, {len(graph['edges'])} edges, "
          f"{len(graph['variable_red_edges'])} variable cycles, 2 blue clues")


if __name__ == "__main__":
    main()
