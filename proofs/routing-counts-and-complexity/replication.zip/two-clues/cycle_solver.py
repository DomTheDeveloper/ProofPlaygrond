"""Count or construct extensions when the residual red matching graph has degree at most 2.

Reads raw JSON {vertices, edges}. Each edge is [u,v,color], color 0/1/2/3.
The solver ignores all compiler metadata. Python 3.10+, standard library.
"""

import argparse
import json
from pathlib import Path
import sys


class MatchingFamily:
    def __init__(self, graph):
        self.vertices = graph["vertices"]
        self.edges = graph["edges"]
        self.incident = [[] for _ in range(self.vertices)]
        distinct = set()
        for edge, (u, v, color) in enumerate(self.edges):
            if not (0 <= u < self.vertices and 0 <= v < self.vertices and
                    u != v and color in range(4)):
                raise ValueError("invalid edge")
            endpoints = min(u, v), max(u, v)
            if endpoints in distinct:
                raise ValueError("parallel edges")
            distinct.add(endpoints)
            self.incident[u].append(edge)
            self.incident[v].append(edge)
        if any(len(row) != 3 for row in self.incident):
            raise ValueError("graph must be cubic")
        self.side = [-1] * self.vertices
        self.components = 0
        for start in range(self.vertices):
            if self.side[start] >= 0:
                continue
            self.components += 1
            self.side[start] = 0
            todo = [start]
            while todo:
                u = todo.pop()
                for edge in self.incident[u]:
                    v = self.other(edge, u)
                    if self.side[v] < 0:
                        self.side[v] = self.side[u] ^ 1
                        todo.append(v)
                    elif self.side[v] == self.side[u]:
                        raise ValueError("graph must be bipartite")
        self.fixed = set()
        self.choices = []
        self.feasible = True
        covered = set()
        for e, (u, v, color) in enumerate(self.edges):
            if color == 1:
                if u in covered or v in covered:
                    self.feasible = False
                covered.update((u, v))
                self.fixed.add(e)
        if not self.feasible:
            return
        available = {u: [] for u in range(self.vertices) if u not in covered}
        for e, (u, v, color) in enumerate(self.edges):
            if u in available and v in available and color == 0:
                available[u].append(e)
                available[v].append(e)
        if any(len(row) > 2 for row in available.values()):
            raise ValueError("outside solver domain: residual red degree exceeds two")
        seen = set()
        for start in available:
            if start in seen:
                continue
            todo, nodes = [start], []
            seen.add(start)
            while todo:
                u = todo.pop()
                nodes.append(u)
                for e in available[u]:
                    v = self.other(e, u)
                    if v not in seen:
                        seen.add(v)
                        todo.append(v)
            if len(nodes) % 2:
                self.feasible = False
                return
            ends = [v for v in nodes if len(available[v]) < 2]
            begin = ends[0] if ends else start
            u, previous, row = begin, -1, []
            while True:
                options = [e for e in available[u] if e != previous]
                if not options:
                    break
                e = options[0]
                row.append(e)
                u, previous = self.other(e, u), e
                if u == begin:
                    break
            if ends:
                self.fixed.update(row[::2])
            else:
                self.choices.append((row[::2], row[1::2]))

    def other(self, e, u):
        a, b, _ = self.edges[e]
        return b if a == u else a

    def matchings(self):
        if not self.feasible:
            return
        for mask in range(1 << len(self.choices)):
            red = set(self.fixed)
            for bit, halves in enumerate(self.choices):
                red.update(halves[(mask >> bit) & 1])
            yield red

    def inspect(self, red, witness=False, rng=None):
        seen = bytearray(len(self.edges))
        for e in red:
            seen[e] = 1
        coloring = [1] * len(self.edges) if witness else None
        cycles = pinned = bad = 0
        for seed, (start, _, _) in enumerate(self.edges):
            if seen[seed]:
                continue
            cycles += 1
            phase, conflict, parity = None, False, 0
            edge, u = seed, start
            tour = [] if witness else None
            while not seen[edge]:
                seen[edge] = 1
                if witness:
                    tour.append(edge)
                color = self.edges[edge][2]
                if color:
                    required = parity ^ (color - 2)
                    if phase is None:
                        phase = required
                    elif phase != required:
                        conflict = True
                v = self.other(edge, u)
                for nxt in self.incident[v]:
                    if nxt != edge and nxt not in red:
                        break
                u, edge, parity = v, nxt, parity ^ 1
            if edge != seed or u != start or parity:
                raise ValueError("candidate does not leave disjoint even cycles")
            pinned += phase is not None
            bad += conflict
            if witness:
                orientation = 0 if phase is None else phase
                if phase is None and rng is not None:
                    orientation = rng.getrandbits(1)
                for j, e in enumerate(tour):
                    coloring[e] = 2 + ((j & 1) ^ orientation)
        ways = 0 if bad else 1 << (cycles - pinned)
        return bad, cycles, ways, coloring if ways else None


def solve(graph, want_witness=False):
    family = MatchingFamily(graph)
    compatible = total = 0
    coloring = None
    for red in family.matchings():
        bad, _, ways, candidate = family.inspect(red, want_witness and coloring is None)
        if not bad:
            compatible += 1
            total += ways
            if candidate is not None:
                coloring = candidate
    answer = {"extendible_red_matchings": compatible, "full_extensions": total}
    if want_witness:
        answer["coloring"] = coloring
    return answer


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("graph")
    parser.add_argument("--witness", action="store_true")
    args = parser.parse_args()
    graph = json.loads(Path(args.graph).read_text())
    result = solve(graph, args.witness)
    if hasattr(sys, "set_int_max_str_digits"):
        # Exact counts can have arbitrarily many decimal digits.
        sys.set_int_max_str_digits(0)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
