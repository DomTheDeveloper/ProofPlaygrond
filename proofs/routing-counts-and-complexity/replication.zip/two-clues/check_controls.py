"""Finite controls for exact sampling, square switches, and planar terminal pairings."""

from collections import Counter
from itertools import product
from random import Random
from two_blue import compile_cnf
from verify import check_coloring, require, generic_raw_count
from sample_background import background, sample


def unit_sampler_check():
    graph = compile_cnf(1, [(1,)])
    family = background(graph)
    probes = [e for e, (_, _, c) in enumerate(graph["edges"]) if c == 2]

    class Tape:
        def __init__(self, value):
            self.value = value
            self.used = 0

        def getrandbits(self, k):
            require(k == 1, "unexpected draw size")
            bit = (self.value >> self.used) & 1
            self.used += 1
            return bit

    seen = set()
    histogram = Counter()
    for bits in range(512):
        tape = Tape(bits)
        coloring = sample(family, tape)
        require(tape.used == 9, "unexpected number of fair draws")
        check_coloring(family, coloring)
        seen.add(bytes(coloring))
        histogram[tuple(coloring[e] for e in probes)] += 1
    total = generic_raw_count({"vertices": graph["vertices"], "edges": family.edges})
    require(total == len(seen) == 512, "sampler failed to be bijective")
    require(histogram == {(2,2):64, (2,3):192, (3,2):192, (3,3):64}, "joint counts")
    print("Sampler: 512 fair-coin tapes gave 512 distinct colorings; raw count", total)


def square_check():
    rng = Random(110621)
    checks = 0
    for n in range(1, 6):
        for _ in range(25):
            targets = list(range(2 * n))
            rng.shuffle(targets)
            separable = set()
            for states in product(range(2), repeat=n):
                successors = [2 * (target // 2) + ((target % 2) ^ states[target // 2])
                              for target in targets]
                labels = {}
                for i in range(2 * n):
                    j = i
                    while j not in labels:
                        labels[j] = i
                        j = successors[j]
                separable.update((a, b) for a in labels for b in labels if labels[a] != labels[b])
            for a in range(2 * n):
                for b in range(2 * n):
                    if a == b:
                        continue
                    start, end = targets[a] // 2, a // 2
                    todo, visited = [start], {start}
                    while todo:
                        u = todo.pop()
                        for edge in (2*u, 2*u + 1):
                            v = targets[edge] // 2
                            if edge not in (a,b) and v not in visited:
                                todo.append(v)
                                visited.add(v)
                    require((end in visited) == ((a,b) in separable), "square reachability")
                    checks += 1
    print("125 square networks;", checks, "ordered opposite-wire requests checked")


def planar_check():
    target = {(a, b, a, b) for a, b in product(range(2), repeat=2)}
    for p, q, r, s in [(0,1,2,3), (0,3,1,2)]:
        for flip, other in product(range(2), repeat=2):
            boundary = {v for v in product(range(2), repeat=4)
                        if v[p] ^ v[q] == flip and v[r] ^ v[s] == other}
            require(len(boundary) == 4 and not boundary <= target, "planar obstruction")
    print("All eight signed noncrossing boundary patterns excluded the exact crossover.")


if __name__ == "__main__":
    unit_sampler_check()
    square_check()
    planar_check()
