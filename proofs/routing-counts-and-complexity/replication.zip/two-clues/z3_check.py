"""Independent optional cross-check using an installed Z3 shared library.

Only the raw graph and its precolors go into the SMT solver. ctypes is in Python's
standard library; libz3 is an optional external dependency for this file only.
"""

import ctypes
import ctypes.util
import json
from itertools import combinations, product
import sys

from two_blue import compile_cnf


def decide(graph):
    name = ctypes.util.find_library("z3")
    if not name:
        raise RuntimeError("the optional Z3 shared library is not installed")
    lib = ctypes.CDLL(name)
    pointer, string = ctypes.c_void_p, ctypes.c_char_p
    for fn, args, ret in (("Z3_mk_config", [], pointer),
                          ("Z3_mk_context", [pointer], pointer),
                          ("Z3_del_config", [pointer], None),
                          ("Z3_del_context", [pointer], None),
                          ("Z3_eval_smtlib2_string", [pointer, string], string)):
        routine = getattr(lib, fn)
        routine.argtypes, routine.restype = args, ret
    config = lib.Z3_mk_config()
    context = lib.Z3_mk_context(config)
    lib.Z3_del_config(config)
    try:
        script = ["(set-logic QF_UF)", "(set-option :timeout 60000)"]
        incident = [[] for _ in range(graph["vertices"])]

        def exactly_one(symbols):
            script.append(f"(assert (or {' '.join(symbols)}))")
            for a, b in combinations(symbols, 2):
                script.append(f"(assert (or (not {a}) (not {b})))")

        for e, (u, v, color) in enumerate(graph["edges"]):
            symbols = [f"e{e}c{j}" for j in (1, 2, 3)]
            for symbol in symbols:
                script.append(f"(declare-const {symbol} Bool)")
            exactly_one(symbols)
            if color:
                script.append(f"(assert {symbols[color - 1]})")
            for w in (u, v):
                incident[w].append(symbols)
        for row in incident:
            for same_color in zip(*row):
                exactly_one(same_color)
        script.append("(check-sat-using sat)")
        data = "\n".join(script).encode()
        return lib.Z3_eval_smtlib2_string(context, data).decode().strip()
    finally:
        lib.Z3_del_context(context)


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as source:
            print(decide(json.load(source)))
        return
    tests = [
        (1, [(1,)], "sat"),
        (1, [(-1,)], "sat"),
        (1, [(1,),(-1,)], "unsat"),
        (2, [(1,2),(-1,2),(1,-2)], "sat"),
        (2, [(1,2),(-1,2),(1,-2),(-1,-2)], "unsat"),
        (3, [tuple(s*(j+1) for j,s in enumerate(signs))
             for signs in product((-1,1), repeat=3)], "unsat"),
    ]
    for n, clauses, answer in tests:
        graph = compile_cnf(n, clauses)
        actual = decide(graph)
        print(graph["vertices"], answer, actual, flush=True)
        if actual != answer:
            raise RuntimeError("raw SMT check failed")


if __name__ == "__main__":
    main()
