"""Exactly uniform red-only sampling for the compiled graph family.

Returns one full coloring with the two blue requirements released. Uniformity
over red matchings relies on the equal-cycle-count theorem for compiled graphs.
"""

import argparse
import json
from pathlib import Path
from random import Random, SystemRandom

from cycle_solver import MatchingFamily


def background(graph):
    no_blue = {"vertices": graph["vertices"],
               "edges": [[u, v, 1 if color == 1 else 0] for u, v, color in graph["edges"]]}
    family = MatchingFamily(no_blue)
    if not family.feasible:
        raise ValueError("no red matching")
    return family


def sample(family, rng):
    red = set(family.fixed)
    for even, odd in family.choices:
        red.update(odd if rng.getrandbits(1) else even)
    return family.inspect(red, witness=True, rng=rng)[3]


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("graph")
    p.add_argument("--seed", type=int)
    args = p.parse_args()
    graph = json.loads(Path(args.graph).read_text())
    rng = SystemRandom() if args.seed is None else Random(args.seed)
    coloring = sample(background(graph), rng)
    probes = [coloring[e] for e, (_, _, c) in enumerate(graph["edges"]) if c == 2]
    print(json.dumps({"probe_colors": probes, "coloring": coloring}))


if __name__ == "__main__":
    main()
