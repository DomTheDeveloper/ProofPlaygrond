"""Reproduce the finite graph checks of the two-blue reduction. Python 3.10+."""

from collections import Counter
from itertools import combinations, product
import random

from two_blue import compile_cnf, normalize
from cycle_solver import MatchingFamily, solve


def truth(clauses, bits):
    return all(any(bool((bits >> (abs(lit) - 1)) & 1) == (lit > 0)
                   for lit in clause) for clause in clauses)


def require(value, message):
    if not value:
        raise AssertionError(message)


def check_coloring(family, coloring):
    require(all(sorted(coloring[e] for e in row) == [1, 2, 3] for row in family.incident),
            "invalid full coloring")
    require(all(not c or c == coloring[e] for e, (_, _, c) in enumerate(family.edges)),
            "clue violated")


def verify_formula(n, clauses, stats):
    graph = compile_cnf(n, clauses)
    family = MatchingFamily(graph)
    require(family.components == 1 and family.feasible, "disconnected or no red matching")
    require(len(family.choices) == n, "wrong number of red-choice components")
    require(sum(c == 2 for _, _, c in family.edges) == 2, "wrong blue count")
    clean = normalize(n, clauses)
    m, literals = len(clean), sum(map(len, clean))
    expected_vertices = 256 * literals + 4 * n + 16
    require(graph["vertices"] == expected_vertices, "size formula")
    pinned_vertices = [u for a, b, color in family.edges if color for u in (a, b)]
    require(len(pinned_vertices) == len(set(pinned_vertices)), "clues not a matching")
    require(sum(c == 1 for _, _, c in family.edges) * 4 == expected_vertices, "red coverage")
    require(len(family.fixed) == expected_vertices // 4 + 4, "forced chords")
    cycle_lengths = [len(a) + len(b) for a, b in family.choices]
    occurrences = Counter(abs(lit) for clause in clean for lit in clause)
    require(sorted(cycle_lengths) == sorted(128 * d + 2 for d in occurrences.values()),
            "core cycle lengths")
    width = 2 * (max(map(len, clean)) + 1 + literals + m)
    exponent = n + width - m - 2
    require(exponent == graph["extension_exponent"], "exponent")
    counts = {}
    for red in family.matchings():
        bits = sum((e in red) << i for i, e in enumerate(graph["variable_red_edges"]))
        require(bits not in counts, "repeated decoded assignment")
        want = truth(clauses, bits)
        bad, cycles, ways, coloring = family.inspect(red, witness=True)
        require(bad == int(not want) and cycles == exponent + 2, "cycle identity")
        require(ways == (1 << exponent if want else 0), "multiplicity")
        if coloring is not None:
            check_coloring(family, coloring)
        counts[bits] = ways
    require(len(counts) == 1 << n, "missing assignment")
    stats["graphs"] += 1
    stats["assignments"] += len(counts)
    stats["yes assignments"] += sum(v > 0 for v in counts.values())
    stats["no assignments"] += sum(v == 0 for v in counts.values())
    stats["yes graphs" if any(counts.values()) else "no graphs"] += 1
    stats["largest graph"] = max(stats["largest graph"], graph["vertices"])


def generic_raw_count(graph):
    """Generic edge-domain backtracking. Uses neither matchings nor compiler metadata."""
    edges = graph["edges"]
    incident = [[] for _ in range(graph["vertices"])]
    for i, (u, v, _) in enumerate(edges):
        incident[u].append(i)
        incident[v].append(i)
    initial = [7 if c == 0 else 1 << (c - 1) for _, _, c in edges]

    def visit(domains, queue):
        while queue:
            vertex = queue.pop()
            slots = incident[vertex]
            supported = [0, 0, 0]
            for one, two, three in ((1,2,4), (1,4,2), (2,1,4), (2,4,1), (4,1,2), (4,2,1)):
                if domains[slots[0]] & one and domains[slots[1]] & two and domains[slots[2]] & three:
                    supported[0] |= one
                    supported[1] |= two
                    supported[2] |= three
            if not supported[0]:
                return 0
            for edge, mask in zip(slots, supported):
                if domains[edge] != mask:
                    domains[edge] = mask
                    u, v, _ = edges[edge]
                    queue.append(v if u == vertex else u)
        best = None
        for edge, mask in enumerate(domains):
            if mask.bit_count() == 2:
                best = edge
                break
            if mask == 7:
                best = edge
        if best is None:
            return 1
        ways = 0
        for color in (1, 2, 4):
            if domains[best] & color:
                branch = domains.copy()
                branch[best] = color
                ways += visit(branch, list(edges[best][:2]))
        return ways
    return visit(initial, list(range(len(incident))))


def large_check():
    n = 48
    rng = random.Random(482026)
    planted = [(i,) for i in range(1, n + 1)]
    for _ in range(144):
        a, b, c = rng.sample(range(1, n + 1), 3)
        planted.append((a, b * rng.choice((-1, 1)), c * rng.choice((-1, 1))))
    graph = compile_cnf(n, planted)
    family = MatchingFamily(graph)
    require(family.components == 1 and len(family.choices) == n, "large topology")
    # Identify a component's Boolean variable via the supplied decoder edge
    # but reconstruct both alternating matchings from the raw graph.
    membership = {e: (i, side) for i, halves in enumerate(family.choices)
                  for side, half in enumerate(halves) for e in half}
    position = [membership[e] for e in graph["variable_red_edges"]]
    all_ones = (1 << n) - 1
    for mask in [all_ones, 0, *(all_ones ^ (1 << j) for j in range(n))]:
        red = set(family.fixed)
        for bit, (i, side) in enumerate(position):
            chosen = side if (mask >> bit) & 1 else side ^ 1
            red.update(family.choices[i][chosen])
        bad, cycles, ways, coloring = family.inspect(red, witness=mask == all_ones)
        require(bad == int(mask != all_ones), "large assignment")
        require(cycles == graph["extension_exponent"] + 2, "large cycle count")
        if coloring is not None:
            check_coloring(family, coloring)
            require(ways == 1 << graph["extension_exponent"], "large count")
    print("Large graph:", graph["vertices"], "vertices;", n, "variables;",
          n + 2, "fixed assignments checked (no exhaustive search).")


def run():
    stats = Counter()
    # Every nonempty subset of the four clauses on x1,x2 that use each variable once.
    two = [(i, j) for i in (-1, 1) for j in (-2, 2)]
    for k in range(1, len(two) + 1):
        for clauses in combinations(two, k):
            verify_formula(2, clauses, stats)
    # Every subset of the eight signed 3-clauses on three distinct variables.
    three = [tuple(sign * (j + 1) for j, sign in enumerate(signs))
             for signs in product((-1, 1), repeat=3)]
    for k in range(9):
        for clauses in combinations(three, k):
            verify_formula(3, clauses, stats)
    # Every signed 3-clause, including repetitions, over two variables.
    for clause in product((-2, -1, 1, 2), repeat=3):
        verify_formula(2, [clause], stats)
    for n, cs in [(2, []), (3, [()]), (2, [(1,), (-1,)]),
                  (2, [(1,2), (-1,2), (1,-2)]), (3, [(1, 2, -3, -1, 2)])]:
        verify_formula(n, cs, stats)
    rng = random.Random(20261121)
    for i in range(64):
        n = rng.randint(1, 5)
        clauses = [tuple(rng.choice((-1, 1)) * rng.randint(1,n)
                         for _ in range(rng.randint(1,5)))
                   for _ in range(rng.randint(1,6))]
        if i % 5 == 0:
            clauses.extend(((1,), (-1,)))
        verify_formula(n, clauses, stats)
    print("Independent red-matching enumeration:", dict(stats))
    for clauses in [[(1,)], [(-1,)], [(1,), (-1,)], [(1, -1)]]:
        graph = compile_cnf(1, clauses)
        brute = generic_raw_count(graph)
        require(brute == solve(graph)["full_extensions"], "direct raw total")
        print("Generic all-different backtracking", clauses, brute)
    large_check()
    print("All graph checks passed.")


if __name__ == "__main__":
    run()
