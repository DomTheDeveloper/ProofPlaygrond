# Two blue clues in cubic bipartite edge coloring

This package accompanies the manuscript **Two blue clues in cubic bipartite edge coloring**. It includes the editable LaTeX source, a SAT-to-graph compiler, a solver for the independent-cycle case, an exact background sampler, and independent checks. Python 3.10 or later suffices for the core scripts. The optional Z3 cross-check also requires the Z3 shared library.

## Try the example

The example has one satisfying assignment, with both variables true. The supplied `example.graph.json` has 1,560 vertices, two blue clues, and 390 red clues. All clues form a matching.

```sh
python3 two_blue.py example.cnf example.graph.json
python3 cycle_solver.py example.graph.json
```

The result is one extendible red perfect matching and 2,097,152 labeled full colorings. Pass `--witness` to the solver to obtain one complete coloring indexed in input-edge order. To sample with the blue constraints released, run the following command. It returns the marked-edge colors and full coloring.

```sh
python3 sample_background.py example.graph.json --seed 7
```

For this example the two probes are both blue with probability 1/16. A single seeded draw is reproducible. The theorem gives the exact probability.

## Reproduce the checks

```sh
python3 verify.py
python3 check_kempe.py
python3 check_controls.py
python3 z3_check.py
```

`verify.py` reconstructs the red matching components from the graph, checks each decoded assignment, verifies cycle scores and multiplicities, and inspects each full witness. The generic all-different backtracker sees only the raw edges and their colors.

`check_kempe.py` tests the probe marginals and checks whether any full lift of a given matching can admit a red-changing Kempe flip. It enforces monochromaticity on each nonred half-cycle in turn and solves the residual parity constraints exactly.

`check_controls.py` exhausts all 512 random-bit tapes for a small sampler instance and compares its output with a separate raw coloring count. It also checks square-switch reachability and planar boundary relations.

`z3_check.py` encodes one Boolean variable per edge and color. Every edge receives exactly one color, every vertex has exactly one incident edge of each color, and every clue is asserted. The solver sees only the raw graph. You may pass a graph JSON file to this script.

Recorded results are in `CHECK_RESULTS.txt`. The 123,088-vertex graph was checked on 50 specified assignments. The 404 smaller formulas were checked exhaustively over their assignments.

## Compile another formula

```sh
python3 two_blue.py formula.cnf graph.json
python3 two_blue.py formula.cnf locked.graph.json --lock-kempe
```

The input is DIMACS CNF with at least one declared variable. Negative literals, repeated literals, unit clauses and differing clause widths are supported. An empty clause is replaced by two contradictory units. An otherwise unused variable gets a tautology. Both normalizations preserve the assignment set. Size formulas use the normalized input. The optional flag appends one additional tautology per variable so each satisfying assignment forms a distinct component under full, clue-preserving Kempe changes.

A graph JSON object has `vertices` and `edges`. Its vertices are numbered from zero. Each edge is `[u,v,color]`, where 0 is free and 1, 2, 3 denote red, blue and green. `variable_red_edges[i]` gives an edge index that is red precisely when DIMACS variable `i+1` is true. For a satisfying assignment `extension_exponent` is the base-2 logarithm of its full-coloring multiplicity. The solver imports neither the compiler nor its two metadata fields.

The cycle solver applies to cubic bipartite inputs where deleting the forced red endpoints and omitting forbidden nonred edges leaves maximum degree at most two. Its worst-case number of choices grows as 2^c for c remaining cycle components. Uniformity of the background sampler relies on the equal-cycle-count theorem for the compiled family.

## Typeset the manuscript

```sh
pdflatex Two_Blue_Clues.tex
pdflatex Two_Blue_Clues.tex
```

A normal TeX Live installation with AMS, TikZ, hyperref, fancyhdr, booktabs and geometry is sufficient.
