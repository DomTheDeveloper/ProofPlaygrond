"""Test the two-probe marginals and all possible red-changing Kempe moves."""

from itertools import combinations, product
from random import Random
from two_blue import compile_cnf
from cycle_solver import MatchingFamily
from verify import truth, require


def run():
    seen_graphs = tested_moves = checked_assignments = extensions_checked = 0
    cases = [(1, [(1, -1)]), (2, [(1, 2), (-1, -2)]),
             (1, [(1,), (-1,)]), (3, [(1, 2, 3), (-1, -2, -3)])]
    three = [tuple((i + 1) * s for i, s in enumerate(signs))
             for signs in product((-1, 1), repeat=3)]
    for clauses in combinations(three, 2):
        cases.append((3, clauses))
    rng = Random(202611212)
    for _ in range(8):
        cases.append((4, [tuple(rng.choice((-1, 1)) * rng.randint(1, 4)
                                 for _ in range(3)) for _ in range(4)]))
    for n, clauses in cases:
        graph = compile_cnf(n, clauses, lock_kempe=True)
        family = MatchingFamily(graph)
        blue = [e for e, (_, _, c) in enumerate(family.edges) if c == 2]
        total_joint = total_background = single = satisfying = 0
        for red in family.matchings():
            bits = sum((e in red) << i for i, e in enumerate(graph["variable_red_edges"]))
            good = truth(clauses, bits)
            bad, cycle_count, ways, _ = family.inspect(red)
            require(bad == int(not good), "wrong locked answer")
            total_joint += ways
            satisfying += good
            for edge in blue:
                family.edges[edge][2] = 0
                one = family.inspect(red)[2]
                require(one == 1 << (cycle_count - 1), "one-probe marginal")
                family.edges[edge][2] = 2
            single += one
            for edge in blue:
                family.edges[edge][2] = 0
            background = family.inspect(red)[2]
            total_background += background
            for edge in blue:
                family.edges[edge][2] = 2
            require(background == 1 << cycle_count, "red-only total")
            checked_assignments += 1
            if not good:
                continue
            extensions_checked += ways
            for halves in family.choices:
                target = halves[1] if halves[0][0] in red else halves[0]
                for color in (2, 3):
                    for e in target:
                        require(family.edges[e][2] == 0, "unexpected core pin")
                        family.edges[e][2] = color
                    # If any coloring in the whole fiber allows this Kempe flip,
                    # one orientation of the residual cycles satisfies these pins.
                    require(family.inspect(red)[2] == 0, "red Kempe move possible")
                    for e in target:
                        family.edges[e][2] = 0
                    tested_moves += 1
        require(2 * single == total_background, "summed one-probe identity")
        require(4 * (1 << n) * total_joint == satisfying * total_background,
                "two-probe probability identity")
        seen_graphs += 1
    print(f"Locked graphs: {seen_graphs}; assignments: {checked_assignments}; "
          f"potential red flips by color tested across full fibers: {tested_moves}; "
          f"represented extensions: {extensions_checked}")
    print("All marginals and Kempe checks passed.")


if __name__ == "__main__":
    run()
