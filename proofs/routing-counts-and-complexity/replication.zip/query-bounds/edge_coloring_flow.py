"""Count and construct extensions of partial three-edge-colorings of cubic graphs.

Python 3.10+, standard library. Run with a JSON file containing {"vertices": n,
"edges": [[u, v, color], ...]}. Vertices are 0..n-1 and 0 denotes an uncolored
edge. Use --decide for a witness alone; check_graph_results.py runs the experiments.
"""
import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
import json


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


class Equations:
    """Binary linear equations stored in row echelon form, high pivots first."""

    def __init__(self, dimension):
        self.dimension = dimension
        self.rows = {}

    def copy(self):
        result = Equations(self.dimension)
        result.rows = self.rows.copy()
        return result

    def reduce(self, mask, rhs=0):
        for pivot in sorted(self.rows, reverse=True):
            if mask >> pivot & 1:
                row, value = self.rows[pivot]
                mask ^= row
                rhs ^= value
        return mask, rhs

    def add(self, mask, rhs):
        mask, rhs = self.reduce(mask, rhs)
        if not mask:
            return rhs == 0
        self.rows[mask.bit_length() - 1] = (mask, rhs)
        return True

    def one_solution(self):
        answer = 0
        for pivot in sorted(self.rows):
            mask, rhs = self.rows[pivot]
            if (mask & answer).bit_count() % 2 != rhs:
                answer |= 1 << pivot
        return answer


def classify_forbidden(system, a, b, z):
    """Classify the forbidden intersection a(x)=z0, b(x)=z1.

    Return 'safe', 'reject', 'force', or 'plane'. A plane's two masks are a
    canonical basis for its two normal directions, with the forbidden target.
    """
    u, f = system.reduce(a, z & 1)
    v, g = system.reduce(b, z >> 1)
    if (u == 0 and f) or (v == 0 and g) or (u == v and f != g):
        return "safe", None
    if not u and not v:
        return "reject", None
    if not v or u == v:
        return "force", (u, 1 ^ f)
    if not u:
        return "force", (v, 1 ^ g)
    targets = {u: f, v: g, u ^ v: f ^ g}
    p, q = sorted(targets)[:2]
    return "plane", (p, q, targets[p] | (targets[q] << 1), u, v)


def allowed_equations(p, q, allowed):
    first = min(allowed)
    if len(allowed) == 1:
        return [(p, first & 1), (q, first >> 1)]
    delta = first ^ max(allowed)
    if delta == 1:
        return [(q, first >> 1)]
    if delta == 2:
        return [(p, first & 1)]
    return [(p ^ q, first.bit_count() % 2)]


def affine_closure(k, edges):
    system = Equations(2 * k)
    while True:
        equations = []
        groups = {}
        for mask, offset in edges:
            kind, info = classify_forbidden(system, mask, mask << k, offset)
            if kind == "reject":
                return None, []
            if kind == "force":
                equations.append(info)
            if kind == "plane":
                p, q, target, first, second = info
                if (p, q) not in groups:
                    groups[p, q] = (set(), (first, second))
                groups[p, q][0].add(target)
        remaining = []
        for (p, q), (forbidden, directions) in groups.items():
            allowed = {0, 1, 2, 3} - forbidden
            if not allowed:
                return None, []
            if len(allowed) == 3:
                remaining.append((p, q, next(iter(forbidden)), *directions))
            else:
                equations.extend(allowed_equations(p, q, allowed))
        previous_rank = len(system.rows)
        if not all(system.add(mask, value) for mask, value in equations):
            return None, []
        if len(system.rows) == previous_rank:
            return system, remaining


def independent_forms(masks, dimension):
    system = Equations(dimension)
    result = []
    for mask in masks:
        before = len(system.rows)
        system.add(mask, 0)
        if len(system.rows) > before:
            result.append(mask)
    return result


def count_factor(k, edges):
    """Return count, one pair of cycle-space assignments, rank, branch count."""
    if k == 1:
        allowed = sorted({0, 1, 2, 3} - {offset for _, offset in edges})
        return len(allowed), (allowed[0] if allowed else None), 0, 0
    base, remaining = affine_closure(k, edges)
    if base is None:
        return 0, None, 0, 0
    candidates = (
        [u for _, _, _, u, v in remaining],
        [v for _, _, _, u, v in remaining],
        [u ^ v for _, _, _, u, v in remaining],
    )
    forms = min((independent_forms(c, 2 * k) for c in candidates), key=len)
    count, example = 0, None
    for values in range(1 << len(forms)):
        system = base.copy()
        for j, form in enumerate(forms):
            if not system.add(form, (values >> j) & 1):
                raise ArithmeticError("Independent observations became inconsistent.")
        for p, q, target, _, _ in remaining:
            kind, info = classify_forbidden(system, p, q, target)
            if kind == "reject" or (kind == "force" and not system.add(*info)):
                break
            if kind == "plane":
                raise ArithmeticError("Conditioning did not fix a plane direction.")
        else:
            count += 1 << (system.dimension - len(system.rows))
            if example is None:
                example = system.one_solution()
    return count, example, len(forms), 1 << len(forms)


def analyze_graph(n, edges):
    adjacency = [[] for _ in range(n)]
    demands = [0] * n
    degree = [0] * n
    occupied = [set() for _ in range(n)]
    pairs = set()
    fixed_conflict = False
    for i, (u, v, color) in enumerate(edges):
        if not (0 <= u < n and 0 <= v < n and u != v and color in (0, 1, 2, 3)):
            raise ValueError("Invalid vertex, loop or color.")
        pair = tuple(sorted((u, v)))
        if pair in pairs:
            raise ValueError("Parallel edges are outside this input format.")
        pairs.add(pair)
        for a, b in ((u, v), (v, u)):
            degree[a] += 1
            if color:
                fixed_conflict |= color in occupied[a]
                occupied[a].add(color)
                demands[a] ^= color
            else:
                adjacency[a].append((b, i))
    if any(d != 3 for d in degree):
        raise ValueError("Every vertex must have degree three.")
    return adjacency, demands, fixed_conflict


def cycle_signatures(n, edges, adjacency, demands):
    """A particular flow plus fundamental-cycle membership for each edge."""
    parents = [-1] * n
    parent_edges = [-1] * n
    tree_edges = set()
    order = []
    for start in range(n):
        if parents[start] != -1:
            continue
        parents[start] = start
        stack = [start]
        while stack:
            u = stack.pop()
            order.append(u)
            for v, e in adjacency[u]:
                if parents[v] == -1:
                    parents[v], parent_edges[v] = u, e
                    tree_edges.add(e)
                    stack.append(v)
    signatures = [0] * len(edges)
    offsets = [color for u, v, color in edges]
    delta = [0] * n
    dimension = 0
    for e, (u, v, color) in enumerate(edges):
        if not color and e not in tree_edges:
            bit = 1 << dimension
            dimension += 1
            signatures[e] = bit
            delta[u] ^= bit
            delta[v] ^= bit
    for v in reversed(order):
        u, e = parents[v], parent_edges[v]
        if u == v:
            if demands[v]:
                return None
            continue
        signatures[e] = delta[v]
        delta[u] ^= delta[v]
        offsets[e] = demands[v]
        demands[u] ^= demands[v]
    return signatures, offsets, dimension


class DisjointSets:
    def __init__(self, n):
        self.parent = list(range(n))

    def root(self, item):
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def join(self, a, b):
        self.parent[self.root(b)] = self.root(a)


@dataclass
class Result:
    count: int
    coloring: list | None
    max_branch_rank: int = 0
    branches_tested: int = 0


def solve(n, edges):
    """Exact labeled extension count and one coloring, in input edge order."""
    if not isinstance(n, int) or n < 0:
        raise ValueError("The vertex count must be a nonnegative integer.")
    adjacency, demands, conflict = analyze_graph(n, edges)
    if conflict:
        return Result(0, None)
    data = cycle_signatures(n, edges, adjacency, demands)
    if data is None:
        return Result(0, None)
    signatures, offsets, dimension = data
    sets = DisjointSets(dimension)
    for e, sig in enumerate(signatures):
        if sig:
            first, *others = bits(sig)
            for j in others:
                sets.join(first, j)
        elif not offsets[e]:
            return Result(0, None)
    factor_edges = defaultdict(list)
    factor_bits = defaultdict(list)
    for j in range(dimension):
        factor_bits[sets.root(j)].append(j)
    for e, sig in enumerate(signatures):
        if sig:
            factor_edges[sets.root((sig & -sig).bit_length() - 1)].append(e)
    result = Result(1, offsets[:])
    for key, edge_ids in factor_edges.items():
        positions = {j: i for i, j in enumerate(factor_bits[key])}
        k = len(positions)
        terms = [(sum(1 << positions[j] for j in bits(signatures[e])), offsets[e])
                 for e in edge_ids]
        count, witness, rank, visits = count_factor(k, terms)
        result.max_branch_rank = max(result.max_branch_rank, rank)
        result.branches_tested += visits
        if not count:
            return Result(0, None, result.max_branch_rank, result.branches_tested)
        result.count *= count
        for e, (mask, offset) in zip(edge_ids, terms):
            a = (witness & mask).bit_count() % 2
            b = ((witness >> k) & mask).bit_count() % 2
            result.coloring[e] = offset ^ a ^ (b << 1)
    return result


def valid(n, edges, colors):
    if colors is None or len(edges) != len(colors):
        return False
    around = [[] for _ in range(n)]
    for (u, v, pin), color in zip(edges, colors):
        if pin and pin != color:
            return False
        around[u].append(color)
        around[v].append(color)
    return all(sorted(row) == [1, 2, 3] for row in around)


def bipartition(n, edges):
    adjacency = [[] for _ in range(n)]
    for i,(u,v,_) in enumerate(edges):
        adjacency[u].append((v,i))
        adjacency[v].append((u,i))
    side = [-1]*n
    for root in range(n):
        if side[root] >= 0:
            continue
        side[root] = 0
        stack = [root]
        while stack:
            u = stack.pop()
            for v,i in adjacency[u]:
                if side[v] < 0:
                    side[v] = 1-side[u]
                    stack.append(v)
                elif side[v] == side[u]:
                    return None, adjacency
    return side, adjacency


def matching_witness(n, edges, side, adjacency, color):
    """Force one color class; reconstruct the other colors along even cycles."""
    used = set()
    matching = set()
    for i,(u,v,pin) in enumerate(edges):
        if pin == color:
            if u in used or v in used:
                return None
            used.update((u,v))
            matching.add(i)
    owner, pair = {}, {}
    for root in range(n):
        if side[root] != 0 or root in used:
            continue
        front, seen_right, path = [root], set(), {}
        free = None
        while front and free is None:
            u = front.pop()
            for v,i in adjacency[u]:
                if v in used or v in seen_right or edges[i][2]:
                    continue
                seen_right.add(v)
                path[v] = (u,i)
                if v not in owner:
                    free = v
                    break
                front.append(owner[v])
        if free is None:
            return None
        while free is not None:
            u,i = path[free]
            old = pair.get(u)
            pair[u] = (free,i)
            owner[free] = u
            free = old[0] if old else None
    matching.update(i for v,i in pair.values())
    result = [color if i in matching else 0 for i in range(len(edges))]
    other = sorted({1,2,3}-{color})
    for i in range(len(edges)):
        if result[i]:
            continue
        start = edges[i][0]
        v, e, cycle = start, i, []
        while True:
            cycle.append(e)
            u,w,_ = edges[e]
            v = w if v == u else u
            if v == start:
                break
            e = next(j for x,j in adjacency[v] if j != e and j not in matching)
        for flip in (0,1):
            if all(not edges[j][2] or edges[j][2] == other[(s+flip) % 2]
                   for s,j in enumerate(cycle)):
                for s,j in enumerate(cycle):
                    result[j] = other[(s+flip) % 2]
                break
        else:
            return None
    return result


def decide(n, edges):
    """Fast bipartite decision for one dominant prescribed color; exact fallback."""
    _, _, conflict = analyze_graph(n, edges)
    if conflict:
        return None
    counts = Counter(pin for _,_,pin in edges if pin)
    color = max((1,2,3), key=lambda z: counts[z])
    if sum(counts.values()) - counts[color] <= 1:
        side, adj = bipartition(n,edges)
        if side is not None:
            return matching_witness(n, edges, side, adj, color)
    return solve(n, edges).coloring


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="JSON file with vertices and edges")
    parser.add_argument("--decide", action="store_true", help="find a coloring without requesting a count")
    args = parser.parse_args()
    with open(args.input, encoding="utf-8") as stream:
        data = json.load(stream)
    if args.decide:
        coloring = decide(data["vertices"], data["edges"])
        print(json.dumps({"extendible": coloring is not None, "coloring": coloring}))
    else:
        answer = solve(data["vertices"], data["edges"])
        print(json.dumps(vars(answer)))
