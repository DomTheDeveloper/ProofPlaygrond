"""Reproduce all finite graph results in the research note. Run with Python 3.10+."""
from collections import Counter, defaultdict
from itertools import permutations, product
from random import Random
from edge_coloring_flow import (
    Equations, allowed_equations, bipartition, bits, classify_forbidden, decide, solve, valid,
)

def switch_ring(k):
    """Return a ring of k squares. Internal edge order is straight, then crossed."""
    if k < 2:
        raise ValueError("A simple ring needs at least two squares.")
    edges = []
    for i in range(k):
        a, b, c, d = range(4*i, 4*i+4)
        nxt = 4*((i+1) % k)
        edges.extend(((a, b, 0), (c, d, 0), (a, d, 0), (c, b, 0),
                      (b, nxt, 2), (d, nxt+2, 3)))
    return 4*k, edges


def latin_ring(k):
    """K3,3-minus-an-edge blocks, joined in a ring; pin one connector."""
    if k < 2:
        raise ValueError("Use at least two blocks.")
    edges = []
    for i in range(k):
        for r, c in product(range(3), repeat=2):
            if (r, c) != (0, 0):
                edges.append((6*i+r, 6*i+3+c, 0))
        edges.append((6*i, 6*((i+1) % k)+3, int(i == 0)))
    return 6*k, edges


def bad_cycles(n, edges, matching):
    """Direct cycle walk with alternating parity, independent of the flow solver."""
    incident = [[] for _ in range(n)]
    for e, (u, v, _) in enumerate(edges):
        if e not in matching:
            incident[u].append(e)
            incident[v].append(e)
    assert all(len(row) == 2 for row in incident)
    seen = set()
    bad = 0
    for start in range(n):
        if start in seen:
            continue
        v, previous, parity = start, -1, 0
        required = set()
        while v not in seen:
            seen.add(v)
            a, b = incident[v]
            e = a if a != previous else b
            left, right, color = edges[e]
            if color:
                assert color in (2, 3)
                required.add((color - 2) ^ parity)
            previous, parity = e, parity ^ 1
            v = right if left == v else left
        bad += len(required) == 2
    return bad


def enumerate_colorings(n, edges):
    """Independent backtracking oracle, suitable only for small graphs."""
    occupied = [0] * n
    colors = [pin for _, _, pin in edges]
    for u, v, pin in edges:
        if pin:
            bit = 1 << (pin-1)
            if (occupied[u] | occupied[v]) & bit:
                return
            occupied[u] |= bit
            occupied[v] |= bit

    def visit():
        best, choices = -1, 0
        for e, (u, v, _) in enumerate(edges):
            if colors[e]:
                continue
            available = 7 & ~(occupied[u] | occupied[v])
            if not available:
                return
            if best < 0 or available.bit_count() < choices.bit_count():
                best, choices = e, available
        if best < 0:
            yield tuple(colors)
            return
        u, v, _ = edges[best]
        for value in bits(choices):
            bit = 1 << value
            occupied[u] |= bit
            occupied[v] |= bit
            colors[best] = value+1
            yield from visit()
            occupied[u] ^= bit
            occupied[v] ^= bit
            colors[best] = 0
    yield from visit()


def proper_clues(n, edges):
    fixed = [0] * len(edges)
    used = [set() for _ in range(n)]

    def visit(e):
        if e == len(edges):
            yield tuple(fixed)
            return
        u, v, _ = edges[e]
        yield from visit(e+1)
        for color in (1, 2, 3):
            if color not in used[u] and color not in used[v]:
                used[u].add(color)
                used[v].add(color)
                fixed[e] = color
                yield from visit(e+1)
                fixed[e] = 0
                used[u].remove(color)
                used[v].remove(color)
    yield from visit(0)


def random_graph(s, rng):
    while True:
        cols = []
        for _ in range(3):
            p = list(range(s))
            rng.shuffle(p)
            cols.append(p)
        if all(len({col[r] for col in cols}) == 3 for r in range(s)):
            return sorted((r, s+cols[color][r], color+1)
                          for r in range(s) for color in range(3))


def high_barrier(d):
    """Two even-cycle modules. Return a graph and its four residual routings."""
    if d < 3 or d % 2 == 0:
        raise ValueError("Use an odd d of at least three.")
    m, shift = 2*d, d+2
    edges, options = [], []
    for j in range(2):
        straight, shifted = set(), set()
        for i in range(m):
            left = 2*m*j + i
            right = 2*m*j + m
            straight.add(len(edges))
            edges.append((left, right+i, 0))
            shifted.add(len(edges))
            edges.append((left, right+(i+shift) % m, 0))
            dest = (2*m+i) if j == 0 else (i-2) % m
            edges.append((right+i, dest, 2+i % 2))
        # If the residual uses the shifted edges, M uses the straight ones.
        options.append((shifted, straight))
    ms = [options[0][a] | options[1][b] for a,b in product((0,1),repeat=2)]
    return 4*m, edges, ms


def matching_filter(n, edges, starting_domains):
    """Small-instance oracle for the fixed point of single-color matching support."""
    s = n//2
    rows = [[] for _ in range(s)]
    for i, (u,v,_) in enumerate(edges):
        rows[u].append((v-s,i))
    all_matchings = []
    def visit(row, cols, matched):
        if row == s:
            all_matchings.append(matched)
            return
        for c,i in rows[row]:
            if not cols >> c & 1:
                visit(row+1, cols | (1<<c), matched | (1<<i))
    visit(0, 0, 0)
    domains = starting_domains[:]
    while True:
        old = domains[:]
        feasible = []
        for k in range(3):
            forced = sum(1 << i for i,d in enumerate(domains) if d == 1<<k)
            blocked = sum(1 << i for i,d in enumerate(domains) if not (d >> k & 1))
            matchings = [m for m in all_matchings if m & forced == forced and not (m & blocked)]
            if not matchings:
                return [], []
            feasible.append(matchings)
            common, union = matchings[0], 0
            for m in matchings:
                common &= m
                union |= m
            for i in range(len(edges)):
                if common >> i & 1:
                    domains[i] &= 1 << k
                if not union >> i & 1:
                    domains[i] &= ~(1 << k)
        if old == domains:
            return domains, feasible


def cube_edges():
    return [(v, v ^ bit, bit) for v in range(8) for bit in (1,2,4)
            if not v & bit]


def adapter_edges(start, first_pin=False):
    """A cube missing edge 0--1. When requested, force exterior color 3."""
    out = []
    for a,b,bit in cube_edges():
        if (a,b) == (0,1):
            continue
        pin = {2:1,4:2}.get(bit,0) if first_pin and a == 0 else 0
        out.append((start+a,start+b,pin))
    return out


def two_color_reduction(n, edges):
    """Replace every color-3 prescription by an adapter pinned in colors 1 and 2."""
    out = []
    for u,v,z in edges:
        if z != 3:
            out.append((u,v,z))
            continue
        out.extend(adapter_edges(n, True))
        out.extend(((u,n,0),(n+1,v,0)))
        n += 8
    return n, out


def space_prescriptions(n, edges, j=1):
    """Replace each edge by 2j adapters, copying its prescription to the center."""
    if j < 1:
        raise ValueError("Use at least one adapter on each side of the clue.")
    out = []
    for u,v,pin in edges:
        last = u
        for i in range(2*j):
            out.append((last, n, pin if i == j else 0))
            out.extend(adapter_edges(n))
            last = n+1
            n += 8
        out.append((last, v, 0))
    return n, out


def run_reduction_checks():
    # Enumerate the cube independently to get exact local completion multiplicities.
    cube = [(u,v,0) for u,v,_ in cube_edges()]
    completions = list(enumerate_colorings(8,cube))
    missing = next(i for i,(u,v,_) in enumerate(cube) if (u,v)==(0,1))
    thin = Counter(c[missing] for c in completions)
    forced = [c for c in completions if all(not z or
              c[next(i for i,(x,y,_) in enumerate(cube) if (x,y)==(u,v))] == z
              for u,v,z in adapter_edges(0,True))]
    assert thin == {1:8,2:8,3:8} and len(forced)==4 and all(c[missing]==3 for c in forced)
    # Actual 1-adapter replacements, on every one-pin input and every color-3/other pair.
    base = [(u,v,0) for u in range(3) for v in range(3,6)]
    checked = 0
    for i in range(len(base)):
        for j in range(len(base)):
            for b in (1,2):
                e = [(u,v,3 if k==i else b if k==j else 0) for k,(u,v,_) in enumerate(base)]
                n, grown = two_color_reduction(6,e)
                ref = sum(1 for _ in enumerate_colorings(6,e))
                res = solve(n,grown)
                assert res.count == 4*ref and (not res.count or valid(n,grown,res.coloring))
                assert all(z != 3 for _,_,z in grown)
                checked += 1
    print(f"Adapter: 8 extensions per exterior color; 4 with the two pins forcing color 3; {checked} encoded inputs checked.")
    # Geometry of a fully expanded proper instance. The general count is proved by composition.
    pinned = [(u,v,1 if i in (0,4,8) else 0) for i,(u,v,_) in enumerate(base)]
    for j in (1,2,5):
        n, grown = space_prescriptions(6,pinned,j)
        side, adj = bipartition(n,grown)
        assert side is not None and all(len(l)==3 for l in adj) and n==6+16*j*len(base)
        clues = [(u,v) for u,v,z in grown if z]
        for ci,(u,v) in enumerate(clues):
            distance={u:0,v:0}
            queue=[u,v]
            for a in queue:
                for w,_ in adj[a]:
                    if w not in distance:
                        distance[w]=1+distance[a]
                        queue.append(w)
            assert all(min(distance[x],distance[y]) >= 8*j for x,y in clues[ci+1:])
        w = decide(n,grown)
        assert valid(n,grown,w)
    print("Wires: cubicity, bipartiteness, separation and a complete coloring tested at 1, 2 and 5 cubes per side.")


def four_clue_graph():
    rows = ((1,6,7), (0,5,10), (2,5,10), (3,4,10), (0,1,9), (3,7,9),
            (4,7,8), (1,3,8), (0,2,9), (2,6,8), (4,5,6))
    pins = {(2,5):1, (3,4):2, (4,0):2, (7,8):1}
    return 22, [(r,11+c,pins.get((r,c),0)) for r,row in enumerate(rows) for c in row]


def affine_domains(n, edges, domains):
    """Project the consequences of the affine relaxation onto the edge lists."""
    m = len(edges)
    system = Equations(2*m)
    incident = [0]*n
    for i,(u,v,_) in enumerate(edges):
        incident[u] |= 1 << i
        incident[v] |= 1 << i
    for mask in incident:
        system.add(mask, 0)
        system.add(mask << m, 0)
    points = [(1 << i, 1 << (m+i), z) for i,domain in enumerate(domains)
              for z in (0,1,2,3) if z == 0 or not (domain >> (z-1) & 1)]
    while True:
        rank = len(system.rows)
        equations = []
        groups = defaultdict(set)
        for a,b,z in points:
            kind, info = classify_forbidden(system,a,b,z)
            if kind == "reject":
                return []
            if kind == "force":
                equations.append(info)
            if kind == "plane":
                p,q,target,*_ = info
                groups[p,q].add(target)
        for (p,q), forbidden in groups.items():
            allowed = {0,1,2,3} - forbidden
            if not allowed:
                return []
            if len(allowed) < 3:
                equations.extend(allowed_equations(p,q,allowed))
        if not all(system.add(a,b) for a,b in equations):
            return []
        if len(system.rows) == rank:
            break
    result = []
    for i,domain in enumerate(domains):
        allowed = 0
        for z in (1,2,3):
            if domain >> (z-1) & 1:
                copy = system.copy()
                if copy.add(1 << i, z & 1) and copy.add(1 << (m+i), z >> 1):
                    allowed |= 1 << (z-1)
        if not allowed:
            return []
        result.append(allowed)
    return result


def joint_witness():
    n, edges = four_clue_graph()
    domains = [1 << (z-1) if z else 7 for _,_,z in edges]
    while True:
        old = domains[:]
        domains, feasible = matching_filter(n, edges, domains)
        assert domains
        domains = affine_domains(n, edges, domains)
        assert domains
        if domains == old:
            break
    sizes = list(map(len, feasible))
    matrix = [[(x & y).bit_count() for y in feasible[1]] for x in feasible[0]]
    assert sizes == [6,6,12] and all(min(row) > 0 for row in matrix)
    unpinned = [(u,v,0) for u,v,z in edges]
    full = list(enumerate_colorings(n,unpinned))
    assert len(full)==312 and not any(enumerate_colorings(n,edges))
    drop_counts = [sum(all(not z or i == drop or f[i]==z for i,(_,_,z) in enumerate(edges))
                       for f in full) for drop,(_,_,z) in enumerate(edges) if z]
    assert drop_counts == [13,10,15,11]
    result = solve(n,edges)
    assert result.count == 0 and result.max_branch_rank == 4
    print(f"Four-clue no-instance: {sizes} supported color matchings, all 36 red-blue pairs overlap;"
          f" clue deletion counts {drop_counts}.")
    return feasible, matrix


def square_network(red, blue):
    k = len(red)
    edges = []
    for i in range(k):
        a,b,c,d = range(4*i,4*i+4)
        edges.extend(((a,b,0),(c,d,0),(a,d,0),(c,b,0),
                      (b,4*red[i],2),(d,4*blue[i]+2,3)))
    return 4*k, edges


def check_square_paths():
    rng = Random(10061956)
    cases = 0
    for k in range(3,9):
        for _ in range(6):
            routes = []
            for label in (2,3):
                perm = list(range(k))
                while any(i == v for i,v in enumerate(perm)):
                    rng.shuffle(perm)
                routes.append(perm)
            n,e = square_network(*routes)
            scores = []
            for state in range(1 << k):
                m = {6*i+j for i in range(k) for j in
                     ((0,1) if (state >> i) & 1 else (2,3))}
                scores.append(bad_cycles(n,e,m))
            for state in range(1,1 << k):
                # A one- or two-flip correction reduces the number of wrong
                # switches, returns to a score no larger, and peaks at most one higher.
                cost = scores[state]
                found = False
                for i in bits(state):
                    first = state ^ (1 << i)
                    if scores[first] <= cost:
                        found = True
                        break
                    if scores[first] <= cost+1 and any(
                            scores[first ^ (1 << j)] <= cost for j in bits(first)):
                        found = True
                        break
                assert found
                cases += 1
    print(f"Square-switch correction: the one/two-flip lemma verified in {cases} nonterminal states.")


def verify():
    edges = [(u, 3+v, 0) for u in range(3) for v in range(3)]
    full = list(enumerate_colorings(6, edges))
    assert len(full) == 12
    expected = Counter(tuple(color if m >> j & 1 else 0 for j, color in enumerate(f))
                       for f in full for m in range(1 << len(edges)))
    cases = yes = 0
    for pins in proper_clues(6, edges):
        e = [(u, v, pin) for (u, v, _), pin in zip(edges, pins)]
        res = solve(6, e)
        assert res.count == expected[pins] and (not res.count or valid(6, e, res.coloring))
        decision = decide(6, e)
        assert (decision is not None) == bool(res.count) and (decision is None or valid(6, e, decision))
        yes += res.count > 0
        cases += 1
    print(f"K3,3: {cases} locally proper partial colorings, {yes} extendible, {cases-yes} impossible.")

    rng = Random(20261122)
    counts = Counter()
    for s in range(3, 9):
        for trial in range(100):
            input_edges = random_graph(s, rng)
            occupied = [set() for _ in range(2*s)]
            e = []
            for u, v, base in input_edges:
                pin = 0
                choices = sorted({1, 2, 3} - occupied[u] - occupied[v])
                if rng.random() < (trial % 7 + 1)/10 and choices:
                    pin = base if trial % 2 == 0 else rng.choice(choices)
                if pin:
                    occupied[u].add(pin)
                    occupied[v].add(pin)
                e.append((u, v, pin))
            oracle = sum(1 for _ in enumerate_colorings(2*s, e))
            res = solve(2*s, e)
            assert res.count == oracle and (not oracle or valid(2*s, e, res.coloring))
            counts[bool(oracle)] += 1
    print(f"Seeded cubic bipartite graphs: {sum(counts.values())} comparisons, "
          f"{counts[True]} extendible and {counts[False]} impossible.")
    joint_witness()
    check_square_paths()
    for d in (3,5,7,9,11,21,101):
        n,e,ms=high_barrier(d)
        scores=[bad_cycles(n,e,m) for m in ms]
        assert scores==[0,d,d,2]
        r=solve(n,e)
        assert r.count==1 and valid(n,e,r.coloring)
    print("Two-cycle barriers: unique solution and score sequence 2,d,0 verified through d=101.")
    run_reduction_checks()
    masks = 0
    for k in range(3, 13):
        n, e = switch_ring(k)
        res = solve(n, e)
        assert res.count == 1 and valid(n, e, res.coloring)
        for state in range(1 << k):
            # A wrong residual pairing leaves the two straight edges in M.
            m = {6*i+j for i in range(k) for j in
                 ((0, 1) if (state >> i) & 1 else (2, 3))}
            h = state.bit_count()
            assert bad_cycles(n, e, m) == (0 if not h else 1 if h % 2 else 2)
            masks += 1
    print(f"Switch rings: all {masks} states for 3 through 12 squares matched the formula.")
    for k in (3, 5, 25, 101, 1001):
        n, e = switch_ring(k)
        res = solve(n, e)
        assert res.count == 1 and valid(n, e, res.coloring)
    print("Large switch ring: 4,004 vertices, unique extension checked.")

    for k in (2, 3, 4, 8, 25, 100):
        n, e = latin_ring(k)
        res = solve(n, e)
        assert res.count == 4**k and valid(n, e, res.coloring)
        if k <= 4:
            assert sum(1 for _ in enumerate_colorings(n, e)) == 4**k
    local_perms = [a | (b << 2) | (c << 4) for a, b, c in permutations((1, 2, 3))]
    assert all(x ^ y ^ z not in local_perms for x, y, z in
               permutations(local_perms, 3))
    print("Affine-cover rings: 4^k verified for k=2,3,4,8,25,100; independent counts through k=4.")


if __name__ == "__main__":
    verify()
