"""Exact toy instance of Gap-MCSP decision-tree complexity (Python 3.10+).

Three variables give 8 truth-table positions and 256 functions. Constants and
input wires are free. One gate computes any Boolean function of two wires.
YES means circuit size at most s. NO means size strictly greater than t.
The circuit enumeration permits reuse of previous gate outputs.
"""
from functools import lru_cache
from itertools import combinations, combinations_with_replacement


def circuits(n=3, max_size=3):
    length = 1 << n
    full = (1 << length) - 1
    inputs = {0, full}
    inputs.update(sum(((position >> j) & 1) << position for position in range(length))
                  for j in range(n))
    frontier = {frozenset(inputs)}
    achievable = inputs.copy()
    balls = [achievable.copy()]

    @lru_cache(None)
    def all_gates(a,b):
        regions = ((~a & ~b) & full, (~a & b) & full, (a & ~b) & full, a & b)
        return {sum(region for j,region in enumerate(regions) if op >> j & 1)
                for op in range(16)}

    for size in range(1,max_size+1):
        new = set()
        for state in frontier:
            for a,b in combinations_with_replacement(sorted(state),2):
                for output in all_gates(a,b) - state:
                    achievable.add(output)
                    if size < max_size:
                        new.add(state | {output})
        balls.append(achievable.copy())
        frontier = new
    return balls


def depths(length, yes, no):
    possible_positions = (1 << length) - 1
    # Candidate sets are integer bitsets indexed by complete truth tables.
    ys = sum(1 << f for f in yes)
    ns = sum(1 << f for f in no)
    column = [sum(1 << f for f in range(1 << length) if f >> i & 1)
              for i in range(length)]

    @lru_cache(None)
    def adaptive(pos, y, n):
        if not y or not n:
            return 0
        best = pos.bit_count()
        for i,c in enumerate(column):
            if pos >> i & 1:
                left = adaptive(pos ^ (1 << i), y & ~c, n & ~c)
                right = adaptive(pos ^ (1 << i), y & c, n & c)
                best = min(best, 1 + max(left,right))
        return best

    for queries in range(length+1):
        for chosen in combinations(range(length),queries):
            m = sum(1 << i for i in chosen)
            if {z & m for z in yes}.isdisjoint(z & m for z in no):
                return adaptive(possible_positions,ys,ns), queries
    raise AssertionError("Distinct complete truth tables are distinguishable.")


def main():
    length = 8
    balls = circuits()
    assert [len(row) for row in balls[:2]] == [5,38]
    print("Circuits on three inputs; functions attainable with 0, 1, 2, 3 gates:",
          [len(row) for row in balls])
    for s,t in ((0,1),(0,2),(1,2),(0,3),(1,3)):
        yes = balls[s]
        no = set(range(1 << length)) - balls[t]
        a,b = depths(length, yes, no)
        assert 0 <= a <= b <= length
        print(f"s={s}, t={t}: YES={len(yes)}, NO={len(no)}, adaptive={a}, nonadaptive={b}")


if __name__ == "__main__":
    main()
